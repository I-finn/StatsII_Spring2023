﻿The zip file fairness_R_project contains the project (fairness_eric.Rproj), that can be imported to R and all the scripts work smoothly.
The project was developed under the following R version:
	R version 3.6.1 (2019-07-05) -- "Action of the Toes"
	Copyright (C) 2019 The R Foundation for Statistical Computing
	Platform: x86_64-w64-mingw32/x64 (64-bit)


FOLDERS
--------

DATE ADDED      NAME OF FILE/FOLDER                             SHORT DESCRIPTION OF CONTENTS
============    ============================================    =================================================================================
20201124	data						Contains the raw data, that is imported to R with the script 1.1_fairness_cleaning
								and then used for all the following analysis.

20201124	output						This is an empty folder. Outputs created in the scripts will be saved in there.

20201124	scripts						Contains the scripts used to clean and analyse the data. For more details about 
								the specific scripts read the readme file in the folder (_readme.scripts).


FILES
-------

DATE ADDED      NAME OF FILE/FOLDER                             SHORT DESCRIPTION OF CONTENTS
============    ============================================    =================================================================================
20201124	fairness_eric.Rproj				This is the R project, that needs to be opened, so the data, outputs and the 
								scripts are automatically connected. The scripts will find the raw data and the 
								outputs will be saved in the appropriate folder.


HOW TO USE THE R PROJECT
------------------------
1. Download the zip file 'fairness_eric.Rproj' and extract all files. Save the folder locally, not on a server. That might cause problems.
2. Open the RPROJ File 'fairness_eric'.
3. Go to 'Files' and open '3.1_fairness_analysis.R' in the scripts folder.
4. Run this script from top to bottom (I recommend running it line by line, so you can follow the whole process). 
   4.1. At the beginning of the script, you run three other scripts automatically, namely '1.1_fairness_cleaning', '1.2_fairness_cleaning_func'
        and '3.2_fairness_analysis_func'. In this process, also the raw data '01_fairness_wastewater_planning_rawdata.xlsx' is loaded automatically. 
   4.2. When running the scripts for the first time, you might have to load missing packages with load.packages().
5. If you are interested in the assumptions, that were tested, open '2.1_fairness_assumptions' instead of '3.1_fairness_analysis.R' in step 3.
   This file also runs the cleaning scripts and the needed functions automatically. 
