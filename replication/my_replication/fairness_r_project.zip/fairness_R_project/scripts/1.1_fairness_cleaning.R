## ================================================================ ##
## Project:     Data Cleaning
## File:        1.1_fairness_cleaning.R
## Created:     11.06.2019
## Authors:     Sara Schmid, sara.schmid@eawag.ch
## Description: Script for data cleaning; edited for ERIC
## Last change: 24.11.2020 by Sara
## ================================================================ ##


## ================================================================ ##
#### 1. Set Up ####
## ================================================================ ##

### 1.1. Load libraries --------------------------------------------------
## ---------------------------------------------------------------- ##
library("readxl")
library("tidyverse")
library("lubridate")



### 1.2. Import data --------------------------------------------------
## ---------------------------------------------------------------- ##
## Exported from Limesurvey as: Excel File
# Headings: Question Codes
# Code Separator ;
# Responses: Answer Codes
# Convert: Y to 1, N to 0


fair_raw <- read_excel("data/01_fairness_wastewater_planning_rawdata.xlsx", na = "N/A")

#Run script with functions for data cleaning. 
source("scripts/1.2_fairness_cleaning_func.R")


## ================================================================ ##
#### 2. Clean dataset ####
## ================================================================ ##

### 2.1 Rename variables------------------------------
## ---------------------------------------------------------------- ##
   
## Rename all variables, so that they are without [].
   
fair_data <- fair_rn(fair_raw)
   

### 2.2 Delete unnecessary variables----------------------------------------------
## ---------------------------------------------------------------- ##
   
## Delete all variables that are never used (NA in all rows)
fair_data <- fair_del(fair_data)

      
### 2.3 Define Variable Levels -------------------------
## ---------------------------------------------------------------- ##
#Likertscales defined as numerical variables (is already like that in the current data file), because they will be analysed as such. For information about the meaning of the numbers consult the itemlist.

fair_data <- fair_varlevel(fair_data) 


### 2.4 Shorten variable names -------------------------
## ---------------------------------------------------------------- ##

fair_data <- fair_shortnames(fair_data)


### 2.5 categorize [other]-variables --------------------------------
# ---------------------------------------------------------------- ##
# Go through all "other"-answers and categorize answers where possible. For details see 03_fair_main_other-variables.

#education

#There is just one case (except "test sara"): "3jährige lehre". This is recoded to "2 = Basic vocational training".
fair_data <- fair_data %>%
   mutate(education = ifelse(id == 763, 2, education)) %>%
   mutate(education_other = ifelse(id == 763, NA, education_other))


#tenant

#If a participant said "both" or "was house owner until recently, now tenant", he/she was categorised as 1 = house owner, because the idea behind this categorisation is: house owners are more likely to have thought about wastewater treatment than tenants.
#"(Mit)Bewohner" and "Untermieter" were categorised as 2 = tenant. Same for a participant who is "Genossenschafter" (we decided, this is closer to tenant, than owner)

#There are two new categories for "other"-answers: 3 = apartment owner ("Wohnungsbesitzer", "Eigentumswohnung" and "Stockwerkeigentümer"), 4 = lives with parents.
fair_data <- rec_tenant_other()


#wastewater

#There is one "other"-answer: "Anschluss a das zentrale Abwassersystem der Nachbargemeinde". It was categorised as 1 = Connected to centralised wastewater system of the community.
fair_data <- fair_data %>%
   mutate(wastewater = ifelse(id == 1057, 1, wastewater)) %>%
   mutate(wastewater_other = ifelse(id == 1057, NA, wastewater_other)) %>%
# There are only 3 cases with their own package plant. The categories "2 = Own package plant" and "3 = Package plant together with a few other households" are combined.
   mutate(wastewater = ifelse(wastewater == 3, 2, wastewater)) %>%
   mutate(wastewater = ifelse(wastewater == 4, 3, wastewater)) %>%
   mutate(wastewater = ifelse(wastewater == 5, 4, wastewater)) 


#device

#"Laptop", "mac book" and "Notebook" were categorised as 1 = Computer. "Ipod" was categorised as 3 = Handy.
fair_data <- rec_device_other()


#politic

#There are 39 cases with an "other"-answer. 3 answered GLP, which is the same as 6 = GLP. 1 gave a totally non-related answer ("idiotischer test"), which is recoded to "no answer".
#Everyone else gets recoded to one of the new categories "10 = don't know", "11 = mix / depending on topic", recode to new cat "12 = none" or "13 = not allowed to vote". For details s. 03_fair_main_other-variables.
fair_data <- rec_politic_other()




### 2.6 Add value labels -----------------------------------------------
# ---------------------------------------------------------------- ##
fair_data$sex <- factor(fair_data$sex,
                        levels = c(1,2),
                        labels = c("Male", "Female"))


fair_data$age <- factor(fair_data$age,
                           levels = c(1,2,3,4,5),
                           labels = c("18-29", "30-39", "40-49", "50-59", "60-69")) 


fair_data$education <- dplyr::recode(fair_data$education, "-oth-" = "6") 
fair_data$education <- factor(fair_data$education,
                                 levels = c(1,2,3,4,5,6),
                                 labels = c("Secondary school", "Basic vocational training", "Highschool", "Higher vocational training", "University degree", "other"))


fair_data$city <- dplyr::recode(fair_data$city, "7" = "6") #there are only 3 cases with More than 500'000; to small for regression (later). These 3 cases are included in the group "100'000 or more)
fair_data$city[fair_data$city == 99] <- "7"

fair_data$city <- factor(fair_data$city,
                         levels = c(1,2,3,4,5,6,7),
                         labels = c("Less than 2000", "2000 to 4999", "5000 to 19999", "20000 to 49999", "50000 to 99999", "100000 or more", "Don't know"))  


fair_data$tenant <- dplyr::recode(fair_data$tenant, "-oth-" = "5")
fair_data$tenant <- factor(fair_data$tenant,
                           levels = c(1,2,3,4,5), #add new categories for recoding of "other"-answers (s. below).
                           labels = c("House owner", "Tenant", "Apartment owner", "lives with parents", "other"))  


fair_data$wastewater <- dplyr::recode(fair_data$wastewater, "-oth-" = "6", "99" = "5") 
fair_data$wastewater <- factor(fair_data$wastewater,
                                  levels = c(1,2,3,4,5,6),
                                  labels = c("Connected to centralised wastewater system of the community", "Package plant (own or together with a few other households)", "Own drainless pit", "Wastewater gets disposed with liquid manure to the fields", "Don't know", "other"))


fair_data$device <- dplyr::recode(fair_data$device, "-oth-" = "4") 
fair_data$device <- factor(fair_data$device,
                              levels = c(1,2,3,4),
                              labels = c("Computer", "Tablet", "Smartphone", "other")) 


fair_data$politic <- dplyr::recode(fair_data$politic, "98" = "9", "-oth-" = "14") #98 was no answer, which is now coded as 9.
fair_data$politic <- factor(fair_data$politic,
                           levels = c(1,2,3,4,5,6,7,8,9,10,11,12,13,14), #add new categories for recoding of "other"-answers (s.below).
                           labels = c("SVP", "SP", "FDP", "CVP", "Gruene", "GLP", "BDP", "EVP", "No answer", "Don't know", "Mix / depending on topic", "None", "Not allowed to vote", "other")) 


### 2.7 Reorder factors and define baseline -------------------------
# ---------------------------------------------------------------- ##
#age : baseline: 1 = 18-29
fair_data$age <- fct_relevel(fair_data$age, "18-29")
levels(fair_data$age)

#city : baseline: 1 = Less than 2000
fair_data$city <- fct_relevel(fair_data$city, "Less than 2000")
levels(fair_data$city)

#education : baseline: 1 = Secondary school
fair_data$education <- fct_relevel(fair_data$education, "Secondary school")
levels(fair_data$education)


### 2.8 Add variables -----------------------------------------------
# ---------------------------------------------------------------- ##
#survey complete? 1 = survey completed, 0 = not completed.
fair_data <- fair_complete(fair_data) 
#Filter: only keep participants with completed survey.
fair_data <- fair_data %>%
   filter(complete == 1)

#Create variable, that marks datasets with usable data (usable). 1 = usable, 0 = not usable, and filter: only keep usable data.
fair_data <- fair_usable(fair_data) 
fair_data <- fair_data %>% #mark cases as unusable, if faster than half the mean.
   mutate(usable = ifelse(interviewtime < (mean(interviewtime)/2), 0, usable))


#create variable, that shows whether the quiz answers (in beginning; "test", whether they read it concentrated) were  right or not. 0 = both wrong, 1 = one wrong, one right, 2 = both right.
fair_data <- fair_quizright(fair_data)

#create variable, that shows how many knowledge points a participant got. Max possible: 8 points.
fair_data <- fair_knowledge_points(fair_data)

#create variable for politic as a 3-point categorisation: left, centre, right.
#1 = left: SP, Gruene, Piraten, Alternative Liste
#2 = center: FDP, CVP, GLP, EVP, BDP, LdU, LDP
#3 = right: SVP, EDU, SD, 
#4 = undefined: No answer, Don't know, Mix / depending on topic, None, Not allowed to vote.
fair_data <- create_politic_lcr()
fair_data$politic_lcr <- factor(fair_data$politic_lcr,
                               levels = c(1,2,3,4),
                               labels = c("left", "center", "right", "undefined"))
#Reorder factors and define baseline: Baseline : 2 = center.
fair_data$politic_lcr <- fct_relevel(fair_data$politic_lcr, "center")
levels(fair_data$politic_lcr)

#### 3. Create datasets
## ================================================================ ##

### 3.1 Create dataset with only the usable data in it --------------
# ---------------------------------------------------------------- ##
fair_data_usable <- fair_data %>%
   filter(usable == 1)

### 3.2 Create datafile for quantitative analysis -----
# ---------------------------------------------------------------- ##
fair_data_quant <- fair_data_usable %>%
   select(id, sex, age, education, city, cursit1, gradfairEq, gradfairEt, gradfairNe, pilotfairchan, pilotfairexpl, pilotfairnoex, pilotfairintern, testfairEq, testfairEt, testalloc, tenant, wastewater, device, reward, religion, engagement, finance, politic, knowledge1, knowledge1howlong, interviewtime, quizright, canalisation, health, stm1, stm2, stm3, stm4, stm5, cost, knowledge_points, politic_lcr) 

#Clean up Environment.
rm(list = ls()[!ls() %in% c("fair_data_quant")])


   
## ================================================================ ##
####  END ####
## ================================================================ ##
