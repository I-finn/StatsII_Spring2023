## ================================================================ ##
## Project:     Data Cleaning Fairness Survey
## File:        1.2_fairness_cleaning_func.R
## Created:     11.06.2019
## Authors:     Sara Zürcher, sara.zuercher@eawag.ch
## Description: Functions, that are needed in the script...
##                ...1.1_fairness_cleaning; edited for ERIC
## Last change: 03.09.2019 by Sara
## ================================================================ ##


## ================================================================ ##
#### 2. Clean dataset ####
## ================================================================ ##

### 2.1 Rename variables------------------------------
## ---------------------------------------------------------------- ##
   
## Rename all variables, so that they are without [].
   
fair_rn <- function(data){
   data %>%
   rename_all(.funs = funs(sub(pattern = "[", "_", x = ., fixed = TRUE))) %>%
   rename_all(.funs = funs(sub(pattern = "]", "", x = ., fixed = TRUE))) 
}
   

### 2.2 Delete unnecessary variables----------------------------------------------
## ---------------------------------------------------------------- ##
   
## Delete all variables that are never used (NA in all rows)
fair_del <- function(data) {
   data %>%
   select_if(function(x) any(!is.na(x))) %>%
   select(-contains("Time", ignore.case = FALSE), ## Delete the time per question variables. most of them are missing anyway and got deleted in the step before. Keeping interviewtime as the total time needed to fill in the whole survey.
          -startlanguage, #"de" for everyone
          -submitdate, #same value as datestamp
          -sex_other) #wurde nur von testSara gebraucht. Dieser Fall wird später sowieso gelöscht.
}

### 2.3 Define Variable Levels -------------------------
## ---------------------------------------------------------------- ##
#Likertscales defined as numerical variables (is already like that in the current data file), because they will be analysed as such. For information about the meaning of the numbers consult the itemlist.

fair_varlevel <- function(data) {
   data %>%
   #define form of date/time variables:
   mutate(startdate = parse_date_time(startdate, orders = "YmdHMS"),
          datestamp = parse_date_time(datestamp, orders = "YmdHMS")) %>% 
   #define categorical variables as characters
   mutate_at(vars(starts_with("age"), starts_with("education"), starts_with("city"), "knowledge1", starts_with("canalisation"), starts_with("statements"), starts_with("cost")), funs(as.character)) %>% 
   #define interviewtime as numeric variable (in seconds). This code looses one decimal and only keeps one. That's ok, since we're not interested in smaller scale than seconds anyway.
   mutate(interviewtime = as.numeric(interviewtime))
}
                  

### 2.4 Shorten variable names -------------------------
## ---------------------------------------------------------------- ##

fair_shortnames <- function(data){
   data %>%
   rename(cursit1 = cursit1_cursit1) %>%
   rename_at(.vars = vars(starts_with("gradfair")), .funs = funs(sub(pattern = "_grad", "", x = ., fixed = TRUE))) %>%
   rename_at(.vars = vars(starts_with("gradwhy")), .funs = funs(sub(pattern = "_gradwhy", "", x = ., fixed = TRUE))) %>%
   rename_at(.vars = vars(starts_with("pilotfair")), .funs = funs(sub(pattern = "_pil", "", x = ., fixed = TRUE)))%>%
   rename_at(.vars = vars(starts_with("pilotwhy")), .funs = funs(sub(pattern = "_pilwhy", "", x = ., fixed = TRUE))) %>%
   rename_at(.vars = vars(starts_with("testfair")), .funs = funs(sub(pattern = "_test", "", x = ., fixed = TRUE))) %>%
   rename_at(.vars = vars(starts_with("testwhy")), .funs = funs(sub(pattern = "_testwhy", "", x = ., fixed = TRUE))) %>%
   rename_at(.vars = vars(starts_with("testalloc")), .funs = funs(sub(pattern = "_alloc1", "", x = ., fixed = TRUE))) %>%
   rename_at(.vars = vars(starts_with("statements")), .funs = funs(sub(pattern = "statements_", "", x = ., fixed = TRUE))) %>%
   rename(reward = reward_reward, religion = religion_reward, engagement = engagement_reward, finance = finance_reward)
}
   
### 2.5 categorize [other]-variables --------------------------------
# ---------------------------------------------------------------- ##

#tenant
rec_tenant_other <- function() {
   fair_data %>%
   mutate(tenant = ifelse(id == 700 |
                             id == 239 |
                             id == 828 |
                             id == 833 |
                             id == 722, 1, tenant)) %>%
   mutate(tenant = ifelse(id == 740 |
                             id == 419 |
                             id == 550 |
                             id == 85, 2, tenant)) %>%
   mutate(tenant = ifelse(id == 974 |
                             id == 338 |
                             id == 411 |
                             id == 423 |
                             id == 373 |
                             id == 386 |
                             id == 450 |
                             id == 319 |
                             id == 601 |
                             id == 1172 |
                             id == 459 |
                             id == 934 |
                             id == 1004 |
                             id == 603 |
                             id == 746 |
                             id == 792 |
                             id == 888 |
                             id == 735 |
                             id == 1051 |
                             id == 892 |
                             id == 361 |
                             id == 356 |
                             id == 998 |
                             id == 358 |
                             id == 935 |
                             id == 478 |
                             id == 929 |
                             id == 360, 3, tenant)) %>%
   mutate(tenant = ifelse(id == 533 |
                             id == 212 |
                             id == 560 |
                             id == 227 |
                             id == 462 |
                             id == 117 |
                             id == 584 |
                             id == 547, 4, tenant)) %>%
   mutate(tenant_other = ifelse(id == 700 |
                                   id == 239 |
                                   id == 828 |
                                   id == 833 |
                                   id == 722 |
                                   id == 740 |
                                   id == 419 |
                                   id == 550 |
                                   id == 85 |
                                   id == 974 |
                                   id == 338 |
                                   id == 411 |
                                   id == 423 |
                                   id == 373 |
                                   id == 386 |
                                   id == 450 |
                                   id == 319 |
                                   id == 601 |
                                   id == 1172 |
                                   id == 459 |
                                   id == 934 |
                                   id == 1004 |
                                   id == 603 |
                                   id == 746 |
                                   id == 792 |
                                   id == 888 |
                                   id == 735 |
                                   id == 1051 |
                                   id == 892 |
                                   id == 361 |
                                   id == 356 |
                                   id == 998 |
                                   id == 358 |
                                   id == 935 |
                                   id == 478 |
                                   id == 929 |
                                   id == 360 |
                                   id == 533 |
                                   id == 212 |
                                   id == 560 |
                                   id == 227 |
                                   id == 462 |
                                   id == 117 |
                                   id == 584 |
                                   id == 547, NA, tenant_other))
}

#device
rec_device_other <- function() {
   fair_data %>%
      mutate(device = ifelse(id == 236 |
                             id == 833 |
                             id == 423 |
                             id == 319 |
                             id == 782 |
                             id == 232 |
                             id == 484 |
                             id == 947 |
                             id == 1037 |
                             id == 1129 |
                             id == 279 |
                             id == 182 |
                             id == 434 |
                             id == 974 |
                             id == 843 |
                             id == 411, 1, device)) %>%
      mutate(device = ifelse(id == 287, 3, device)) %>%
      mutate(device_other = ifelse(id == 236 |
                                   id == 833 |
                                   id == 423 |
                                   id == 319 |
                                   id == 782 |
                                   id == 232 |
                                   id == 484 |
                                   id == 947 |
                                   id == 1037 |
                                   id == 1129 |
                                   id == 279 |
                                   id == 182 |
                                   id == 434 |
                                   id == 974 |
                                   id == 843 |
                                   id == 411 |
                                   id == 287, NA, device_other))
}

#politic
rec_politic_other <- function() {fair_data %>%
   mutate(politic = ifelse(id == 213 | 
                              id == 286 | 
                              id == 921, 6, politic)) %>%
   mutate(politic = ifelse(id == 1013, 9, politic)) %>%
   mutate(politic = ifelse(id == 239 |
                              id == 722, 10, politic)) %>%   
   mutate(politic = ifelse(id == 888 |
                              id == 874 |
                              id == 894 |
                              id == 956 |
                              id == 270 |
                              id == 1047 |
                              id == 930 |
                              id == 465, 11, politic)) %>%
   mutate(politic = ifelse(id == 735 |
                              id == 973 |
                              id == 630 |
                              id == 305 |
                              id == 517 |
                              id == 989 |
                              id == 1014 |
                              id == 1022 |
                              id == 369 |
                              id == 496 |
                              id == 752 |
                              id == 950 |
                              id == 599 |
                              id == 803 |
                              id == 785, 12, politic)) %>%
   mutate(politic = ifelse(id == 187 |
                              id == 1099 |
                              id == 199, 13, politic)) %>%
   mutate(politic_other = ifelse(id == 213 | 
                                    id == 286 | 
                                    id == 921 |
                                    id == 1013|
                                    id == 239 |
                                    id == 722 |
                                    id == 888 |
                                    id == 874 |
                                    id == 894 |
                                    id == 956 |
                                    id == 270 |
                                    id == 1047 |
                                    id == 930 |
                                    id == 465 |
                                    id == 735 |
                                    id == 973 |
                                    id == 630 |
                                    id == 305 |
                                    id == 517 |
                                    id == 989 |
                                    id == 1014 |
                                    id == 1022 |
                                    id == 369 |
                                    id == 496 |
                                    id == 752 |
                                    id == 950 |
                                    id == 599 |
                                    id == 803 |
                                    id == 785| 
                                    id == 187 |
                                    id == 1099 |
                                    id == 199, NA, politic_other))
}



### 2.8 Add variables -----------------------------------------------
# ---------------------------------------------------------------- ##
#survey complete? 1 = survey completed, 0 = not completed.
fair_complete <- function(data){
   data %>%
   mutate(complete = ifelse(lastpage == 21, 1, 0))
}

#Create variable, that marks datasets with usable data (usable). 1 = usable, 0 = not usable. 
fair_usable <- function(data){
    data <- data %>%
#excluded, because answers are in italian.
   mutate(usable = ifelse(id == 1056 | id == 451, 0, 1)) %>%
#excluded, because only random letters or signs in textboxes, copy-pasted 
       #the same thing in every textbox. Plus: a lot of them just clicked 
       #through the ratings (= same rating for every option). 
   mutate(usable = ifelse(id == 143 | 
                             id == 968 | 
                             id == 806 | 
                             id == 594 | 
                             id == 581 | 
                             id == 374 | 
                             id == 372 | 
                             id == 521 | 
                             id == 1140 | 
                             id == 1029 | 
                             id == 463 | 
                             id == 425 | 
                             id == 105 | 
                             id == 280 | 
                             id == 1214 | 
                             id == 873 | 
                             id == 911 | 
                             id == 703 | 
                             id == 1030 | 
                             id == 590 | 
                             id == 197 | 
                             id == 924 | 
                             id == 486 | 
                             id == 525 | 
                             id == 187 | 
                             id == 134 | 
                             id == 209 | 
                             id == 467 | 
                             id == 433 | 
                             id == 390 | 
                             id == 1067 | 
                             id == 721 | 
                             id == 896 | 
                             id == 402 | 
                             id == 649 | 
                             id == 712 | 
                             id == 992 | 
                             id == 470 | 
                             id == 1075 | 
                             id == 1081 | 
                             id == 767 | 
                             id == 214 | 
                             id == 750 | 
                             id == 958 | 
                             id == 973 | 
                             id == 281 | 
                             id == 1137 | 
                             id == 244 | 
                             id == 1199 | 
                             id == 361 | 
                             id == 116 | 
                             id == 684 | 
                             id == 408 | 
                             id == 623 | 
                             id == 1013 | 
                             id == 507 | 
                             id == 972, 0, usable)) %>%
   
#excluded, because very weak content (repetition of vignette) in testboxes and or random letters/signs in the textboxes.
   mutate(usable = ifelse(id == 634 | 
                             id == 813 | 
                             id == 220 | 
                             id == 224 | 
                             id == 231 | 
                             id == 819 | 
                             id == 519 | 
                             id == 226 | 
                             id == 800 | 
                             id == 737 | 
                             id == 131 | 
                             id == 983, 0, usable)) %>%
       filter(usable == 1) %>% 
       mutate(usable = ifelse(interviewtime < (mean(interviewtime)/2), 0, usable))
}

#create variable, that shows whether the quiz answers (in beginning; "test", whether they read it concentrated) were answered right or not. 0 = both wrong, 1 = one wrong, one right, 2 = both right.
#mutate(quizsit_wrong =)
quizsit1false <- c(1,3,4)
quizsit2false <- c(1,2,4)
fair_quizright <- function(data){
   data %>%
      mutate(quizright = case_when(quizsit1 %in% quizsit1false & quizsit2 %in% quizsit2false ~ 0, 
                                   quizsit1 %in% quizsit1false & !(quizsit2 %in% quizsit2false) | !(quizsit1 %in% quizsit1false) & quizsit2 %in% quizsit2false ~ 1,
                                   !(quizsit1 %in% quizsit1false) & !(quizsit2 %in% quizsit2false) ~ 2))
}

#create variable, that shows how many knowledge points a participant got. Max possible: 8 points.
fair_knowledge_points <- function(data){
   data %>%
      mutate(canalisation_points = if_else(canalisation == 3, 1, 0)) %>%
      mutate(health_points = if_else(health == 3, 1, 0)) %>%
      mutate(stm1_points = if_else(stm1== 1, 1, 0)) %>%
      mutate(stm2_points = if_else(stm2 == 1, 1, 0)) %>%
      mutate(stm3_points = if_else(stm3 == 1, 1, 0)) %>%
      mutate(stm4_points = if_else(stm4 == 0, 1, 0)) %>%
      mutate(stm5_points = if_else(stm5 == 1, 1, 0)) %>%
      mutate(cost_points = if_else(cost == 4, 1, 0)) %>%
      mutate(knowledge_points = canalisation_points + health_points + stm1_points + stm2_points + stm3_points + stm4_points + stm5_points + cost_points) 
}

#create variable for politic as a 3-point categorisation: left, centre, right.
create_politic_lcr <- function(){
   fair_data %>%
      mutate(politic_lcr = 0) %>%
      mutate(politic_lcr = ifelse(politic == "SP" |
                                     politic == "Gruene", 1, politic_lcr)) %>%
      mutate(politic_lcr = ifelse(id == 1158 | #participant with Piraten
                                     id == 1054, 1, politic_lcr)) %>% #participant with Alternative Liste
      mutate(politic_lcr = ifelse(politic == "FDP" |
                                     politic == "CVP" |
                                     politic == "GLP" |
                                     politic == "EVP" |
                                     politic == "BDP", 2, politic_lcr)) %>%
      mutate(politic_lcr = ifelse(id == 525 |  #participant with LdU
                                     id == 929, 2, politic_lcr)) %>%  #participant with LDP
      mutate(politic_lcr = ifelse(politic == "SVP", 3, politic_lcr)) %>%
      mutate(politic_lcr = ifelse(id == 75 |  #participant with EDU
                                     id == 657 |  #participant with edu
                                     id == 1124, 3, politic_lcr)) %>%  #participant with SD
      mutate(politic_lcr = ifelse(politic == "No answer" |
                                     politic == "Don't know" |
                                     politic == "Mix / depending on topic" |
                                     politic == "None" |
                                     politic == "Not allowed to vote", 4, politic_lcr)) 
}


## ================================================================ ##
####  END ####
## ================================================================ ##

