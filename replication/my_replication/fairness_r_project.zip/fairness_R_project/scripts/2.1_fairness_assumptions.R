## ================================================================ ##
## Project:     Check Assumptions for Data Analysis
## File:        2.1_fairness_assumptions.R
## Created:     15.07.2019
## Authors:     Sara Schmid, sara.schmid@eawag.ch
## Description: Script for checking assumptions for...
##               ...data analysis; edited for ERIC
## Last change: 03.09.2019 by Sara
## ================================================================ ##

#### 1. Set Up ----

### 1.1. Update dates ----

#' Update the dates (yymmdd) in this file (2.1_fairness_assumptions) and in the functions file (2.2_fairness_assumptions_func.



### 1.2. Import data ----

#' Run the script "datacleaning" to get the datafile needed for the following analyses.
source("scripts/1.1_fairness_cleaning.R")
#' Run the script with the functions needed for the following analyses. 
source("scripts/2.2_fairness_assumptions_func.R")



### 1.3. Load libraries ----
library("Hmisc")
library("nlme")
library("car")
library("xlsx")



### 1.4. Create datasets ----
#' Dataset in long format with all gradfair variables:
gradfair_data <- fair_data_quant %>%
   select(id, gradfairEq, gradfairEt, gradfairNe) %>%
   gather(approach, fairness, gradfairEq:gradfairNe)

#' Dataset in long format with all testfair variables:
testfair_data <- fair_data_quant %>%
   select(id, testfairEq, testfairEt) %>%
   gather(approach, fairness, testfairEq:testfairEt)

#' Dataset in long format with all pilotfair variables:
pilotfair_data <- fair_data_quant %>%
   select(id, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern) %>%
   gather(approach, fairness, pilotfairnoex:pilotfairintern)

#' Define order from unfairest to fairest:
pilotfair_data$approach <- factor(pilotfair_data$approach,
                                  levels = unique(pilotfair_data$approach),
                                  labels = c("pilotfairnoex", "pilotfairchan", "pilotfairexpl", "pilotfairintern")) 


#### 2. Univariate outliers ----

#' *Look at z-scores. Z-scores > 3.29 are potential outliers.*

#' Demographics.
sum(scale(as.numeric(fair_data_quant$age), center = TRUE, scale = TRUE) > 3.29)
sum(scale(as.numeric(fair_data_quant$city), center = TRUE, scale = TRUE) > 3.29, na.rm = T)
sum(scale(fair_data_quant$engagement, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$finance, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$knowledge_points, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$knowledge1howlong, center = TRUE, scale = TRUE) > 3.29, na.rm = TRUE)
sum(scale(fair_data_quant$quizright, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$religion, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$reward, center = TRUE, scale = TRUE) > 3.29)

sum(scale(fair_data_quant$interviewtime, center = TRUE, scale = TRUE) > 3.29)
subset(fair_data_quant, ((fair_data_quant$interviewtime - mean(fair_data_quant$interviewtime)) / sd(fair_data_quant$interviewtime)) > 3.29)
#' There are 8 univariate outliers in interviewtime. Not important, because interviewtime is not used for any analyses.

#' Current situation (cursit).
sum(scale(fair_data_quant$cursit1, center = TRUE, scale = TRUE) > 3.29)

#' Gradual implementation of package plants (gradfair; distributive justice - individual level).
sum(scale(fair_data_quant$gradfairEq, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$gradfairEt, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$gradfairNe, center = TRUE, scale = TRUE) > 3.29)

#' Test phase for package plants (testfair; distributive justice - collective level).
sum(scale(fair_data_quant$testfairEq, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$testfairEt, center = TRUE, scale = TRUE) > 3.29)

#' Pilot project with package plants (pilotfair; procedural justice).
sum(scale(fair_data_quant$pilotfairnoex, center = TRUE, scale = TRUE) > 3.29)
subset(fair_data_quant, ((fair_data_quant$pilotfairnoex - mean(fair_data_quant$pilotfairnoex)) / sd(fair_data_quant$pilotfairnoex)) > 3.29) # Like suggested by Tabachnik and Fidell (2007), we assign the extreme score a raw score on this variable that is one unit larger than the next most extreme score in the distribution, i.e. it's now 5 instead of 6.
fair_data_quant <- fair_data_quant %>%
   mutate(pilotfairnoex = ifelse(id == 905, 5, pilotfairnoex))
sum(scale(fair_data_quant$pilotfairchan, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$pilotfairexpl, center = TRUE, scale = TRUE) > 3.29)
sum(scale(fair_data_quant$pilotfairintern, center = TRUE, scale = TRUE) > 3.29)



#### 3. Correlation matrix ----

#' Pearson correlation for all numeric variables and all categorical variables with only 0-1 coding (gender, knowledge1)
#' Select variables and save in new data frame:
cor_data_num <- fair_data_quant %>%
   subset(select = c(sex, reward, religion, engagement, finance, knowledge1, knowledge1howlong, interviewtime, quizright, knowledge_points, cursit1, gradfairEq, gradfairEt, gradfairNe, pilotfairchan, pilotfairexpl, pilotfairnoex, pilotfairintern, testfairEq, testfairEt, testalloc))

#' Recode sex, so it's 0-1 instead of 1-2 (sex) and change variable level to numeric (sex and knowledge1)
cor_data_num$sex <- as.numeric(cor_data_num$sex)
cor_data_num <- cor_data_num %>%
   mutate(sex = ifelse(sex == 1, 0, sex)) %>%
   mutate(sex = ifelse(sex == 2, 1, sex))
cor_data_num$knowledge1 <- as.numeric(cor_data_num$knowledge1)

#' Calculate matrix and save r and p in two different sheets of the same excel file: 
cor_matrix_num <- rcorr(as.matrix(cor_data_num), type = "pearson")

cor_matrix_num[["r"]] <- round(cor_matrix_num[["r"]], 3)
cor_matrix_num[["P"]] <- round(cor_matrix_num[["P"]], 3)

write.xlsx(cor_matrix_num[["r"]], file = "output/190903_cormatrix.xlsx", 
           sheetName = "Pearson - r",
           col.names = TRUE, row.names = TRUE, append = FALSE)
write.xlsx(cor_matrix_num[["P"]], file = "output/190903_cormatrix.xlsx", 
           sheetName = "Pearson - p",
           col.names = TRUE, row.names = TRUE, append = TRUE)

#' *For Output see Excel file*.  

#' Spearman correlation for all ordinal variables (also compared to the numeric ones)
#' Select variables and save in new data frame:
cor_data_ord <- fair_data_quant %>%
   subset(select = c(sex, reward, religion, engagement, finance, knowledge1, knowledge1howlong, interviewtime, quizright, knowledge_points, cursit1, gradfairEq, gradfairEt, gradfairNe, pilotfairchan, pilotfairexpl, pilotfairnoex, pilotfairintern, testfairEq, testfairEt, testalloc, education, age, city))

#' Recode sex, so it's 0-1 instead of 1-2 (sex) and change variable level to numeric (sex, age, city, education and knowledge1)
cor_data_ord$sex <- as.numeric(cor_data_ord$sex)
cor_data_ord <- cor_data_ord %>%
   mutate(sex = ifelse(sex == 1, 0, sex)) %>%
   mutate(sex = ifelse(sex == 2, 1, sex))
cor_data_ord$age <- as.numeric(cor_data_ord$age)
cor_data_ord$city <- as.numeric(cor_data_ord$city)
cor_data_ord$education <- as.numeric(cor_data_ord$education)
cor_data_ord$knowledge1 <- as.numeric(cor_data_ord$knowledge1)

#' Calculate matrix and save r and p in two different sheets of the same excel file as before: 
cor_matrix_ord <- rcorr(as.matrix(cor_data_ord), type = c("spearman"))

cor_matrix_ord[["r"]] <- round(cor_matrix_ord[["r"]], 3)
cor_matrix_ord[["P"]] <- round(cor_matrix_ord[["P"]], 3)

write.xlsx(cor_matrix_ord[["r"]], file = "output/190903_cormatrix.xlsx", 
           sheetName = "Spearman - r",
           col.names = TRUE, row.names = TRUE, append = TRUE)
write.xlsx(cor_matrix_ord[["P"]], file = "output/190903_cormatrix.xlsx", 
           sheetName = "Spearman - p",
           col.names = TRUE, row.names = TRUE, append = TRUE)

#' *For Output see separate Excel file*.  
#' To get one big matrix (like in the paper), you have to integrate the Files from Pearson and Spearman into one file.



#### 4. Checking assumptions for tests concerning comparisons of approaches ----
#' Assumptions for regression and all regression-based methods (as in Andy Field, 2012):  
#' - Variable types: predictors: interval or categorical (two categories); outcome: intervals, unbound (so data from 6-point Likertscale should range from 1 to 6, not only from 2 to 5)  
#' - Non-zero variance  
#' - No perfect multicollinearity; Check correlation matrix! Or use vif("name of regression model", S. p.293)  
#' - Predictors are uncorrelated with external variables  
#' - Homoscedasticity, s. normally distributed errors (fitted vs. residuals) plot("name of regression model")  
#' - Independent errors;   
#' - Normally distributed errors; look at studentized residuals using rstudent("name of regression model") and plots, S. p.297; plot studentized residuals against fitted (predicted) values  
#' - Independence; Use durbinWatsonTest("name of regression model"); result should be not significant (p-value might be different everytime, because of bootstrapping)  
#' - Linearity; use plot("name of regression model")


### 4.2. gradfair - H1.1, H1.2 and RQ1.3 ----

#' Compare baseline model with only an intercept to a model that allows intercepts to vary over contexts. If random-Intercept-Model is not better than baseline model, it doesn't need a multilevel linear model.
f9_which_model(gradfair_data)
#' AIC and BIC are slightly higher in m1. Also, the ANOVA shows, that a random intercept is not needed. Therefore we choose a one-way repeated measures ANOVA. The only assumption here is sphericity.

#' We will also conduct a Bonferoni-corrected posthoc test. Assumption for paired t-tests: distribution of differences between scores should be normal.  

#' Create wide format data:
gradfair_data_wide <- fair_data_quant %>%
   select(id, gradfairEq, gradfairEt, gradfairNe)
#' Compute differences between scores
gradfair_data_wide <- gradfair_data_wide %>%
   mutate(diffEqEt = gradfairEq - gradfairEt)%>%
   mutate(diffEqNe = gradfairEq - gradfairNe)%>%
   mutate(diffEtNe = gradfairEt - gradfairNe)

#' Explore the distribution of the differences
#' Create long format:
gradfair_data_diff <- gradfair_data_wide %>%
   select(id, diffEqEt, diffEqNe, diffEtNe) %>%
   gather(difference, score, diffEqEt:diffEtNe)

#View barcharts of differences
gradfair_data_diff$difference <- factor(gradfair_data_diff$difference, labels = c("Difference Equality-Equity", "Difference Equality-Need", "Difference Equity-Need"))
difflabels <- c("Difference Equality-Equity", "Difference Equality-Need", "Difference Equity-Need")
f11_barcharts_diff(gradfair_data_diff)

#' Bar charts look like a normal distribution. We will calculate a paired t-test.



### 4.3. testfair - H2.1 ----
#' Compare baseline model with only an intercept to a model that allows intercepts to vary over contexts. If random-Intercept-Model is not better than baseline model, it doesn't need a multilevel linear model.
f9_which_model(testfair_data)
#' AIC and BIC are slightly higher in m1. Also, the ANOVA shows, that a random intercept is not needed. Therefore we choose a paired t-test.  

#' Assumption for paired t-tests: distribution of differences between scores should be normal.  

#' Create wide format data
testfair_data_wide <- fair_data_quant %>%
   select(id, testfairEq, testfairEt, testalloc)
testfair_data_wide <- testfair_data_wide %>%
   mutate(diffEqEt = testfairEq - testfairEt)

#' View barcharts of differences
testfair_data_wide %>%
   ggplot(aes(x = diffEqEt))+ 
   geom_bar() +
   labs(x = "Difference between the approaches", y = "Count", title = "Differences between the approaches")

#' Histogram shows a non-normal distribution. 
#' We choose a robust method: Wilcoxon signed-rank test.



### 4.4. testfair - H2.2 ----
#' H2.2: The share allocated to Weihermatten is more than 50% (= 11).
#' A t-test is suitable if the data is believed to be drawn from a normal distribution, or if the sample size is large. (Reference: http://www.instantr.com/2012/12/29/performing-a-one-sample-t-test-in-r/) 

#' Delete inconsistent cases from the data set:
testfair_data_wide_no_incons <- f13_del_incons_cases() 

#' Look at the distribution:
testfair_data_wide_no_incons %>%
   ggplot(aes(x = testalloc))+ 
   geom_bar() +
   labs(x = "Distribution of testalloc", y = "Count", title = "Distribution of the allocation of shares to W and A")
#' Histogram shows a non-normal distribution. 
#' We choose a robust method: Wilcoxon signed-rank test!



### 4.5. pilotfair - H3.1 - H3.4 ----
#' Compare baseline model with only an intercept to a model that allows intercepts to vary over contexts. If random-Intercept-Model is not better than baseline model, it doesn't need a multilevel linear model.
f9_which_model(pilotfair_data)
#' AIC and BIC are higher in m0. Also, the ANOVA shows, that a random intercept is better than the more basic model. Therefore we choose a random intercept model.

#' We will also conduct a Bonferoni-corrected posthoc test. Assumption for paired t-tests: distribution of differences between scores should be normal.  

#' Create wide format data:
pilotfair_data_wide <- fair_data_quant %>%
   select(id, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern)
pilotfair_data_wide <- pilotfair_data_wide %>%
   mutate(diffnoexchan = pilotfairnoex - pilotfairchan)%>%
   mutate(diffnoexexpl = pilotfairnoex - pilotfairexpl)%>%
   mutate(diffnoexintern = pilotfairnoex - pilotfairintern) %>%
   mutate(diffchanexpl = pilotfairchan - pilotfairexpl) %>%
   mutate(diffchanintern = pilotfairchan - pilotfairintern) %>%
   mutate(diffexplintern = pilotfairexpl - pilotfairintern)

#' create long format:
pilotfair_data_diff <- pilotfair_data_wide %>%
   select(id, diffnoexchan, diffnoexexpl, diffnoexintern, diffchanexpl, diffchanintern, diffexplintern) %>%
   gather(difference, score, diffnoexchan:diffexplintern)

#' View barcharts of differences:
pilotfair_data_diff$difference <- factor(pilotfair_data_diff$difference, labels = c("Difference No explanation-Chance", "Difference No explanation-Explanation", "Difference No explanation-Intern", "Difference Chance-Explanation", "Difference Chance-Intern", "Difference Explanation-Intern"))
difflabels <- c("Difference No explanation-Chance", "Difference No explanation-Explanation", "Difference No explanation-Intern", "Difference Chance-Explanation", "Difference Chance-Intern", "Difference Explanation-Intern")
f11_barcharts_diff(pilotfair_data_diff)

#' Not all histograms show an approximate normal distribution 
#' We choose a robust method: Wilcoxon signed-rank test.


#### 5. Checking assumptions for tests concerning explanatory variables (regression analyses) ----

### 5.1. gradfair - RQ1.4 ----
#' Prepare data
gradfair_RQ1.4_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, gradfairEq, gradfairEt, gradfairNe) %>%
   filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

gradfair_RQ1.4_data <- gradfair_RQ1.4_data %>%
   mutate(diffEqEt = gradfairEq - gradfairEt) %>%
   mutate(diffEqNe = gradfairEq - gradfairNe) %>%
   mutate(diffEtNe = gradfairEt - gradfairNe)



### 5.1.1 Model 1: all demographics in one model - EqEt ----
#' Can demographics explain the difference between Eq and Et?  
reg_all_EqEt <- lm(diffEqEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = gradfair_RQ1.4_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
gradfair_RQ1.4_data$residuals <- resid(reg_all_EqEt)
gradfair_RQ1.4_data$standardized.residuals <- rstandard(reg_all_EqEt)
gradfair_RQ1.4_data$studentized.residuals <- rstudent(reg_all_EqEt)
gradfair_RQ1.4_data$cooks.distance <- cooks.distance(reg_all_EqEt)
gradfair_RQ1.4_data$covariance.ratios <- covratio(reg_all_EqEt)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No critical values.  
#' (2)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' only 3 are critical, that's ok.  
#' (3)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 19 cases (4.03%) are critical.

#' *Cook's distance:*
gradfair_RQ1.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' *Check covariance ratios.*  
#' Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- gradfair_RQ1.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are 16 cases with covariance ratios outside the required range. 
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "grad_EqEt")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_EqEt)
#' The assumption of independent errors is NOT met: D-W statistic is significant.

#' *Check for multicollinearity.*  
#' Criteria for VIF:  
#' - largest VIF greater than 10 -> cause for concern.
#' - average VIF substantially greater than 1 -> regression might be biased.
#' - Tolerance (1/VIF) below .1 -> serious problem.
#' - Tolerance (1/VIF) below .2 -> potential problem.  
#' VIF does only consider predictors. Therefore, this analysis is the same for all models with all demographics in one model. The analysis is not repeated in the following models.
vif(reg_all_EqEt)
#'No VIF greater than 10! It's OK!
mean(vif(reg_all_EqEt))
#' The average VIF (=1.455779) is higher than 1. Is this "substantially" greater? Or is it still ok?  
#' -> https://statisticalhorizons.com/multicollinearity: "Personally, I tend to get concerned when a VIF is greater than 2.50"  
#' -> Hair, J. F. Jr., Anderson, R. E., Tatham, R. L. & Black, W. C. (1995). Multivariate Data Analysis (3rd ed). New York: Macmillan: "If VIF value exceeding 4.0, or by tolerance less than 0.2 then there is a problem with multicollinearity."
1/vif(reg_all_EqEt)
#' Tolerance is nowhere near .2, so it's OK!  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(gradfair_RQ1.4_data$standardized.residuals) 
plot(reg_all_EqEt)
#' Looks ok.



### 5.1.2. Model 2: all demographics in one model - EqNe ----

#' Can demographics explain the difference between Eq and Ne?  
reg_all_EqNe <- lm(diffEqNe ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = gradfair_RQ1.4_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
gradfair_RQ1.4_data$residuals <- resid(reg_all_EqNe)
gradfair_RQ1.4_data$standardized.residuals <- rstandard(reg_all_EqNe)
gradfair_RQ1.4_data$studentized.residuals <- rstudent(reg_all_EqNe)
gradfair_RQ1.4_data$cooks.distance <- cooks.distance(reg_all_EqNe)
gradfair_RQ1.4_data$covariance.ratios <- covratio(reg_all_EqNe)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' 1 case causes concern.
#' (2)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 7 cases are more than 1%. -> cause for concern  
#' (3)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 21 cases (4.63%) outside these borders!   

#' *Cook's distance:*
gradfair_RQ1.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- gradfair_RQ1.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 17 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "grad_EqNe")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_EqNe)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
hist(gradfair_RQ1.4_data$standardized.residuals) 
plot(reg_all_EqNe)
#'Plots look ok.



### 5.1.3 Model 3: all demographics in one model - EtNe ----

#' Can demographics explain the difference between Et and Ne?  
reg_all_EtNe <- lm(diffEtNe ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = gradfair_RQ1.4_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
gradfair_RQ1.4_data$residuals <- resid(reg_all_EtNe)
gradfair_RQ1.4_data$standardized.residuals <- rstandard(reg_all_EtNe)
gradfair_RQ1.4_data$studentized.residuals <- rstudent(reg_all_EtNe)
gradfair_RQ1.4_data$cooks.distance <- cooks.distance(reg_all_EtNe)
gradfair_RQ1.4_data$covariance.ratios <- covratio(reg_all_EtNe)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No critical values.  
#' (2)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 7 are more than 1 %. -> cause for concern  
#' (3)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' 25 cases (5.51%) outside these borders. This is a problem!

#' *Cook's distance:*
gradfair_RQ1.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.*   
#' Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- gradfair_RQ1.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are 16 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "grad_EtNe")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_EtNe)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.


#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(gradfair_RQ1.4_data$standardized.residuals) 
plot(reg_all_EtNe)
#'Plots look ok.



### 5.2. testtfair - RQ2.4 ----
#' Prepare data
testfair_RQ2.4_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, testfairEq, testfairEt) %>%
  filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

testfair_RQ2.4_data <- testfair_RQ2.4_data %>%
   mutate(diffEqEt = testfairEq - testfairEt)



### 5.2.1.  Model 4: all demographics in one model - EqEt ----
#' Can demographics explain the difference between Eq and Et?  
reg_all_EqEt <- lm(diffEqEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = testfair_RQ2.4_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
testfair_RQ2.4_data$residuals <- resid(reg_all_EqEt)
testfair_RQ2.4_data$standardized.residuals <- rstandard(reg_all_EqEt)
testfair_RQ2.4_data$studentized.residuals <- rstudent(reg_all_EqEt)
testfair_RQ2.4_data$cooks.distance <- cooks.distance(reg_all_EqEt)
testfair_RQ2.4_data$covariance.ratios <- covratio(reg_all_EqEt)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No critical values.
#' (2)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' only 1 case (0.22%) is critical, that's ok.
#' (3)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' only 13 cases (2.75%) outside these borders! 

#' *Cook's distance:*
testfair_RQ2.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.  
#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.* Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- testfair_RQ2.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are 5 cases with covariance ratios outside the required range. 
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "test_EqEt")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_EqEt)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see Model 1 (gradfair)*  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(testfair_RQ2.4_data$standardized.residuals) 
plot(reg_all_EqEt)
#' Plots look ok.


#********************************************************************#
#' Same analysis for sample with 2 correct quiz questions:

#'filter:
testfair_RQ2.4_data_q2 <- fair_data_quant %>%
   filter(quizright == 2)
testfair_RQ2.4_data_q2 <- testfair_RQ2.4_data_q2 %>%
  filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (7 cases)

#'create dataset:
testfair_RQ2.4_data_q2 <- testfair_RQ2.4_data_q2 %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, testfairEq, testfairEt)

testfair_RQ2.4_data_q2 <- testfair_RQ2.4_data_q2 %>%
   mutate(diffEqEt = testfairEq - testfairEt)

#'Define model with all demographic variables:
reg_all_EqEt_q2 <- lm(diffEqEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                      data = testfair_RQ2.4_data_q2) 

#' *Check Outliers and influential cases:*
testfair_RQ2.4_data_q2$residuals <- resid(reg_all_EqEt_q2)
testfair_RQ2.4_data_q2$standardized.residuals <- rstandard(reg_all_EqEt_q2)
testfair_RQ2.4_data_q2$studentized.residuals <- rstudent(reg_all_EqEt_q2)
testfair_RQ2.4_data_q2$cooks.distance <- cooks.distance(reg_all_EqEt_q2)
testfair_RQ2.4_data_q2$covariance.ratios <- covratio(reg_all_EqEt_q2)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
testfair_RQ2.4_data_q2 %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No critical value.
#' (2)
testfair_RQ2.4_data_q2 %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' No critical value.
#' (3)
testfair_RQ2.4_data_q2 %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' only 13 cases (2.75%) outside these borders! 

#' *Cook's distance:*
testfair_RQ2.4_data_q2 %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.  
#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.* Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- testfair_RQ2.4_data_q2 %>% 
   filter(covariance.ratios > 1+3*(25/277) | covariance.ratios < 1-3*(25/277))
covariance %>%
   count(covariance.ratios)
#' There are 212 cases with covariance ratios outside the required range. 
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "test_EqEt_q2")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_EqEt_q2)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see Model 1 (gradfair)*  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(testfair_RQ2.4_data_q2$standardized.residuals) 
plot(reg_all_EqEt_q2)
#' No normal distribution.


 
### 5.3. pilotfair - RQ3.5 ----
#' Prepare data
pilotfair_RQ3.5_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern) %>%
  filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

pilotfair_RQ3.5_data <- pilotfair_RQ3.5_data %>%
   mutate(diffnoexchan = pilotfairnoex - pilotfairchan)%>%
   mutate(diffnoexexpl = pilotfairnoex - pilotfairexpl)%>%
   mutate(diffnoexintern = pilotfairnoex - pilotfairintern) %>%
   mutate(diffchanexpl = pilotfairchan - pilotfairexpl) %>%
   mutate(diffchanintern = pilotfairchan - pilotfairintern) %>%
   mutate(diffexplintern = pilotfairexpl - pilotfairintern)



### 5.3.1 Model 5: all demographics in one model - diffnoexchan ----
#' Can demographics explain the difference between Gut feeling and Chance?  
reg_all_noexchan <- lm(diffnoexchan ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                       data = pilotfair_RQ3.5_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(reg_all_noexchan)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(reg_all_noexchan)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(reg_all_noexchan)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(reg_all_noexchan)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(reg_all_noexchan)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No critical values.
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 2 (0.42%) are critical.  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' 26 cases (5.51%) outside these borders. -> cause for concern  

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.  
#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.* Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are 11 cases with covariance ratios outside the required range, but since the cook's distances are ok, we do not need to worry.  
f24_lm_savetable(as.data.frame(covariance), "NoexChan")


#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_noexchan)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see Model 1 (gradfair)*  


#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(reg_all_noexchan)
#'Plots look ok.



### 5.3.2 Model 6: all demographics in one model - diffnoexexpl ----

#' Can demographics explain the difference between Gut feeling and Criteria?  
reg_all_diffnoexexpl <- lm(diffnoexexpl ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                           data = pilotfair_RQ3.5_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(reg_all_diffnoexexpl)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(reg_all_diffnoexexpl)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(reg_all_diffnoexexpl)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(reg_all_diffnoexexpl)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(reg_all_diffnoexexpl)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No critical values.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' only 4 (0.88%) are critical, that's ok.  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' only 19 cases (4.19%) outside these borders.  

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.  
#' 
#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.* Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are 7 cases with covariance ratios outside the required range. 
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "NoexExpl")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_diffnoexexpl)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see Model 1 (gradfair)*  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(reg_all_diffnoexexpl)



### 5.3.3 Model 7: all demographics in one model - diffnoexintern ----

#' Can demographics explain the difference between Gut feeling and Voluntary?  
reg_all_diffnoexintern <- lm(diffnoexintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                             data = pilotfair_RQ3.5_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(reg_all_diffnoexintern)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(reg_all_diffnoexintern)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(reg_all_diffnoexintern)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(reg_all_diffnoexintern)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(reg_all_diffnoexintern)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No critical values.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' only 2 (0.44%) are critical, that's ok.  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' only 16 cases (3.52%) outside these borders! 

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.  

#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.* Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are 9 cases with covariance ratios outside the required range, but since the cook's distances are ok, we do not need to worry. 
f24_lm_savetable(as.data.frame(covariance), "NoexIntern")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_diffnoexintern)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see Model 1 (gradfair)*  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(reg_all_diffnoexintern)



### 5.3.4 Model 8: all demographics in one model - diffchanexpl ----

#' Can demographics explain the difference between Chance and Criteria?  
reg_all_diffchanexpl <- lm(diffchanexpl ~ sex + as.numeric(age) + education + as.numeric(city) + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                           data = pilotfair_RQ3.5_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(reg_all_diffchanexpl)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(reg_all_diffchanexpl)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(reg_all_diffchanexpl)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(reg_all_diffchanexpl)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(reg_all_diffchanexpl)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No critical values.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' only 3 are critical, that's ok.  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' 26 cases (5.73%) outside these borders. -> cause for concern

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.  
#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.* Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are 3 cases with covariance ratios outside the required range, but since the cook's distances are ok, we do not need to worry.  
f24_lm_savetable(as.data.frame(covariance), "ChanExpl")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_diffchanexpl)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see Model 1 (gradfair)*  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(reg_all_diffchanexpl)



### 5.3.5 Model 9: all demographics in one model - diffchanintern ----

#' Can demographics explain the difference between Chance and Criteria?  
reg_all_diffchanintern <- lm(diffchanintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                             data = pilotfair_RQ3.5_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(reg_all_diffchanintern)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(reg_all_diffchanintern)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(reg_all_diffchanintern)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(reg_all_diffchanintern)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(reg_all_diffchanintern)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' 1 case is critical.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 6 cases are more than 1%. -> cause for concern  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' only 21 cases (4.63%) outside these borders! 

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.  

#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.* Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are 14 cases with covariance ratios outside the required range. 
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "ChanIntern")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_diffchanintern)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see Model 1 (gradfair)*  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(reg_all_diffchanintern)



### 5.3.6 Model 10: all demographics in one model - diffexplintern ----

#' Can demographics explain the difference between Chance and Criteria?  
reg_all_diffexplintern <- lm(diffexplintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                             data = pilotfair_RQ3.5_data) #define model with all demographic variables.

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(reg_all_diffexplintern)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(reg_all_diffexplintern)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(reg_all_diffexplintern)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(reg_all_diffexplintern)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(reg_all_diffexplintern)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' 1 case causes concern.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 4 cases (0.88%) are critical, that's ok.  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' 26 cases (5.73%) outside these borders. -> cause for concern  

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.  

#' *Mahalanobis distance*  
#' Not checked, because no case with cook's distance > 1.

#' *Check covariance ratios.* Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454))
covariance %>%
   count(covariance.ratios)
#' There are cases with covariance ratios outside the required range. 
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "ExplIntern")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(reg_all_diffexplintern)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see Model 1 (gradfair)*  

#' *Look at assumptions (normal distribution) about the residuals.*
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(reg_all_diffexplintern)



### 5.4 Einzelmodelle (neu_RV; 27.6.19): all demographics in one model ----
#' Create datasets.
gradfair_RQ1.4_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, gradfairEq, gradfairEt, gradfairNe)  %>%
   filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

testfair_RQ2.4_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, testfairEq, testfairEt) %>%
   filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

pilotfair_RQ3.5_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern) %>%
   filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)



### 5.4.1 gradfairEq ----
#'Create model.
indEq <- lm(gradfairEq ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = gradfair_RQ1.4_data)

#' *Check Outliers and influential cases:*
gradfair_RQ1.4_data$residuals <- resid(indEq)
gradfair_RQ1.4_data$standardized.residuals <- rstandard(indEq)
gradfair_RQ1.4_data$studentized.residuals <- rstudent(indEq)
gradfair_RQ1.4_data$cooks.distance <- cooks.distance(indEq)
gradfair_RQ1.4_data$covariance.ratios <- covratio(indEq)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No cases cause concern.  
#' (2)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' No cases +/- 2.58. 
#' (3)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 14 cases (3.08%) outside these borders!   

#' *Cook's distance:*
gradfair_RQ1.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- gradfair_RQ1.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 4 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "IndEq")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(indEq)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(gradfair_RQ1.4_data$standardized.residuals) 
plot(indEq)
#'Plots look ok.



### 5.4.2 gradfairEt ----
indEt <- lm(gradfairEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = gradfair_RQ1.4_data)

#' *Check Outliers and influential cases:*
gradfair_RQ1.4_data$residuals <- resid(indEt)
gradfair_RQ1.4_data$standardized.residuals <- rstandard(indEt)
gradfair_RQ1.4_data$studentized.residuals <- rstudent(indEt)
gradfair_RQ1.4_data$cooks.distance <- cooks.distance(indEt)
gradfair_RQ1.4_data$covariance.ratios <- covratio(indEt)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No cases cause concern.  
#' (2)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' Only 1 is critical, that's ok.
#' (3)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 22 cases (4.85%) outside these borders!   

#' *Cook's distance:*
gradfair_RQ1.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- gradfair_RQ1.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 13 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "IndEt")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(indEt)
#' The assumption of independent errors is NOT met: D-W statistic is significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(gradfair_RQ1.4_data$standardized.residuals) 
plot(indEt)
#' No normal distribution -> Bootstrapping.



### 5.4.3 gradfairNe ----
indNe <- lm(gradfairNe ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = gradfair_RQ1.4_data)

#' *Check Outliers and influential cases:*
gradfair_RQ1.4_data$residuals <- resid(indNe)
gradfair_RQ1.4_data$standardized.residuals <- rstandard(indNe)
gradfair_RQ1.4_data$studentized.residuals <- rstudent(indNe)
gradfair_RQ1.4_data$cooks.distance <- cooks.distance(indNe)
gradfair_RQ1.4_data$covariance.ratios <- covratio(indNe)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No cases cause concern.  
#' (2)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 8 cases (1.76%) are critical. That's a problem.
#' (3)
gradfair_RQ1.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' 23 cases (5.07%) outside these borders!   

#' *Cook's distance:*
gradfair_RQ1.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- gradfair_RQ1.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 19 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "IndNe")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(indNe)
#' The assumption of independent errors is NOT met: D-W statistic is significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(gradfair_RQ1.4_data$standardized.residuals) 
plot(indNe)
#' No normal distribution -> Bootstrapping.



### 5.4.4 testfairEq ----
#'Create model.
collEq <- lm(testfairEq ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = testfair_RQ2.4_data)

#' *Check Outliers and influential cases:*
testfair_RQ2.4_data$residuals <- resid(collEq)
testfair_RQ2.4_data$standardized.residuals <- rstandard(collEq)
testfair_RQ2.4_data$studentized.residuals <- rstudent(collEq)
testfair_RQ2.4_data$cooks.distance <- cooks.distance(collEq)
testfair_RQ2.4_data$covariance.ratios <- covratio(collEq)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No cases cause concern.  
#' (2)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' only 1 case (0.22%) is critical, that's ok.
#' (3)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 10 cases (2.20%) outside these borders!   

#' *Cook's distance:*
testfair_RQ2.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- testfair_RQ2.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 3 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "CollEq")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(collEq)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(testfair_RQ2.4_data$standardized.residuals) 
plot(collEq)
#'Plots look ok.



### 5.4.5 testfairEt ----
#'Create model.
collEt <- lm(testfairEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
             data = testfair_RQ2.4_data)

#' *Check Outliers and influential cases:*
testfair_RQ2.4_data$residuals <- resid(collEt)
testfair_RQ2.4_data$standardized.residuals <- rstandard(collEt)
testfair_RQ2.4_data$studentized.residuals <- rstudent(collEt)
testfair_RQ2.4_data$cooks.distance <- cooks.distance(collEt)
testfair_RQ2.4_data$covariance.ratios <- covratio(collEt)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No cases cause concern.  
#' (2)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' No cases +/- 2.58. 
#' (3)
testfair_RQ2.4_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 14 cases (2.97%) outside these borders!   

#' *Cook's distance:*
testfair_RQ2.4_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- testfair_RQ2.4_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 3 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "CollEt")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(collEt)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(testfair_RQ2.4_data$standardized.residuals) 
plot(collEt)
#'Plots look ok.



### 5.4.6 pilotfairnoex ----
#'Create model.
prNoex <- lm(pilotfairnoex ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
             data = pilotfair_RQ3.5_data)

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(prNoex)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(prNoex)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(prNoex)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(prNoex)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(prNoex)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' 1 case causes concern.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 5 cases (1.06%) are more than 1%. -> cause for concern
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 16 cases (3.39%) outside these borders!   

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 256 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "PrNoex")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(prNoex)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(prNoex)
#'Plots look ok.



### 5.4.7 pilotfairchan ----
#'Create model.
prChance <- lm(pilotfairchan ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
             data = pilotfair_RQ3.5_data)

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(prChance)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(prChance)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(prChance)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(prChance)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(prChance)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No cases cause concern.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' No cases cause concern.  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 12 cases (2.54%) outside these borders!   

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 2 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "PrChance")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(prChance)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(prChance)
#'Plots look ok.



### 5.4.8 pilotfairexpl ----
#'Create model.
prExpl <- lm(pilotfairexpl ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
               data = pilotfair_RQ3.5_data)

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(prExpl)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(prExpl)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(prExpl)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(prExpl)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(prExpl)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' 1 case causes concern.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' No cases cause concern.  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' Only 22 cases (4.66%) outside these borders!   

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 14 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "PrExpl")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(prExpl)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(prExpl)
#'Plots look ok.



### 5.4.9 pilotfairintern ----
#'Create model.
prInt <- lm(pilotfairintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
             data = pilotfair_RQ3.5_data)

#' *Check Outliers and influential cases:*
pilotfair_RQ3.5_data$residuals <- resid(prInt)
pilotfair_RQ3.5_data$standardized.residuals <- rstandard(prInt)
pilotfair_RQ3.5_data$studentized.residuals <- rstudent(prInt)
pilotfair_RQ3.5_data$cooks.distance <- cooks.distance(prInt)
pilotfair_RQ3.5_data$covariance.ratios <- covratio(prInt)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' 6 cases cause concern.  
#' (2)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' No cases cause concern.  
#' (3)
pilotfair_RQ3.5_data %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' 26 cases (5.73%) outside these borders!  

#' *Cook's distance:*
pilotfair_RQ3.5_data %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- pilotfair_RQ3.5_data %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 20 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "PrInt")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(prInt)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(pilotfair_RQ3.5_data$standardized.residuals) 
plot(prInt)
#'Plots look ok.


### 5.4.10 gradfairEq - testfairEq ----
#' Prepare data
gradfair_testfair <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, gradfairEq, gradfairEt, testfairEq, testfairEt) %>%
   filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

gradfair_testfair <- gradfair_testfair %>%
   mutate(gradEqtestEq = gradfairEq - testfairEq) %>%
   mutate(gradEttestEt = gradfairEt - testfairEt) 

#'Create model.
distindcollEq <- lm(gradEqtestEq ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = gradfair_testfair)

#' *Check Outliers and influential cases:*
gradfair_testfair$residuals <- resid(distindcollEq)
gradfair_testfair$standardized.residuals <- rstandard(distindcollEq)
gradfair_testfair$studentized.residuals <- rstudent(distindcollEq)
gradfair_testfair$cooks.distance <- cooks.distance(distindcollEq)
gradfair_testfair$covariance.ratios <- covratio(distindcollEq)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
gradfair_testfair %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' 1 case causes concern.  
#' (2)
gradfair_testfair %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 7 cases cause concern.  
#' (3)
gradfair_testfair %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' 26 cases (5.73%) outside these borders!  

#' *Cook's distance:*
gradfair_testfair %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- gradfair_testfair %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 19 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "distindcollEq")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(distindcollEq)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(gradfair_testfair$standardized.residuals) 
plot(distindcollEq)
#'Plots look ok.



#'### 5.4.11 gradfairEt - testfairEt ----
#'Create model.
distindcollEt <- lm(gradEttestEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                    data = gradfair_testfair)

#' *Check Outliers and influential cases:*
gradfair_testfair$residuals <- resid(distindcollEt)
gradfair_testfair$standardized.residuals <- rstandard(distindcollEt)
gradfair_testfair$studentized.residuals <- rstudent(distindcollEt)
gradfair_testfair$cooks.distance <- cooks.distance(distindcollEt)
gradfair_testfair$covariance.ratios <- covratio(distindcollEt)

#' *Standardized residuals:*  
#' (1) Values +/- 3.29 are cause for condern.  
#' (2) more than 1% (4.72) more than +/- 2.58 is inacceptable.  
#' (3) we expect 95% (448.4) of the values to be within the borders of +/-1.96.
#' (1)
gradfair_testfair %>%
   filter(standardized.residuals > 3.29 | standardized.residuals < -3.29) %>%
   pull(standardized.residuals)
#' No cases cause concern.  
#' (2)
gradfair_testfair %>%
   filter(standardized.residuals > 2.58 | standardized.residuals < -2.58) %>%
   count(standardized.residuals)
#' 8 cases cause concern.  
#' (3)
gradfair_testfair %>%
   filter(standardized.residuals > 1.96 | standardized.residuals < -1.96) %>%
   count(standardized.residuals)
#' 24 cases (5.73%) outside these borders!  

#' *Cook's distance:*
gradfair_testfair %>% 
   filter(cooks.distance > 1) %>%
   pull(cooks.distance)
#' None of the cases has a cooks.distance > 1. So we can assume, that their influence on the model is negligible.

#' *Mahalanobis distance*  
#' Since none of the cases has a Cook's distance > 1 (in all the models), we do not check the Mahalanobis distance.  

#' **Check covariance ratios.** Should lie between 1+3(k+1)/n and 1-3(k+1)/n.
covariance <- gradfair_testfair %>% 
   filter(covariance.ratios > 1+3*(25/454) | covariance.ratios < 1-3*(25/454)) 
covariance %>%
   count(covariance.ratios)
#' There are 16 cases with covariance ratios outside the required range.
#' Considering, that the Cook's distances are ok, we are not worried.
f24_lm_savetable(as.data.frame(covariance), "distindcollEt")

#' *Check for independent errors using the Durbin-Watson test.*
durbinWatsonTest(distindcollEt)
#' The assumption of independent errors is met: D-W statistic close to 2 and result is not significant.  

#' *For multicollinearity (VIF analyses) see model 1*  

#' *Look at assumptions (normal distribution) about the residuals.* 
par(mfrow=c(2,2))
hist(gradfair_testfair$standardized.residuals) 
plot(distindcollEt)
#'Plots look ok.

## ================================================================ ## 
## =============================  END ============================= ##
## ================================================================ ##