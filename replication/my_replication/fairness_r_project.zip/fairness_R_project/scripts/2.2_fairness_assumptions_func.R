## ===================================================================== ##
## Project:     Functions Needed to Check Assumptions for Data Analysis
## File:        2.2_fairness_assumptions_func.R
## Created:     15.07.2019
## Authors:     Sara Schmid, sara.schmid@eawag.ch
## Description: Functions, that are needed in the script...
##                ...2.1_fairness_assumptions; edited for ERIC
## Last change: 03.09.2019 by Sara
## ===================================================================== ##

f9_which_model <- function(dataset) {
   m0 <- gls(fairness ~ approach, data = dataset, method = "ML")
   m1 <- lme(fairness ~ approach, data = dataset, random = ~1|id, method = "ML")
   summary(m0)
   summary(m1)
   anova(m0, m1)
}
#Compares a basic model (only intercept) to a model that has a random intercept and shows, whether the two models differ significantly.


f11_barcharts_diff <- function (dataset) {
   dataset$difference <- factor(dataset$difference, labels = c(difflabels))
   dataset %>%
      ggplot(aes(x = score))+ 
      facet_wrap(~ difference, scales='free_x', nrow = 1) + 
      geom_bar() +
      labs(x = "Difference between the approaches", y = "Count", title = "Differences between the approaches")
}
#Creates barcharts of the differences between the approaches.


f13_del_incons_cases <- function() {
   testfair_data_wide_no_incons <- testfair_data_wide %>%
      filter(testfairEq != 6 | testfairEt != 6) %>%
      filter(testfairEq == 6 & testalloc == 11 | testfairEq != 6) %>%
      filter(testfairEt == 6 & testalloc == 1 | testfairEt != 6)
}
#Deletes inconsistent cases from the dataset. 597 and 1023 are filtered in both Eq and testalloc inconsistent as well as in Et and testalloc inconsistent. Therefore instead of 47 cases (33 from Et and 14 from Eq), only 45 are deleted


f24_lm_savetable <- function(data, sht_nm) {
   write.xlsx(data, file = "output/190903_covariance_ratios.xlsx", sheetName = sht_nm, 
              col.names = TRUE, row.names = TRUE, append = TRUE)
}
#Saves outliers determined by covariance ratios into one Excel file.