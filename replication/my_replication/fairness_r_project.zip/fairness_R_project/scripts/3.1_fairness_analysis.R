## ================================================================ ##
## Project:     Data Analysis
## File:        3.1_fairness_analysis.R
## Created:     15.07.2019
## Authors:     Sara Schmid, sara.schmid@eawag.ch
## Description: Script for data analysis; edited for ERIC
## Last change: 024.11.2020 by Sara
## ================================================================ ##


#### 1. Set Up ----

### 1.1. Update dates ----

#' Update the dates (yymmdd) in this file (3.1_fairness_analysis) and in the functions file (3.2_fairness_analysis_func).


### 1.2. Import data ----

#' Run the script "datacleaning" to get the datafile needed for the following analyses.
source("scripts/1.1_fairness_cleaning.R")
#' Run the script with the functions needed for the following analyses. 
source("scripts/3.2_fairness_analysis_func.R")



### 1.3. Load libraries ----
library("ez")
library("broom")
library("boot")
library("nlme")
library("car")
library("lme4")
library("Hmisc")
library("xlsx")


### 1.4. Create datasets ----
##Dataset in long format with all gradfair variables.
gradfair_data <- fair_data_quant %>%
   select(id, gradfairEq, gradfairEt, gradfairNe) %>%
   gather(approach, fairness, gradfairEq:gradfairNe)

#' Dataset in long format with all testfair variables.
testfair_data <- fair_data_quant %>%
   select(id, testfairEq, testfairEt) %>%
   gather(approach, fairness, testfairEq:testfairEt)

#' Dataset in long format with all pilotfair variables.
pilotfair_data <- fair_data_quant %>%
   select(id, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern) %>%
   gather(approach, fairness, pilotfairnoex:pilotfairintern)

pilotfair_data$approach <- factor(pilotfair_data$approach,
                                  levels = unique(pilotfair_data$approach),
                                  labels = c("pilotfairnoex", "pilotfairchan", "pilotfairexpl", "pilotfairintern")) #define order from unfairest to fairest


#### 2. Descriptives demographics ----
#' Create dataset in long format with all demographics variables:
demographics_data <- fair_data_quant %>%
   select(id, sex, age, education, city, tenant, wastewater, device, reward, religion, engagement, finance, politic, knowledge1, knowledge1howlong, interviewtime, quizright, knowledge_points, politic_lcr) %>%
   mutate_all(funs(as.numeric)) %>%
   gather(variable, value, sex:politic_lcr)

pdf("output/201124_demographics_plots.pdf") #this codeline and the code "dev.off()" at the end of chapter 2, export every plot in between the two codelines to one PDF.

#' Count / percent.
demographics_distr <- f2_descrstat_distr(demographics_data, variable, value)
f1_demo_savetable(as.data.frame(demographics_distr), "demographics")

#' Barcharts.
demographics_data %>%
   ggplot(aes(x = value))+ 
   facet_wrap(~ variable, scales='free_x', nrow = 3) + 
   geom_bar() +
   labs(x = "Value", y = "Count", title = "Barcharts of demographics") 
#' Warning message can be ignored. It's about the 346 people without experience in wastewater. They are missing in knowledge1howlong.

#' Central tendency.
demographics_centr <- demographics_data %>%
   filter(variable != "sex" & variable != "politic" & variable != "politic_lcr") %>%
   f3_descrstat_centr(colana1 = variable, colana2 = value)
f1_demo_savetable(demographics_centr, "demographics_centr")
print(demographics_centr)

#' Boxplots.
demographics_data %>%
   filter(variable != "sex" & variable != "politic" & variable != "wastewater" & variable != "device" & variable != "education" & variable != "interviewtime" & variable != "tenant" & variable != "knowledge1" & variable != "politic_lcr") %>%
   ggplot(aes(x = "", y = value)) +
   facet_wrap(~ variable, scales='free_x', nrow = 3) + 
   geom_boxplot(outlier.color = "red") +
   geom_jitter(width = 0.2, height = 0.3, color = "orange", size = 0.6) +
   labs(x = "Variables", y = "Values")
#' Warning message can be ignored. It's about the 346 people without experience in wastewater. They are missing in knowledge1howlong.

demographics_data %>%
   filter(variable == "interviewtime") %>%
   ggplot(aes(x = "", y = value)) +
   facet_wrap(~ variable, scales='free_x', nrow = 3) + 
   geom_boxplot(outlier.color = "red") +
   geom_jitter(width = 0.2, height = 0.3, color = "orange", size = 0.6) +
   labs(x = "Variables", y = "Values")

#Look at counts and % of wastewater knowledge (quiz).
knowledge_counts <- fair_data_quant %>%
   select(id, canalisation, health, stm1, stm2, stm3, stm4, stm5, cost) %>%
   mutate_all(funs(as.numeric)) %>%
   gather(variable, value, canalisation:cost)

knowledge_distr <- f2_descrstat_distr(knowledge_counts, variable, value)
f1_demo_savetable(as.data.frame(knowledge_distr), "knowledge")

dev.off()


#### 3. Analyse the current situation ----
#' Create dataset in long format with all cursit variables:
cursit_data <- fair_data_quant %>%
   select(id, cursit1) %>%
   gather(variable, value, cursit1)


### 3.1. cursit - Descriptives ----
pdf("output/201124_cursit_descr_plots.pdf")

#' Count / percent.
f4_cursit_savetable(as.data.frame(f2_descrstat_distr(cursit_data, variable, value)), "cursit_distr")

#' Barcharts.
cursit_data$variable <- factor(cursit_data$variable, labels = c("Current situation"))

cursit_data %>%
   ggplot(aes(x = value))+ 
   geom_bar() +
   labs(x = "Fairness of the current situation", y = "Count", title = "Fairness of the current situation") 

#' Central tendency.
f4_cursit_savetable(f3_descrstat_centr(cursit_data, variable, value), "cursit_centr")
f3_descrstat_centr(cursit_data, variable, value)

#' Boxplots.
cursit_data %>%
   ggplot(aes(x = "", y = value)) +
   geom_boxplot() +
   geom_jitter(width = 0.2, height = 0.3, color = "orange", size = 1) +
   labs(x = "Current situation", y = "Fairness") 

dev.off()


#### 4. Analyze the Gradual Implementation of KLARAs ----

### 4.1. gradfair - Descriptives ----

pdf("output/201124_gradfair_descr_plots.pdf")

#' Count / percent.
f5_gradfair_savetable(as.data.frame(f2_descrstat_distr(gradfair_data, approach, fairness)), "gradfair_distr")
f2_descrstat_distr(gradfair_data, approach, fairness)

#' Barcharts.
gradfair_data$approach <- factor(gradfair_data$approach, labels = c("Equality", "Equity", "Need")) #Just for design reasons, so the charts are labeled nicely.
f12_barcharts_vign(gradfair_data, titletext = "Fairness of the different approaches in the vignette: Gradual implementation of package plants.")
gradfair_data$approach <- factor(gradfair_data$approach, labels = c("gradfairEq", "gradfairEt", "gradfairNe")) #Change the names of the items back.

#' Central tendency.
f5_gradfair_savetable(f3_descrstat_centr(gradfair_data, approach, fairness), "gradfair_centr")
f3_descrstat_centr(gradfair_data, approach, fairness)

#' Boxplots.
xscalelabels <- c("Equality", "Equity", "Need")
f6_multipleboxplot(gradfair_data, approach, fairness)

dev.off()


### 4.2.1 Testing H1.1, H1.2 and RQ1.3 ----

f10_rmANOVA(gradfair_data)
#' Mauchly's test for sphericity is p < .05. Therefore we report the Greenhouse-Geisser estimate. The three approaches Eq, Et and Ne do differ significantly.  

#' Posthoc-test
gradfair_tt <- f21_pairwise.t.test.with.t.and.df(gradfair_data$fairness, gradfair_data$approach, paired = TRUE, p.adjust.method = "bonferroni")
gradfair_tt$t.value
gradfair_tt$p.value
gradfair_tt$dfs
by(gradfair_data$fairness,list(gradfair_data$approach),mean)
#' Et is significantly fairer than Eq. Ne is significantly fairer than Eq. Ne is significantly fairer than Et.  
#' Effect sizes: sqrt(t^2/(t^2+df))
sqrt(gradfair_tt$t.value^2/(gradfair_tt$t.value^2+gradfair_tt$dfs))

#' Testing the three approaches against the current situation.
#' Create Dataset:
gradfair_cursit <- fair_data_quant %>%
   select(id, cursit1, gradfairEq, gradfairEt, gradfairNe) %>%
   gather(approach, fairness, cursit1:gradfairNe)

#' t-tests:
gradfair_tt <- f21_pairwise.t.test.with.t.and.df(gradfair_cursit$fairness, gradfair_cursit$approach, paired = TRUE, p.adjust.method = "bonferroni")
gradfair_tt$t.value
gradfair_tt$p.value
gradfair_tt$dfs

#' Effect sizes: sqrt(t^2/(t^2+df))
sqrt(gradfair_tt$t.value^2/(gradfair_tt$t.value^2+gradfair_tt$dfs))


### 4.2.2 Testing RQ1.4 ----
#' Prepare data
gradfair_RQ1.4_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, gradfairEq, gradfairEt, gradfairNe) %>%
  filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

gradfair_RQ1.4_data <- gradfair_RQ1.4_data %>%
   mutate(diffEqEt = gradfairEq - gradfairEt)%>%
   mutate(diffEqNe = gradfairEq - gradfairNe)%>%
   mutate(diffEtNe = gradfairEt - gradfairNe)


### 4.2.2.1 Model 1: all demographics in one model - EqEt ----
#' Can demographics explain the difference between Eq and Et?  

#' There is no need for concern because of the assumptions, so we can report the "normal" regression results.

reg_all_EqEt <- lm(diffEqEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = gradfair_RQ1.4_data) #define model with all demographic variables.
sum <- summary(reg_all_EqEt)

#'Create dataframe for saving the F-statistic values from all regression models:
reg_all_F.statistic <- data.frame(x = 0)

#'Create dataframe for saving the p-values from all regression models:
reg_all_p.values <- data.frame(x = 0)

#'Create dataframe for saving the R-squared values from all regression models:
reg_all_R.squared <- data.frame(x = 0)

#'Create dataframe for saving the adjusted R-squared values from all regression models:
reg_all_adj.R.squared <- data.frame(x = 0)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "gradEqEt"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_EqEt_tidy <- tidy(reg_all_EqEt)
reg_all_EqEt_tidy

#' Save regression model as Excel sheet:
f24_lm_savetable(as.data.frame(reg_all_EqEt_tidy), "grad_EqEt")


### 4.2.2.1 Model 2: all demographics in one model - EqNe ----
#' Can demographics explain the difference between Eq and Ne?  

#' There is no need for concern because of the assumptions, so we can report the "normal" regression results.

reg_all_EqNe <- lm(diffEqNe ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = gradfair_RQ1.4_data) #define model with all demographic variables.
sum <- summary(reg_all_EqNe)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "gradEqNe"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_EqNe_tidy <- tidy(reg_all_EqNe)
reg_all_EqNe_tidy
#' Save regression model as Excel sheet:
f24_lm_savetable(as.data.frame(reg_all_EqNe_tidy, sum), "grad_EqNe")



### 4.2.2.3 Model 3: all demographics in one model - EtNe ----
#' Can demographics explain the difference between Et and Ne? 
 
#' There is no need for concern because of the assumptions, so we can report the "normal" regression results.
reg_all_EtNe <- lm(diffEtNe ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = gradfair_RQ1.4_data) #define model with all demographic variables.
sum <- summary(reg_all_EtNe)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "gradEtNe"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_EtNe_tidy <- tidy(reg_all_EtNe)
reg_all_EtNe_tidy
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_EtNe_tidy), "grad_EtNe")



#### 5. Analyze the Test phase with package plants ----

### 5.1. testfair - Descriptives ----

pdf("output/201124_testfair_descr_plots.pdf")

#' Count / percent.
f8_testfair_savetable(as.data.frame(f2_descrstat_distr(testfair_data, approach, fairness)), "testfair_distr")
f2_descrstat_distr(testfair_data, approach, fairness)

#' Barcharts.
testfair_data$approach <- factor(testfair_data$approach, labels = c("Equality", "Equity")) #Just for design reasons, so the charts are labeled nicely.
f12_barcharts_vign(testfair_data, titletext = "Fairness of the different approaches in the vignette: Test phase with package plants.")
testfair_data$approach <- factor(testfair_data$approach, labels = c("testfairEq", "testfairEt"))#Change the names of the items back.

#' Central tendency.
f8_testfair_savetable(f3_descrstat_centr(testfair_data, approach, fairness), "testfair_centr")
f3_descrstat_centr(testfair_data, approach, fairness)

#' Boxplots.
xscalelabels <- c("Equality", "Equity", "Need")
f6_multipleboxplot(testfair_data, approach, fairness)

dev.off()

### 5.2. testtfair - Testing hypotheses ----
# Create wide format data:
testfair_data_wide <- fair_data_quant %>%
   select(id, testfairEq, testfairEt, testalloc)
testfair_data_wide <- testfair_data_wide %>%
   mutate(diffEqEt = testfairEq - testfairEt)

### 5.2.1 Testing H2.1 ----
testfair_wt <- wilcox.test(testfair_data_wide$testfairEq, testfair_data_wide$testfairEt, paired = TRUE, alternative = "less", conf.int = TRUE)
testfair_wt
by(testfair_data$fairness,list(testfair_data$approach),mean)
#' Equity is fairer than Equality (p = .007).  

#' Calculate Z to report in Paper
Z <- qnorm(testfair_wt$p.value/2)
Z

#' Calculate r to report in Paper.
abs(Z)/sqrt(472)


### 5.2.2 Testing H2.2 ----
#' Test consistency of answers. participants who chose 100% : 0% as totally fair, should also allocate 100% to Weihermatten.
#' Spearman correlation between testalloc and testfairEt is significant.
testfair_data_wide %>%
   filter(testfairEq == 6) %>%
   count(testalloc)

testfair_data_wide %>%
   filter(testfairEt == 6) %>%
   count(testalloc)

#' What do we do with participants, who answered inconsistently? 
#' Ignore all inconsistent cases for this analysis: ignored if...  
#' ...Eq and Et were both rated as totally fair.   
#' ...rating of Eq/Et is inconsistent with testalloc:
testfair_data_wide_no_incons <- f13_del_incons_cases()

#' *Which allocation key is most often chosen as totally fair?*
testalloc_table_counts <- testfair_data_wide_no_incons %>%
   count(testalloc) %>%
   mutate(percent = prop.table(n)*100)

write.xlsx(testalloc_table_counts, file = "output/201124_testalloc_counts.xlsx", sheetName = "testalloc_counts", col.names = TRUE, row.names = TRUE, append = TRUE)

#' H2.2: The share allocated to Weihermatten is higher than 50% (= 11).
#' 1 means 100% for Weihermatten and 0% for Angarten. Therefore our hypothesis means: testalloc < 11.  
median(testfair_data_wide_no_incons$testalloc)
mean(testfair_data_wide_no_incons$testalloc)
sd(testfair_data_wide_no_incons$testalloc)

alloc_wt <- wilcox.test(testfair_data_wide_no_incons$testalloc, mu = 11, alternative = "less", conf.int = TRUE)
alloc_wt

#' Calculate Z to report in Paper
Z <- qnorm(alloc_wt$p.value/2)
Z

#' Calculate r to report in Paper.
abs(Z)/sqrt(427)


### 5.2.3 Testing RQ2.4 ----
#' Prepare data
testfair_RQ2.4_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, testfairEq, testfairEt) %>%
  filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

testfair_RQ2.4_data <- testfair_RQ2.4_data %>%
   mutate(diffEqEt = testfairEq - testfairEt)


### 5.2.3.1  Model 4: all demographics in one model - EqEt ----
#' Can demographics explain the difference between Eq and Et?  
reg_all_EqEt <- lm(diffEqEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = testfair_RQ2.4_data) #define model with all demographic variables.
sum <- summary(reg_all_EqEt)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "testEqEt"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_EqEt_tidy <- tidy(reg_all_EqEt)
reg_all_EqEt_tidy
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_EqEt_tidy), "testEqEt")

#********************************************************************#
#' Same analysis for sample with 2 correct quiz questions:

#'filter:
testfair_RQ2.4_data_q2 <- fair_data_quant %>%
   filter(quizright == 2)
testfair_RQ2.4_data_q2 <- testfair_RQ2.4_data_q2 %>%
  filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (7 cases)

#'create dataset:
testfair_RQ2.4_data_q2 <- testfair_RQ2.4_data_q2 %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, testfairEq, testfairEt)

testfair_RQ2.4_data_q2 <- testfair_RQ2.4_data_q2 %>%
   mutate(diffEqEt = testfairEq - testfairEt)

#'Define model with all demographic variables:
reg_all_EqEt_q2 <- lm(diffEqEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                   data = testfair_RQ2.4_data_q2) 
sum <- summary(reg_all_EqEt_q2)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "testEqEt_q2"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_EqEt_tidy_q2 <- tidy(reg_all_EqEt_q2)
reg_all_EqEt_tidy_q2
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_EqEt_tidy_q2), "testEqEt_q2")

#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = diffEqEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = testfair_RQ2.4_data_q2, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "testEqEt_q2_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)


#### 6. Analyze the Pilot project with package plants ----

### 6.1. pilotfair - Descriptives ----

pdf("output/201124_pilotfair_descr_plots.pdf")

#' Count / percent.
f7_pilotfair_savetable(as.data.frame(f2_descrstat_distr(pilotfair_data, approach, fairness)), "pilotfair_distr")
f2_descrstat_distr(pilotfair_data, approach, fairness)

#' Barcharts.
pilotfair_data$approach <- factor(pilotfair_data$approach, labels = c("Gut feeling", "Chance", "Criteria", "Voluntary")) #Just for design reasons, so the charts are labeled nicely.
f12_barcharts_vign(pilotfair_data, titletext = "Fairness of the different approaches in the vignette: Pilot project with package plants.")
pilotfair_data$approach <- factor(pilotfair_data$approach, labels = c("pilotfairnoex", "pilotfairchan", "pilotfairexpl", "pilotfairintern")) #Change the names of the items back.

#' Central tendency.
f7_pilotfair_savetable(f3_descrstat_centr(pilotfair_data, approach, fairness), "pilotfair_centr")
f3_descrstat_centr(pilotfair_data, approach, fairness)

#' Boxplots.
xscalelabels <- c("Gut feeling", "Chance", "Criteria", "Voluntary")
f6_multipleboxplot(pilotfair_data, approach, fairness)

dev.off()


### 6.2.1 Testing H3.1 - H3.4 ----
m1 <- lme(fairness ~ approach, data = pilotfair_data, random = ~1|id, method = "ML")
summary(m1)

f10_rmANOVA(pilotfair_data)
#' Mauchly's test for sphericity is significant. Therefore we report the Greenhouse-Geisser estimate. The four approaches gut feeling, chance, criteria and voluntary do differ significantly.

# Create wide format data
pilotfair_data_wide <- fair_data_quant %>%
   select(id, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern)
pilotfair_data_wide <- pilotfair_data_wide %>%
   mutate(diffnoexchan = pilotfairnoex - pilotfairchan)%>%
   mutate(diffnoexexpl = pilotfairnoex - pilotfairexpl)%>%
   mutate(diffnoexintern = pilotfairnoex - pilotfairintern) %>%
   mutate(diffchanexpl = pilotfairchan - pilotfairexpl) %>%
   mutate(diffchanintern = pilotfairchan - pilotfairintern) %>%
   mutate(diffexplintern = pilotfairexpl - pilotfairintern)

#' Posthoc test: Wilcoxon signed-rank test for all comparisons.
by(pilotfair_data$fairness,list(pilotfair_data$approach),mean)

#' NoexChan.
noexchan_wt <- wilcox.test(pilotfair_data_wide$pilotfairnoex, pilotfair_data_wide$pilotfairchan, paired = TRUE, alternative = "less", conf.int = TRUE)
#' Calculate Z to report in Paper
noexchan_wt_Z <- qnorm(noexchan_wt$p.value/2)
#' Calculate r to report in Paper.
noexchan_wt_r <- abs(noexchan_wt_Z)/sqrt(472)

#' NoexExpl.
noexexpl_wt <- wilcox.test(pilotfair_data_wide$pilotfairnoex, pilotfair_data_wide$pilotfairexpl, paired = TRUE, alternative = "less", conf.int = TRUE)
#' Calculate Z to report in Paper
noexexpl_wt_Z <- qnorm(noexexpl_wt$p.value/2)
#' Calculate r to report in Paper.
noexexpl_wt_r <- abs(noexexpl_wt_Z)/sqrt(472)

#' NoexIntern.
noexintern_wt <- wilcox.test(pilotfair_data_wide$pilotfairnoex, pilotfair_data_wide$pilotfairintern, paired = TRUE, alternative = "less", conf.int = TRUE)
#' Calculate Z to report in Paper
noexintern_wt_Z <- qnorm(noexintern_wt$p.value/2)
#' Calculate r to report in Paper.
noexintern_wt_r <- abs(noexintern_wt_Z)/sqrt(472)

#' ChanExpl.
chanexpl_wt <- wilcox.test(pilotfair_data_wide$pilotfairchan, pilotfair_data_wide$pilotfairexpl, paired = TRUE, alternative = "less", conf.int = TRUE)
#' Calculate Z to report in Paper
chanexpl_wt_Z <- qnorm(chanexpl_wt$p.value/2)
#' Calculate r to report in Paper.
chanexpl_wt_r <- abs(chanexpl_wt_Z)/sqrt(472)

#' ChanIntern.
chanintern_wt <- wilcox.test(pilotfair_data_wide$pilotfairchan, pilotfair_data_wide$pilotfairintern, paired = TRUE, alternative = "less", conf.int = TRUE)
#' Calculate Z to report in Paper
chanintern_wt_Z <- qnorm(chanintern_wt$p.value/2)
#' Calculate r to report in Paper.
chanintern_wt_r <- abs(chanintern_wt_Z)/sqrt(472)

#' ExplIntern.
explintern_wt <- wilcox.test(pilotfair_data_wide$pilotfairexpl, pilotfair_data_wide$pilotfairintern, paired = TRUE, alternative = "less", conf.int = TRUE)
#' Calculate Z to report in Paper
explintern_wt_Z <- qnorm(explintern_wt$p.value/2)
#' Calculate r to report in Paper.
explintern_wt_r <- abs(explintern_wt_Z)/sqrt(472)

#' combine data to a matrix.
Model <- c("noexchan", "noexexpl", "noexintern", "chanexpl", "chanintern", "explintern")
Z <- c(noexchan_wt_Z, noexexpl_wt_Z, noexintern_wt_Z, chanexpl_wt_Z, chanintern_wt_Z, explintern_wt_Z)
p <- c(noexchan_wt$p.value, noexexpl_wt$p.value, noexintern_wt$p.value, chanexpl_wt$p.value, chanintern_wt$p.value, explintern_wt$p.value)
#' Bonferroni adjustment.
pilot_wt_bonfp <- p.adjust(p, method = "bonferroni", n = 6)
r <- c(noexchan_wt_r, noexexpl_wt_r, noexintern_wt_r, chanexpl_wt_r, chanintern_wt_r, explintern_wt_r)
pilotfair_wt <- rbind(Model, Z, pilot_wt_bonfp, r)

#' Export data to xlsx.
write.xlsx(pilotfair_wt, file = "output/201124_proc_wilcox.xlsx", col.names = TRUE, row.names = TRUE, append = TRUE)



### 6.2.2 Testing RQ3.5 ----
#' Prepare data
pilotfair_RQ3.5_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern) %>%
  filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)


pilotfair_RQ3.5_data <- pilotfair_RQ3.5_data %>%
   mutate(diffnoexchan = pilotfairnoex - pilotfairchan)%>%
   mutate(diffnoexexpl = pilotfairnoex - pilotfairexpl)%>%
   mutate(diffnoexintern = pilotfairnoex - pilotfairintern) %>%
   mutate(diffchanexpl = pilotfairchan - pilotfairexpl) %>%
   mutate(diffchanintern = pilotfairchan - pilotfairintern) %>%
   mutate(diffexplintern = pilotfairexpl - pilotfairintern)


### 6.2.2.1 Model 5: all demographics in one model - diffnoexchan ----
#' Can demographics explain the difference between Gut feeling and Chance?  
reg_all_noexchan <- lm(diffnoexchan ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                       data = pilotfair_RQ3.5_data) #define model with all demographic variables.
sum <- summary(reg_all_noexchan)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "noexchan"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_noexchan_tidy <- tidy(reg_all_noexchan)
reg_all_noexchan_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_noexchan_tidy), "pilot_noexchan")

#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = diffnoexchan ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = pilotfair_RQ3.5_data, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "pilotnoexchan_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)


### 6.2.2.2 Model 6: all demographics in one model - diffnoexexpl ----
#' Can demographics explain the difference between Gut feeling and Criteria?  

#' There is no need for concern because of the assumptions, so we can report the "normal" regression results.
reg_all_diffnoexexpl <- lm(diffnoexexpl ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                           data = pilotfair_RQ3.5_data) #define model with all demographic variables.
sum <- summary(reg_all_diffnoexexpl)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "noexexpl"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_diffnoexexpl_tidy <- tidy(reg_all_diffnoexexpl)
reg_all_diffnoexexpl_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_diffnoexexpl_tidy), "pilot_noexexpl")



### 6.2.2.3 Model 7: all demographics in one model - diffnoexintern ----

#' Can demographics explain the difference between Gut feeling and Voluntary?  
reg_all_diffnoexintern <- lm(diffnoexintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                             data = pilotfair_RQ3.5_data) #define model with all demographic variables.
sum <- summary(reg_all_diffnoexintern)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "noexintern"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_diffnoexintern_tidy <- tidy(reg_all_diffnoexintern)
reg_all_diffnoexintern_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_diffnoexintern_tidy), "pilot_noexintern")

#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = diffnoexintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = pilotfair_RQ3.5_data, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "pilot_noexintern_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)


### 6.2.2.4 Model 8: all demographics in one model - diffchanexpl ----

#' Can demographics explain the difference between Chance and Criteria?  

#' There is no need for concern because of the assumptions, so we can report the "normal" regression results.
reg_all_diffchanexpl <- lm(diffchanexpl ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                           data = pilotfair_RQ3.5_data) #define model with all demographic variables.
sum <- summary(reg_all_diffchanexpl)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "chanexpl"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_diffchanexpl_tidy <- tidy(reg_all_diffchanexpl)
reg_all_diffchanexpl_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_diffchanexpl_tidy), "pilot_chanexpl")



### 6.2.2.5 Model 9: all demographics in one model - diffchanintern ----

#' Can demographics explain the difference between Chance and Criteria?  
reg_all_diffchanintern <- lm(diffchanintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                             data = pilotfair_RQ3.5_data) #define model with all demographic variables.
sum <- summary(reg_all_diffchanintern)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "chanintern"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_diffchanintern_tidy <- tidy(reg_all_diffchanintern)
reg_all_diffchanintern_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_diffchanintern_tidy), "pilot_chanintern")

#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = diffchanintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = pilotfair_RQ3.5_data, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "pilot_chanintern_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)


### 6.2.2.6 Model 10: all demographics in one model - diffexplintern ----
#' Can demographics explain the difference between Chance and Criteria?  
reg_all_diffexplintern <- lm(diffexplintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                             data = pilotfair_RQ3.5_data) #define model with all demographic variables.
sum <- summary(reg_all_diffexplintern)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "explintern"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_diffexplintern_tidy <- tidy(reg_all_diffexplintern)
reg_all_diffexplintern_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_diffexplintern_tidy), "pilot_explintern")




### 6.2.2.7 Additional analyses demographics in pilotfair ----
#' Compare men and women in selected approaches.
#' We will conduct a Bonferoni-corrected posthoc test. Assumption for unpaired t-tests: 
#'     Distribution of fairness in both groups should be normal.
#'     Homogeneity of variance (Levene-Test).

#' Create wide format data:
pilotfair_sex <- fair_data_quant %>%
   select(id, sex, pilotfairnoex, pilotfairexpl)

#' Look at barcharts.
pilotfair_sex %>%
   ggplot(aes(x = pilotfairnoex))+ 
   facet_wrap(~ sex, scales='free_x', nrow = 1) + 
   geom_bar() +
   labs(x = "Evaluation of Gut feeling", y = "Count")

pilotfair_sex %>%
   ggplot(aes(x = pilotfairexpl))+ 
   facet_wrap(~ sex, scales='free_x', nrow = 1) + 
   geom_bar() +
   labs(x = "Evaluation of Criteria", y = "Count")
#' Levene's test.
leveneTest(pilotfairnoex~sex, pilotfair_sex)
leveneTest(pilotfairexpl~sex, pilotfair_sex)
#' Data is not normally distributed. We will calculate a Mann-Whitney-U test.

pilotfair_noex_sex <- fair_data_quant %>%
   select(id, sex, pilotfairnoex) %>%
   spread(sex, pilotfairnoex)

noex_sex_wt <- wilcox.test(pilotfair_noex_sex$Female, pilotfair_noex_sex$Male, paired = FALSE, alternative = "less", conf.int = TRUE)
noex_sex_wt
#' Calculate effect size r.
abs(qnorm(noex_sex_wt$p.value/2)) / sqrt(472)

pilotfair_expl_sex <- fair_data_quant %>%
   select(id, sex, pilotfairexpl) %>%
   spread(sex, pilotfairexpl)

expl_sex_wt <- wilcox.test(pilotfair_expl_sex$Male, pilotfair_expl_sex$Female, paired = FALSE, alternative = "two.sided", conf.int = TRUE)
expl_sex_wt
abs(qnorm(expl_sex_wt$p.value/2)) / sqrt(472)


#### 7. Einzelmodelle: all demographics in one model ----

### 7.1 gradfairEq ----
#'Create model.
indEq <- lm(gradfairEq ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = gradfair_RQ1.4_data)
sum <- summary(indEq)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "gradEq"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_indEq_tidy <- tidy(indEq)
reg_all_indEq_tidy
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_indEq_tidy), "indEq")


### 7.2 gradfairEt ----
indEt <- lm(gradfairEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = gradfair_RQ1.4_data)
sum <- summary(indEt)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "gradEt"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_indEt_tidy <- tidy(indEt)
reg_all_indEt_tidy
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_indEt_tidy), "indEt")


#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = gradfairEt  ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = gradfair_RQ1.4_data, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "indEt_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)

### 7.3 gradfairNe ----
indNe <- lm(gradfairNe ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = gradfair_RQ1.4_data)
sum <- summary(indNe)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "gradNe"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_indNe_tidy <- tidy(indNe)
reg_all_indNe_tidy
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_indNe_tidy), "indNe")

#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = gradfairNe  ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = gradfair_RQ1.4_data, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "indNe_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)

### 7.4 testfairEq ----
#'Create model.
collEq <- lm(testfairEq ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
             data = testfair_RQ2.4_data)
sum <- summary(collEq)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "testEq"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_collEq_tidy <- tidy(collEq)
reg_all_collEq_tidy
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_collEq_tidy), "collEq")

### 7.5 testfairEt ----
#'Create model.
collEt <- lm(testfairEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
             data = testfair_RQ2.4_data)
sum <- summary(collEt)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "testEt"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_collEt_tidy <- tidy(collEt)
reg_all_collEt_tidy
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_collEt_tidy), "collEt")

#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = testfairEt  ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = testfair_RQ2.4_data, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "collEt_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)

### 7.6 pilotfairnoex ----
#'Create model.
prNoex <- lm(pilotfairnoex ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
             data = pilotfair_RQ3.5_data)
sum <- summary(prNoex)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "prNoex"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_prNoex_tidy <- tidy(prNoex)
reg_all_prNoex_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_prNoex_tidy), "prNoex")

#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = pilotfairnoex  ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = pilotfair_RQ3.5_data, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "prNoex_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)

### 7.7 pilotfairchan ----
#'Create model.
prChance <- lm(pilotfairchan ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
               data = pilotfair_RQ3.5_data)
sum <- summary(prChance)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "prChance"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_prChance_tidy <- tidy(prChance)
reg_all_prChance_tidy
#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_prChance_tidy), "prChance")

### 7.8 pilotfairexpl ----
#'Create model.
prExpl <- lm(pilotfairexpl ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
             data = pilotfair_RQ3.5_data)
sum <- summary(prExpl)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "prExpl"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_prExpl_tidy <- tidy(prExpl)
reg_all_prExpl_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_prExpl_tidy), "prExpl")

### 7.9 pilotfairintern ----
#'Create model.
prInt <- lm(pilotfairintern ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
            data = pilotfair_RQ3.5_data)
sum <- summary(prInt)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "prInt"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
reg_all_prInt_tidy <- tidy(prInt)
reg_all_prInt_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(reg_all_prInt_tidy), "prInt")

#' Since not all assumptions are met, we are going to report the bootstrapped confidence intervals of the regression:
boot_results <- boot(statistic = f26_boot_regression, 
                     formula = pilotfairintern  ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                     data = pilotfair_RQ3.5_data, R = 10000)

set.seed(123)
write.xlsx(f27_boot_CI(), file = "output/201124_lm.xlsx", sheetName = "prInt_boot", 
           col.names = TRUE, row.names = TRUE, append = TRUE)

#' Save F-statistic values from all models as Excel sheet: 
write.xlsx(reg_all_F.statistic, file = "output/201124_lm_F-statistic.xlsx",
           col.names = TRUE, row.names = TRUE, append = TRUE)

#' Save p-values from all models as Excel sheet: 
write.xlsx(reg_all_p.values, file = "output/201124_lm_p-values.xlsx",
           col.names = TRUE, row.names = TRUE, append = TRUE)

#' Save R-squared values from all models as Excel sheet: 
write.xlsx(reg_all_R.squared, file = "output/201124_lm_R-squared.xlsx",
           col.names = TRUE, row.names = TRUE, append = TRUE)

#' Save adjusted R-squared values from all models as Excel sheet: 
write.xlsx(reg_all_adj.R.squared, file = "output/201124_lm_adj-R-squared.xlsx",
           col.names = TRUE, row.names = TRUE, append = TRUE)




#### 8. Analyze the vignette overlapping hypotheses ----

### 8.1 Translating concepts of distributive justice to those of procedural justice (SI-11.1) ----
#' We wondered, whether there were any connections between distributive justice at the individual level and procedural justice. Therefore we calculated a correlation matrix including all approaches from the two vignettes. 

#' Create dataset with all distributive (only individual level, because procedural justice is also measured at the individual level) and procedural justice items:
distr_proc <- fair_data_quant %>%
   select(id, gradfairEq, gradfairEt, gradfairNe, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern)

#' Correlation matrix
cor_distr_proc <- rcorr(as.matrix(distr_proc), type = "pearson")

cor_distr_proc[["r"]] <- round(cor_distr_proc[["r"]], 3)
cor_distr_proc[["P"]] <- round(cor_distr_proc[["P"]], 3)

write.xlsx(cor_distr_proc[["r"]], file = "output/201124_cor_distr_proc.xlsx", 
           sheetName = "Pearson - r",
           col.names = TRUE, row.names = TRUE, append = FALSE)
write.xlsx(cor_distr_proc[["P"]], file = "output/201124_cor_distr_proc.xlsx", 
           sheetName = "Pearson - p",
           col.names = TRUE, row.names = TRUE, append = TRUE)

#' Equality does not correlate with any of the proc. just. items.

#' Equity correlates with Chance and Criteria. Plot these two comparisons:
#' Plot Equity vs Chance:
distr_proc %>%
   ggplot(mapping = aes(x = gradfairEt, y = pilotfairchan)) + 
   geom_jitter( width = 0.3, height = 0.3)  +
   geom_smooth(method = lm, color = "black")

#' Plot Equity vs Criteria:
distr_proc %>%
   ggplot(mapping = aes(x = gradfairEt, y = pilotfairexpl)) + 
   geom_jitter( width = 0.3, height = 0.3)  +
   geom_smooth(method = lm, color = "black")

#' Need correlates with Gut feeling and Criteria. Plot these two comparisons:
#' Plot Need vs Gut feeling:
distr_proc %>%
   ggplot(mapping = aes(x = gradfairNe, y = pilotfairnoex)) + 
   geom_jitter( width = 0.3, height = 0.3)  +
   geom_smooth(method = lm, color = "black")

#' Plot Need vs Criteria:
distr_proc %>%
   ggplot(mapping = aes(x = gradfairNe, y = pilotfairexpl)) + 
   geom_jitter( width = 0.3, height = 0.3)  +
   geom_smooth(method = lm, color = "black")


### 8.2 Differences between Eq and Et at ind and coll level ----

#' Is the difference between the equality approach and the equity approach bigger in vignette 1 (individual level) than in vignette 3 (collective level)?  

#' Build Dataframe (long) and show means.
H4.1_long <- f13_buildEEDataFrame1(fair_data_quant)
by(H4.1_long$Score,list(H4.1_long$Vignette,H4.1_long$Question),mean)
by(H4.1_long$Score,list(H4.1_long$Vignette,H4.1_long$Question),sd)
H4.1_long_diff <- f14_buildEEDataFrame2(fair_data_quant)
by(H4.1_long_diff$Diff,H4.1_long_diff$Vignette,mean)
by(H4.1_long_diff$Diff,H4.1_long_diff$Vignette,sd)
#' The means in testfair are almost exactly the same as in gradfair.
boxplot(Diff~Vignette, data=H4.1_long_diff)


#' The variance in testfair looks bigger than in gradfair.  
#' *Test with Levene's test*  
leveneTest(Diff~Vignette, H4.1_long_diff)
#' The variance in testfair is bigger than in gradfair.

#' Since the means do not differ, also the linear mixed model does not show any effect of the vignette:  
#' Linear Mixed Model. 
LMM<-lmer(Diff~Vignette+(1|id),data=H4.1_long_diff)
summary(LMM)

boot_results <- boot(statistic = f26_boot_regression, 
                     formula = Diff~Vignette+(1|id), 
                     data = H4.1_long_diff, R = 2000)

set.seed(123)
as.data.frame(boot_results$t0)
confint(boot_results)

f35_boot_CI()
write.xlsx(f35_boot_CI(), file = "output/201124_bootCI.xlsx", sheetName = "testEqEt", 
           col.names = TRUE, row.names = TRUE, append = TRUE)


### 8.3 Testing RQ2.5 ----

### 8.3.1 all demographics in one model - gradfairEq - testfairEq ----
#' Can demographics explain the difference between equality at the individual and the collective level?  

#' There is no need for concern because of the assumptions, so we can report the "normal" regression results.
#' Prepare data
gradfair_testfair <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, gradfairEq, gradfairEt, testfairEq, testfairEt) %>%
   filter(city != "Don't know") #this category is not interpretable and therefore excluded from the regression analyses (18 cases)

gradfair_testfair <- gradfair_testfair %>%
   mutate(gradEqtestEq = gradfairEq - testfairEq) %>%
   mutate(gradEttestEt = gradfairEt - testfairEt) 

#'Create model.
distindcollEq <- lm(gradEqtestEq ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                    data = gradfair_testfair)

sum <- summary(distindcollEq)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "distindcollEq"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
distindcollEq_tidy <- tidy(distindcollEq)
distindcollEq_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(distindcollEq_tidy), "distindcollEq")

#' Boxplots for Equality at the individual and the collective level depending on previous knowledge about wastewater treatment.
Eq_knowledge <- fair_data_quant %>%
   select(id, gradfairEq, testfairEq, knowledge1) %>%
   gather(approach, fairness, gradfairEq:testfairEq)

Eq_knowledge <- Eq_knowledge %>%
   mutate(new_group = ifelse(approach == "gradfairEq" & knowledge1 == 1, "Ind.yes", "placeholder")) %>%
   mutate(new_group = ifelse(approach == "gradfairEq" & knowledge1 == 0, "Ind.no", new_group)) %>%
   mutate(new_group = ifelse(approach == "testfairEq" & knowledge1 == 1, "Coll.yes", new_group)) %>%
   mutate(new_group = ifelse(approach == "testfairEq" & knowledge1 == 0, "Coll.no", new_group)) 

#Boxplot.
p <- Eq_knowledge %>%
   ggplot(aes(x = new_group, y = fairness)) +
   geom_boxplot(fatten = 2) + 
   geom_jitter(width = 0.3, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of Equality',
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6), 
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Distributive Justice', 
                    labels = c("individual \n prev.KNWL", "individual \n no prev.KNWL", "collective \n prev.KNWL", "collective \n no prev.KNWL")) +
   theme(strip.background = element_blank(),
         strip.text.x = element_blank())
p
ggsave("output/graphs_for_paper/box_Eq_knowledge.png", p, width = 140, height = 90, unit = "mm")

### 8.3.2 all demographics in one model - gradfairEt - testfairEt ----
#' Can demographics explain the difference between equity at the individual and the collective level?  

#' There is no need for concern because of the assumptions, so we can report the "normal" regression results.
#'Create model.
distindcollEt <- lm(gradEttestEt ~ sex + age + education + city + reward + religion + engagement + finance + politic_lcr + knowledge1 + knowledge_points, 
                    data = gradfair_testfair)

sum <- summary(distindcollEt)

#'Save F, p, R-squared and adjusted R-squared to the dataframes:
ana_var <- "distindcollEt"

reg_all_F.statistic <- reg_all_F.statistic %>%
   mutate(!!quo_name(ana_var) := sum$fstatistic[["value"]])

reg_all_p.values <- reg_all_p.values %>%
   mutate(!!quo_name(ana_var) := pf(sum$fstatistic[["value"]], sum$fstatistic[["numdf"]], sum$fstatistic[["dendf"]], lower.tail=FALSE))

reg_all_R.squared <- reg_all_R.squared %>%
   mutate(!!quo_name(ana_var) := sum$r.squared)

reg_all_adj.R.squared <- reg_all_adj.R.squared %>%
   mutate(!!quo_name(ana_var) := sum$adj.r.squared)

#'Bring the regression model in a presentable form:
distindcollEt_tidy <- tidy(distindcollEt)
distindcollEt_tidy

#' Save regression model as Excel sheet: 
f24_lm_savetable(as.data.frame(distindcollEt_tidy), "distindcollEt")


#### 9. Compare university degree to others - pilot ----
procuni <- f36_procUni(fair_data_quant, fair_data_quant$education=="University degree", test=wilcox.test)

#' Calculate r to report in Paper.
r_uniNoex <- abs((qnorm(procuni[4]/2))/sqrt(472))
r_uniChan <- abs((qnorm(procuni[8]/2))/sqrt(472))
r_uniExpl <- abs((qnorm(procuni[12]/2))/sqrt(472))
r_uniIntern <- abs((qnorm(procuni[16]/2))/sqrt(472))

r <- c(r_uniNoex, r_uniChan, r_uniExpl, r_uniIntern)

#' Bonferroni adjustment.
p <- c((procuni[4]), (procuni[8]), (procuni[12]), (procuni[16]))
bonfp <- p.adjust(p, method = "bonferroni", n = 4)

procuni <- rbind(procuni, bonfp, r)

#' Export data to xlsx.
write.xlsx(procuni, file = "output/201124_pilot_uni_vs_others.xlsx", col.names = TRUE, row.names = TRUE, append = TRUE)


#### 10. Compare political orientation left to others - distributive (ind and coll) ----
indcoll <- f37_indColl(fair_data_quant, fair_data_quant$politic_lcr=="left",test=wilcox.test)

#' Calculate r to report in Paper.
r_indEq <- abs((qnorm(indcoll[4]/2))/sqrt(472))
r_indEt <- abs((qnorm(indcoll[8]/2))/sqrt(472))
r_collEq <- abs((qnorm(indcoll[12]/2))/sqrt(472))
r_collEt <- abs((qnorm(indcoll[16]/2))/sqrt(472))
r_diffEq <- abs((qnorm(indcoll[20]/2))/sqrt(472))
r_diffEt <- abs((qnorm(indcoll[24]/2))/sqrt(472))
r_diffind <- abs((qnorm(indcoll[28]/2))/sqrt(472))
r_diffcoll <- abs((qnorm(indcoll[32]/2))/sqrt(472))

r <- c(r_indEq, r_indEt, r_collEq, r_collEt, r_diffEq, r_diffEt, r_diffind, r_diffcoll)

#' Bonferroni adjustment.
p <- c((indcoll[4]), (indcoll[8]), (indcoll[12]), (indcoll[16]), (indcoll[20]), (indcoll[24]), (indcoll[28]),(indcoll[32]))
bonfp <- p.adjust(p, method = "bonferroni", n = 8)

indcoll <- rbind(indcoll, bonfp, r)

#' Export data to xlsx.
write.xlsx(indcoll, file = "output/201124_distr_political_left.xlsx", col.names = TRUE, row.names = TRUE, append = TRUE)

## ================================================================ ## 
## =============================  END ============================= ##
## ================================================================ ##