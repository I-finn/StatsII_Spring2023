## ===================================================================== ##
## Project:     Functions Needed for Data Analysis
## File:        3.2_fairness_analysis_func.R
## Created:     15.07.2019
## Authors:     Sara Schmid, sara.schmid@eawag.ch
## Description: Functions, that are needed in the script...
##                ...3.1_fairness_analysis; edited for ERIC
## Last change: 24.11.2020 by Sara
## ===================================================================== ##

f1_demo_savetable <- function(data, sht_nm) {
   write.xlsx(data, file = "output/201124_demographics.xlsx", sheetName = sht_nm, 
              col.names = TRUE, row.names = TRUE, append = TRUE)
}
#Saves different descriptive values of demographics into one Excel file.


f2_descrstat_distr <- function(data, colana1, colana2) {
   ana_var1 <- enquo(colana1)
   ana_var2 <- enquo(colana2)
   
   data %>%
      group_by(!!ana_var1) %>%
      count(!!ana_var2) %>%
      mutate(percent = prop.table(n)*100)
}
#Descriptives: distributions.


f3_descrstat_centr <- function(data, colana1, colana2) {
   ana_var1 <- enquo(colana1)
   ana_var2 <- enquo(colana2)
   
   data %>%
      group_by(!!ana_var1) %>%
      summarise(min = min(!!ana_var2, na.rm=TRUE),
                max = max(!!ana_var2, na.rm=TRUE),
                median = median(!!ana_var2, na.rm=TRUE), 
                mean = mean(!!ana_var2, na.rm=TRUE), 
                sd = sd(!!ana_var2, na.rm=TRUE),
                N = sum(!is.na(!!ana_var2)))
}
#Descriptives: central tendencies.


f4_cursit_savetable <- function(data, sht_nm) {
   write.xlsx(data, file = "output/201124_cursit.xlsx", sheetName = sht_nm, 
              col.names = TRUE, row.names = TRUE, append = TRUE)
}
#Saves different descriptives values from vignette "Current Situation" into one Excel file.


f5_gradfair_savetable <- function(data, sht_nm) {
   write.xlsx(data, file = "output/201124_gradfair.xlsx", sheetName = sht_nm, 
              col.names = TRUE, row.names = TRUE, append = TRUE)
}
#Saves different descriptives values from vignette "Graduelle EInführung von KLARA" into one Excel file.


f6_multipleboxplot <- function(data, colana1, colana2) {
   ana_var1 <- enquo(colana1)
   ana_var2 <- enquo(colana2)
   
   data %>%
      ggplot(aes_q(x = ana_var1, y = ana_var2)) +
      geom_boxplot() +
      geom_jitter(width = 0.2, height = 0.3, color = "orange", size = 1) +
      labs(x = "Approach", y = "Fairness") +
      scale_y_continuous(breaks = c(1, 2, 3, 4, 5, 6),
                         labels = c("not at all fair", "not fair", "rather not fair", "rather fair", "fair", "totally fair")) +
      scale_x_discrete(labels = xscalelabels)
}
#Boxplots for all variables from one vignette.


f7_pilotfair_savetable <- function(data, sht_nm) {
   write.xlsx(data, file = "output/201124_pilotfair.xlsx", sheetName = sht_nm, 
              col.names = TRUE, row.names = TRUE, append = TRUE)
}
#Saves different descriptives values from vignette "Pilotprojekt" into one Excel file.


f8_testfair_savetable <- function(data, sht_nm) {
   write.xlsx(data, file = "output/201124_testfair.xlsx", sheetName = sht_nm, 
              col.names = TRUE, row.names = TRUE, append = TRUE)
}
#Saves different descriptives values from vignette "Testphase" into one Excel file.


f9_which_model <- function(dataset) {
   m0 <- gls(fairness ~ approach, data = dataset, method = "ML")
   m1 <- lme(fairness ~ approach, data = dataset, random = ~1|id, method = "ML")
   summary(m0)
   summary(m1)
   anova(m0, m1)
}
#Compares a basic model (only intercept) to a model that has a random intercept and shows, whether the two models differ significantly.


f10_rmANOVA <- function (dataset) {
   m2 <- ezANOVA(data = dataset, dv= .(fairness), wid = .(id), within = .(approach), detailed = TRUE)
   m2
}
#Repeated measures ANOVA.


f12_barcharts_vign <- function (data, titletext) {
   data %>%
      ggplot(aes(x = fairness))+ 
      facet_wrap(~ approach, scales='free_x', nrow = 1) + 
      geom_bar() +
      labs(x = "Fairness of the approach", y = "Count", title = titletext) 
}
#Creates barcharts of the different approaches per vignette.


f13_del_incons_cases <- function() {
   testfair_data_wide_no_incons <- testfair_data_wide %>%
      filter(testfairEq != 6 | testfairEt != 6) %>%
      filter(testfairEq == 6 & testalloc == 11 | testfairEq != 6) %>%
      filter(testfairEt == 6 & testalloc == 1 | testfairEt != 6)
}
#Deletes inconsistent cases from the dataset. 597 and 1023 are filtered in both Eq and testalloc inconsistent as well as in Et and testalloc inconsistent. Therefore instead of 47 cases (33 from Et and 14 from Eq), only 45 are deleted


#Function by RV: We build a data frame that contains one row for each relevant response (gradfair / testfair; Equity-Equality).
f13_buildEEDataFrame1<-function(d) {
   # equality score from vignette 1
   d1<-d[,c("id","gradfairEq")]
   colnames(d1)[2]<-"Score"
   d1$Question<-"Equality"
   d1$Vignette<-"grad"
   
   # equity score from vignette 1
   d2<-d[,c("id","gradfairEt")]
   colnames(d2)[2]<-"Score"
   d2$Question<-"Equity"
   d2$Vignette<-"grad"
   
   # equality score from vignette 3
   d3<-d[,c("id","testfairEq")]
   colnames(d3)[2]<-"Score"
   d3$Question<-"Equality"
   d3$Vignette<-"test"
   
   # equity score from vignette 1
   d4<-d[,c("id","testfairEt")]
   colnames(d4)[2]<-"Score"
   d4$Question<-"Equity"
   d4$Vignette<-"test"
   dnew<-rbind(d1,d2,d3,d4)
   
   #convert to factors
   dnew$Question<-factor(dnew$Question)
   dnew$Vignette<-factor(dnew$Vignette)
   dnew
}


#Function by RV: We build a data frame that contains one row for each person and vignette and the differences between the score of equity and equality (gradfair / testfair; Equity-Equality).
f14_buildEEDataFrame2<-function(d) {
   d1<-data.frame(cbind(d$id, d$gradfairEt-d$gradfairEq))
   colnames(d1)<-c("id","Diff")
   d1$Vignette<-"grad"
   d2<-data.frame(cbind(d$id, d$testfairEt-d$testfairEq))
   colnames(d2)<-c("id","Diff")
   d2$Vignette<-"test"
   dnew<-rbind(d1,d2)
   dnew$Vignette<-factor(dnew$Vignette)
   dnew
}


#Function for a posthoc pairwise.t.test, but it also prints t-values and dfs.
f21_pairwise.t.test.with.t.and.df <- function (x, g, p.adjust.method = p.adjust.methods, pool.sd = !paired, 
                                               paired = FALSE, alternative = c("two.sided", "less", "greater"), 
                                               ...) 
{
   if (paired & pool.sd) 
      stop("pooling of SD is incompatible with paired tests")
   DNAME <- paste(deparse(substitute(x)), "and", deparse(substitute(g)))
   g <- factor(g)
   p.adjust.method <- match.arg(p.adjust.method)
   alternative <- match.arg(alternative)
   if (pool.sd) {
      METHOD <- "t tests with pooled SD"
      xbar <- tapply(x, g, mean, na.rm = TRUE)
      s <- tapply(x, g, sd, na.rm = TRUE)
      n <- tapply(!is.na(x), g, sum)
      degf <- n - 1
      total.degf <- sum(degf)
      pooled.sd <- sqrt(sum(s^2 * degf)/total.degf)
      compare.levels <- function(i, j) {
         dif <- xbar[i] - xbar[j]
         se.dif <- pooled.sd * sqrt(1/n[i] + 1/n[j])
         t.val <- dif/se.dif
         if (alternative == "two.sided") 
            2 * pt(-abs(t.val), total.degf)
         else pt(t.val, total.degf, lower.tail = (alternative == 
                                                     "less"))
      }
      compare.levels.t <- function(i, j) {
         dif <- xbar[i] - xbar[j]
         se.dif <- pooled.sd * sqrt(1/n[i] + 1/n[j])
         t.val = dif/se.dif 
         t.val
      }       
   }
   else {
      METHOD <- if (paired) 
         "paired t tests"
      else "t tests with non-pooled SD"
      compare.levels <- function(i, j) {
         xi <- x[as.integer(g) == i]
         xj <- x[as.integer(g) == j]
         t.test(xi, xj, paired = paired, alternative = alternative, 
                ...)$p.value
      }
      compare.levels.t <- function(i, j) {
         xi <- x[as.integer(g) == i]
         xj <- x[as.integer(g) == j]
         t.test(xi, xj, paired = paired, alternative = alternative, 
                ...)$statistic
      }
      compare.levels.df <- function(i, j) {
         xi <- x[as.integer(g) == i]
         xj <- x[as.integer(g) == j]
         t.test(xi, xj, paired = paired, alternative = alternative, 
                ...)$parameter
      }
   }
   PVAL <- pairwise.table(compare.levels, levels(g), p.adjust.method)
   TVAL <- pairwise.table.t(compare.levels.t, levels(g), p.adjust.method)
   if (pool.sd) 
      DF <- total.degf
   else
      DF <- pairwise.table.t(compare.levels.df, levels(g), p.adjust.method)           
   ans <- list(method = METHOD, data.name = DNAME, p.value = PVAL, 
               p.adjust.method = p.adjust.method, t.value = TVAL, dfs = DF)
   class(ans) <- "pairwise.htest"
   ans
}
pairwise.table.t <- function (compare.levels.t, level.names, p.adjust.method) 
{
   ix <- setNames(seq_along(level.names), level.names)
   pp <- outer(ix[-1L], ix[-length(ix)], function(ivec, jvec) sapply(seq_along(ivec), 
                                                                     function(k) {
                                                                        i <- ivec[k]
                                                                        j <- jvec[k]
                                                                        if (i > j)
                                                                           compare.levels.t(i, j)               
                                                                        else NA
                                                                     }))
   pp[lower.tri(pp, TRUE)] <- pp[lower.tri(pp, TRUE)]
   pp
}

#Calculates the effectsize. Author: Andy Field
f23_rFromWilcox <- function(wilcoxModel, N) {
   z <- stats::qnorm(wilcoxModel$p.value / 2)
   r <- z / sqrt(N)
   cat(wilcoxModel$data.name, "Effect Size, r = ", r)
}


f24_lm_savetable <- function(data, sht_nm) {
   write.xlsx(data, file = "output/201124_lm.xlsx", sheetName = sht_nm, 
              col.names = TRUE, row.names = TRUE, append = TRUE)
}
#Saves different lms into one Excel file.


f26_boot_regression <- function(formula, data, indices) {
   d <- data[indices,]
   fit <- lm(formula, data = d)
   return(coef(fit))
}


f27_boot_CI <- function() {
   boot_results_combined <- as.data.frame(boot_results$t0)
   x <- confint(boot_results)
   boot_results_combined <- cbind(boot_results_combined, x)
   boot_results_combined
}


f29_group_religion <- function(data){
   data %>%
      mutate(religion_lh = 0) %>%
      mutate(religion_lh = ifelse(religion == 1 |
                                     religion == 2 |
                                     religion == 3, 1, religion_lh)) %>%
      mutate(religion_lh = ifelse(religion == 4 |
                                     religion == 5 |
                                     religion == 6, 2, religion_lh))
}


f30_group_engagement <- function(data){
   data %>%
      mutate(engagement_lh = 0) %>%
      mutate(engagement_lh = ifelse(engagement == 1 |
                                       engagement == 2 |
                                       engagement == 3, 1, engagement_lh)) %>%
      mutate(engagement_lh = ifelse(engagement == 4 |
                                       engagement == 5 |
                                       engagement == 6, 2, engagement_lh))
}


f31_religion_ana_diff <- function (data, sht_nm) {
   d <- data %>%
      select(religion_lh, diff)
   
   d <- split(d, d$religion_lh)
   
   ML <- mean(unlist(d[["low"]][["diff"]]))
   SDL <- sd(unlist(d[["low"]][["diff"]]))
   NL <- length(d[["low"]][["diff"]])
   MH <- mean(unlist(d[["high"]][["diff"]]))
   SDH <- sd(unlist(d[["high"]][["diff"]]))
   NH <- length(d[["high"]][["diff"]])
   
   
   
   #' Wilcoxon. Test religious people against non religious people.
   wilcox <- wilcox.test(d$low$diff, d$high$diff)
   wilcox_p <- wilcox[["p.value"]]
   wilcox_W <- wilcox[["statistic"]][["W"]]
   
   M_SD <- do.call(rbind, Map(data.frame, 
                              ML = ML, SDL = SDL,NL = NL, MH = MH, SDH = SDH, NH = NH, wilcox_W = wilcox_W, wilcox_p = wilcox_p))
   
   write.xlsx(M_SD, file = "output/201124_religion_diff_M_SD.xlsx", 
              sheetName = sht_nm, col.names = TRUE, row.names = TRUE, append = TRUE)
}


f32_engagement_ana_diff <- function (data, sht_nm) {
   d <- data %>%
      select(engagement_lh, diff)
   
   d <- split(d, d$engagement_lh)
   
   ML <- mean(unlist(d[["low"]][["diff"]]))
   SDL <- sd(unlist(d[["low"]][["diff"]]))
   NL <- length(d[["low"]][["diff"]])
   MH <- mean(unlist(d[["high"]][["diff"]]))
   SDH <- sd(unlist(d[["high"]][["diff"]]))
   NH <- length(d[["high"]][["diff"]])
   
   
   
   #' Wilcoxon. Test religious people against non religiious people.
   wilcox <- wilcox.test(d$low$diff, d$high$diff)
   wilcox_p <- wilcox[["p.value"]]
   wilcox_W <- wilcox[["statistic"]][["W"]]
   
   M_SD <- do.call(rbind, Map(data.frame, 
                              ML = ML, SDL = SDL,NL = NL, MH = MH, SDH = SDH, NH = NH, wilcox_W = wilcox_W, wilcox_p = wilcox_p))
   
   write.xlsx(M_SD, file = "output/201124_engagement_diff_M_SD.xlsx", 
              sheetName = sht_nm, col.names = TRUE, row.names = TRUE, append = TRUE)
}


f33_religion_ana_orig <- function(data, sht_nm1, sht_nm2) {
   
   d <- data %>%
      select(religion_lh, var1, var2, var3)
   
   d <- split(d, d$religion_lh)
   
   #' M, SD, N for the original variables.
   EqML <- mean(unlist(d[["low"]][["var1"]]))
   EqSDL <- sd(unlist(d[["low"]][["var1"]]))
   EqNL <- length(d[["low"]][["var1"]])
   EqMH <- mean(unlist(d[["high"]][["var1"]]))
   EqSDH <- sd(unlist(d[["high"]][["var1"]]))
   EqNH <- length(d[["high"]][["var1"]])
   EtML <- mean(unlist(d[["low"]][["var2"]]))
   EtSDL <- sd(unlist(d[["low"]][["var2"]]))
   EtNL <- length(d[["low"]][["var2"]])
   EtMH <- mean(unlist(d[["high"]][["var2"]]))
   EtSDH <- sd(unlist(d[["high"]][["var2"]]))
   EtNH <- length(d[["high"]][["var2"]])
   NeML <- mean(unlist(d[["low"]][["var3"]]))
   NeSDL <- sd(unlist(d[["low"]][["var3"]]))
   NeNL <- length(d[["low"]][["var3"]])   
   NeMH <- mean(unlist(d[["high"]][["var3"]]))
   NeSDH <- sd(unlist(d[["high"]][["var3"]]))
   NeNH <- length(d[["high"]][["var3"]])
   
   M_SD <- do.call(rbind, Map(data.frame, 
                              EqML = EqML, EqSDL = EqSDL, EqNL = EqNL, EqMH = EqMH, EqSDH = EqSDH, EqNH = EqNH,
                              EtML = EtML, EtSDL = EtSDL, EtNL = EtNL, EtMH = EtMH, EtSDH = EtSDH, EtNH = EtNH,
                              NeML = NeML, NeSDL = NeSDL, NeNL = NeNL, NeMH = NeMH, NeSDH = NeSDH, NeNH = NeNH))
   
   write.xlsx(M_SD, file = "output/201124_religion_orig.xlsx", 
              sheetName = sht_nm1, col.names = TRUE, row.names = TRUE, append = TRUE)
   
   #' Wilcoxon. Test religious people against non religiious people.
   wilcoxEq <- wilcox.test(d[["low"]][["var1"]], d[["high"]][["var1"]])
   wilcoxEq_p <- wilcoxEq[["p.value"]]
   wilcoxEq_W <- wilcoxEq[["statistic"]][["W"]]
   
   wilcoxEt <- wilcox.test(d[["low"]][["var2"]], d[["high"]][["var2"]])
   wilcoxEt_p <- wilcoxEt[["p.value"]]
   wilcoxEt_W <- wilcoxEt[["statistic"]][["W"]]
   
   wilcoxNe <- wilcox.test(d[["low"]][["var3"]], d[["high"]][["var3"]])
   wilcoxNe_p <- wilcoxNe[["p.value"]]
   wilcoxNe_W <- wilcoxNe[["statistic"]][["W"]]
   
   grad_wilcox <- do.call(rbind, Map(data.frame, 
                                     wilcoxEq_W = wilcoxEq_W, wilcoxEq_p = wilcoxEq_p, 
                                     wilcoxEt_W = wilcoxEt_W, wilcoxEt_p = wilcoxEt_p, 
                                     wilcoxNe_W = wilcoxNe_W, wilcoxNe_p = wilcoxNe_p))
   
   write.xlsx(grad_wilcox, file = "output/201124_religion_orig.xlsx", 
              sheetName = sht_nm2, col.names = TRUE, row.names = TRUE, append = TRUE)
}


f34_engagement_ana_orig <- function(data, sht_nm1, sht_nm2) {
   
   d <- data %>%
      select(engagement_lh, var1, var2, var3)
   
   d <- split(d, d$engagement_lh)
   
   #' M, SD, N for the original variables.
   EqML <- mean(unlist(d[["low"]][["var1"]]))
   EqSDL <- sd(unlist(d[["low"]][["var1"]]))
   EqNL <- length(d[["low"]][["var1"]])
   EqMH <- mean(unlist(d[["high"]][["var1"]]))
   EqSDH <- sd(unlist(d[["high"]][["var1"]]))
   EqNH <- length(d[["high"]][["var1"]])
   EtML <- mean(unlist(d[["low"]][["var2"]]))
   EtSDL <- sd(unlist(d[["low"]][["var2"]]))
   EtNL <- length(d[["low"]][["var2"]])
   EtMH <- mean(unlist(d[["high"]][["var2"]]))
   EtSDH <- sd(unlist(d[["high"]][["var2"]]))
   EtNH <- length(d[["high"]][["var2"]])
   NeML <- mean(unlist(d[["low"]][["var3"]]))
   NeSDL <- sd(unlist(d[["low"]][["var3"]]))
   NeNL <- length(d[["low"]][["var3"]])   
   NeMH <- mean(unlist(d[["high"]][["var3"]]))
   NeSDH <- sd(unlist(d[["high"]][["var3"]]))
   NeNH <- length(d[["high"]][["var3"]])
   
   M_SD <- do.call(rbind, Map(data.frame, 
                              EqML = EqML, EqSDL = EqSDL, EqNL = EqNL, EqMH = EqMH, EqSDH = EqSDH, EqNH = EqNH,
                              EtML = EtML, EtSDL = EtSDL, EtNL = EtNL, EtMH = EtMH, EtSDH = EtSDH, EtNH = EtNH,
                              NeML = NeML, NeSDL = NeSDL, NeNL = NeNL, NeMH = NeMH, NeSDH = NeSDH, NeNH = NeNH))
   
   write.xlsx(M_SD, file = "output/201124_engagement_orig.xlsx", 
              sheetName = sht_nm1, col.names = TRUE, row.names = TRUE, append = TRUE)
   
   #' Wilcoxon. Test religious people against non religiious people.
   wilcoxEq <- wilcox.test(d[["low"]][["var1"]], d[["high"]][["var1"]])
   wilcoxEq_p <- wilcoxEq[["p.value"]]
   wilcoxEq_W <- wilcoxEq[["statistic"]][["W"]]
   
   wilcoxEt <- wilcox.test(d[["low"]][["var2"]], d[["high"]][["var2"]])
   wilcoxEt_p <- wilcoxEt[["p.value"]]
   wilcoxEt_W <- wilcoxEt[["statistic"]][["W"]]
   
   wilcoxNe <- wilcox.test(d[["low"]][["var3"]], d[["high"]][["var3"]])
   wilcoxNe_p <- wilcoxNe[["p.value"]]
   wilcoxNe_W <- wilcoxNe[["statistic"]][["W"]]
   
   grad_wilcox <- do.call(rbind, Map(data.frame, 
                                     wilcoxEq_W = wilcoxEq_W, wilcoxEq_p = wilcoxEq_p, 
                                     wilcoxEt_W = wilcoxEt_W, wilcoxEt_p = wilcoxEt_p, 
                                     wilcoxNe_W = wilcoxNe_W, wilcoxNe_p = wilcoxNe_p))
   
   write.xlsx(grad_wilcox, file = "output/201124_engagement_orig.xlsx", 
              sheetName = sht_nm2, col.names = TRUE, row.names = TRUE, append = TRUE)
}


f35_boot_CI <- function() {
   boot_results_combined <- as.data.frame(boot_results$t0)
   boot_results_combined <- boot_results_combined %>%
      na.omit()
   x <- confint(boot_results)
   boot_results_combined <- cbind(boot_results_combined, x)
   boot_results_combined
}


f36_procUni<-function(d,group,test=t.test) {
   # test whether group makes a difference in the evalautions of process dimensions
   h<-unclass(by(d$pilotfairnoex,group,mean))
   te<-test(d$pilotfairnoex~group)
   h<-c(h,te$statistic,te$p.value)
   
   h1<-unclass(by(d$pilotfairchan,group,mean))
   te<-test(d$pilotfairchan~group)
   h1<-c(h1,te$statistic,te$p.value)
   h<-cbind(h,h1)
   
   h1<-unclass(by(d$pilotfairexpl,group,mean))
   te<-test(d$pilotfairexpl~group)
   h1<-c(h1,te$statistic,te$p.value)
   h<-cbind(h,h1)
   
   h1<-unclass(by(d$pilotfairintern,group,mean))
   te<-test(d$pilotfairintern~group)
   h1<-c(h1,te$statistic,te$p.value)
   h<-cbind(h,h1)
   
   colnames(h)<-c("Gut feeling","Random","Criteria","Voluntary")
   rownames(h)[nrow(h)]<-"p"
   h}


f37_indColl<-function(d,group,test) {
   # compare individual and collective evaluationms according to condition group
   h<-unclass(by(d$gradfairEq,group,mean))
   if (!is.null(test)) {
      te<-test(d$gradfairEq~group)
      h<-c(h,te$statistic,te$p.value)
   }
   
   h1<-unclass(by(d$gradfairEt,group,mean))
   if (!is.null(test)) {
      te<-test(d$gradfairEt~group)
      h1<-c(h1,te$statistic,te$p.value)
   }
   h<-cbind(h,h1)
   
   h1<-unclass(by(d$testfairEq,group,mean))
   if (!is.null(test)) {
      te<-test(d$testfairEq~group)
      h1<-c(h1,te$statistic,te$p.value)
   }
   h<-cbind(h,h1)
   
   h1<-unclass(by(d$testfairEt,group,mean))
   if (!is.null(test)) {
      te<-test(d$testfairEt~group)
      h1<-c(h1,te$statistic,te$p.value)
   }
   h<-cbind(h,h1)
   
   h1<-unclass(by((d$gradfairEq-d$testfairEq),group,mean))
   if (!is.null(test)) {
      te<-test((d$gradfairEq-d$testfairEq)~group)
      h1<-c(h1,te$statistic,te$p.value)
   }
   h<-cbind(h,h1)
   
   h1<-unclass(by((d$gradfairEt-d$testfairEt),group,mean))
   if (!is.null(test)) {
      te<-test((d$gradfairEt-d$testfairEt)~group)
      h1<-c(h1,te$statistic,te$p.value)
   }
   h<-cbind(h,h1)
   
   h1<-unclass(by((d$gradfairEq-d$gradfairEt),group,mean))
   if (!is.null(test)) {
      te<-test((d$gradfairEq-d$gradfairEt)~group)
      h1<-c(h1,te$statistic,te$p.value)
   }
   h<-cbind(h,h1)
   
   h1<-unclass(by((d$testfairEq-d$testfairEt),group,mean))
   if (!is.null(test)) {
      te<-test((d$testfairEq-d$testfairEt)~group)
      h1<-c(h1,te$statistic,te$p.value)
   }
   h<-cbind(h,h1)
   
   
   colnames(h)<-c("ind.Equality","ind.Equity","Coll.Equality","Coll.Equity","Diff.Equality","Diff.Equity","diff.ind","diff.coll")
   if (!is.null(test)) {
      rownames(h)[3:4]<-c("Test","p")
   }
   h}

