#' *****************************************************************
#' > Project:     Graphs \
#' > File:        4_graphs_for_paper.R \
#' > Created:     22.07.2019 \
#' > Authors:     Sara Schmid, sara.schmid@eawag.ch \
#' > Description: Create nice graphs for paper  \
#' > Last change: 24.11.2020 by Sara \



#### 1. Set Up ----

### 1.1. Import data ----

#' Run the script "datacleaning" to get the datafile needed for the following analyses.
source("scripts/1.1_fairness_cleaning.R")
#' Run the script with the functions needed for the following analyses. 
source("scripts/3.2_fairness_analysis_func.R")


### 1.2. Functions ----
f_layout_demo <- function() {
   theme_bw() +
      theme(axis.line = element_line(colour = "black"),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            panel.border = element_blank(),
            panel.background = element_blank(),
            axis.text.x = element_text(size = 10, colour = "black"),
            axis.title.x = element_text(size = 12, colour = "black"),
            axis.title.y = element_text(size = 12, colour = "black"),
            axis.text.y = element_text(size = 10, colour = "black"),
            plot.title = element_text(size = 15, colour = "black"),
            legend.title = element_text(size = 12, colour = "black"),
            legend.text = element_text(size = 10, colour = "black"),
            legend.key.size = unit(0.75, 'lines'), 
            legend.position = "right",
            strip.text.x = element_text(size=15),
            strip.background = element_blank()) 
}

f_colors_sz <- c('#FFFFC4','#FFDE21','#FFAE51','#FF656C','#FF2DA5','#9712FA','#000000')

single_col_bar <- geom_bar(fill = 'white', color = 'black', size = 0.5)

min.mean.sd.max <- function(x) {
   r <- c(min(x), mean(x) - sd(x), mean(x), mean(x) + sd(x), max(x))
   names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
   r
}

#### 2. Descriptives demographics ----

#' Sex
p <- fair_data_quant %>%
   ggplot(aes(x = sex)) +
   single_col_bar +
   labs(x = "Gender") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   f_layout_demo() 
p
ggsave("output/graphs_for_paper/barchart_sex.png", p, width = 80, height = 90, unit = "mm")


#' Age
p <- fair_data_quant %>%
   ggplot(aes(x = age))+ 
   single_col_bar +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_discrete(labs(x = "Age")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/barchart_age.png", p, width = 80, height = 90, unit = "mm")


#' Size of place of residence
p <- fair_data_quant %>%
ggplot(aes(x = as.numeric(city))) + 
   single_col_bar +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(labs(x = "Size of place of residence"), 
                      breaks = c(1,2,3,4,5,6,7), 
                      labels = c("Less than\n2.000","Up to\n5.000","Up to\n20.000","Up to\n50.000","Up to\n100.000","100.000\nor more", "I don't\nknow")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/barchart_city.png", p, width = 120, height = 80, unit = "mm")


#' Highest education
fair_data_quant$education <- factor(fair_data_quant$education, labels = c("SecS","BVoc","HigS","HVoc","UniD"))

p <- fair_data_quant %>%
   ggplot(aes(x = education))+ 
   single_col_bar +
   labs(x = "Highest education") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/barchart_education.png", p, width = 80, height = 90, unit = "mm")


#' Tenant
p <- fair_data_quant %>%
   ggplot(aes(x = tenant))+ 
   single_col_bar +
   labs(x = "House owner or tenant") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_discrete(labels = c("Tenant", "House", "Apartment", "Parents")) +
   f_layout_demo() 
p
ggsave("output/graphs_for_paper/barchart_tenant.png", p, width = 80, height = 90, unit = "mm")


#' Wastewater
p <- fair_data_quant %>%
   ggplot(aes(x = wastewater))+ 
   single_col_bar +
   labs(x = "Wastewater disposal at home") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 450), expand = c(0, 0), breaks = seq(0,450, by = 50)) +
   scale_x_discrete(labels = c("Central", "Package P", "Pit", "Manure", "Don't know", "Other")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/barchart_wastewater.png", p, width = 180, height = 80, unit = "mm")


#' Previous knowledge of wastewater treatment
p <- fair_data_quant %>%
   ggplot(aes(x = knowledge1))+ 
   single_col_bar +
   labs(x = "Previous knowledge of\nwastewater treatment") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 450), expand = c(0, 0), breaks = seq(0,450, by = 50)) +
   scale_x_discrete(labels = c("No previous\nengagement", "Previous\nengagement")) +
   f_layout_demo() 
p
ggsave("output/graphs_for_paper/barchart_knowledge1.png", p, width = 80, height = 90, unit = "mm")


#' Length of previous wastewater engagement 
p <- fair_data_quant %>%
   ggplot(aes(x = knowledge1howlong))+ 
   single_col_bar +
   labs(x = "Previous knowledge of\nwastewater treatment (in years)") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(breaks = c(1,2,3,4), 
                      labels = c("Less than 1", "1-5", "6-10", "10+\n")) +
   geom_density(aes(y=..count..), colour="#9712FA", adjust=4) +
      f_layout_demo() 
p
ggsave("output/graphs_for_paper/barchart_knowledge1howlong.png", p, width = 80, height = 90, unit = "mm")


#' Importance of reward
p <- fair_data_quant %>%
   ggplot(aes(x = reward))+ 
   single_col_bar +
   labs(x = "Importance of reward") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(limits = c(0.5,7),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all important", "2", "3", "4", "5", "6\nVery important")) +
   geom_density(aes(y=..count..), colour="#9712FA", adjust=4) +
   f_layout_demo() 
p
ggsave("output/graphs_for_paper/barchart_reward.png", p, width = 80, height = 90, unit = "mm")


#' Religiousness
p <- fair_data_quant %>%
   ggplot(aes(x = religion))+ 
   single_col_bar +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(labs(x = "Religiousness"),
                      limits = c(0.5,7), 
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all religious", "2", "3", "4", "5", "6\nVery religious")) +
   geom_density(aes(y=..count..), colour="#9712FA", adjust=4) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/barchart_religion.png", p, width = 80, height = 90, unit = "mm")


#' Social commitment
p <- fair_data_quant %>%
   ggplot(aes(x = engagement))+ 
   single_col_bar +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(labs(x = "Social commitment"),
                      limits = c(0.5,7), 
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all committed", "2", "3", "4", "5", "6\nVery committed")) +
   geom_density(aes(y=..count..), colour="#9712FA", adjust=4) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/barchart_engagement.png", p, width = 80, height = 90, unit = "mm")


#' Financial worries
p <- fair_data_quant %>%
   ggplot(aes(x = finance))+ 
   single_col_bar +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(labs(x = "Financial worries"),
                      limits=c(-0.5, 7), 
                      breaks = c(0,1,2,3,4,5,6),
                      labels = c("0\nNone","1\nNot at all big","2","3","4","5","6\nVery big")) +
   geom_density(aes(y=..count..), colour="#9712FA", adjust=4) +
   f_layout_demo() 
p
ggsave("output/graphs_for_paper/barchart_finance.png", p, width = 150, height = 80, unit = "mm")


#' Politic
p <- fair_data_quant %>%
   ggplot(aes(x = politic_lcr))+ 
   single_col_bar +
   labs(x = "Political orientation") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   f_layout_demo() 
p
ggsave("output/graphs_for_paper/barchart_politic_lcr.png", p, width = 80, height = 90, unit = "mm")


#' Number of points in wastewater knowledge quiz
p <- fair_data_quant %>%
ggplot(aes(x = knowledge_points))+ 
   single_col_bar +
   labs(x = "Number of points in \nwastewater knowledge quiz") +
   scale_y_continuous(name = "Number of respondents", limits = c(0, 300), expand = c(0, 0), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(limits = c(-1,9), 
                      breaks = c(0, 1, 2, 3, 4, 5, 6, 7, 8)) +
   geom_density(aes(y=..count..), colour="#9712FA", adjust=4) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/barchart_knowledge_points.png", p, width = 80, height = 90, unit = "mm")



#### 3. Descriptives vignettes ----

### 3.1. Current situation ----
p <- fair_data_quant %>%
   ggplot(aes(x = cursit1))+ 
   single_col_bar +
   labs(x = "Evaluation of current situation") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 225), expand = c(0, 0), breaks = seq(0, 225, by = 25)) +
   scale_x_continuous(limits=c(0, 7), 
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all fair","2","3","4","5","6\nTotally fair")) +
   geom_density(aes(y=..count..), colour="#9712FA", adjust=4) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/barchart_cursit.png", p, width = 80, height = 90, unit = "mm")


### 3.2. Gradual implementation ----
gradfair_data <- fair_data_quant %>%
   select(id, gradfairEq, gradfairEt, gradfairNe) %>%
   gather(approach, fairness, gradfairEq:gradfairNe)
gradfair_data$approach <- factor(gradfair_data$approach, labels = c("Equality", "Equity", "Need"))

#Barchart.
p <- gradfair_data %>%
   ggplot(aes(x = fairness, fill = approach, binwidth = 2))+ 
   geom_bar(position = position_dodge(), size = 0.5, color = 'black') +
   labs(x = "Fairness") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 225), expand = c(0, 0), breaks = seq(0, 225, by = 25)) +
   scale_x_continuous(name = 'Evaluation of distributive justice:\nindividual',
                      limits = c(0.5, 6.5),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all fair", "2", "3", "4", "5", "6\nTotally fair")) +
   scale_fill_manual(values=f_colors_sz) +
   guides(fill = guide_legend(nrow=2,byrow=TRUE, title = "Approach")) +
      f_layout_demo()
p
ggsave("output/graphs_for_paper/gradfair_approaches.png", p, width = 120, height = 90, unit = "mm")

#Boxplot.
p <- gradfair_data %>%
   ggplot(aes(x = approach, y = fairness)) +
   geom_boxplot(fatten = 2) +    
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of distributive justice:\nindividual',
                      breaks = c(1, 2, 3, 4, 5, 6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Approach') +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/gradfair_approaches_box.png", p, width = 120, height = 90, unit = "mm")



### 3.3. Pilot project ----
pilotfair_data <- fair_data_quant %>%
   select(id, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern) %>%
   gather(approach, fairness, pilotfairnoex:pilotfairintern)

pilotfair_data$approach <- factor(pilotfair_data$approach,
                                  levels = unique(pilotfair_data$approach),
                                  labels = c("pilotfairnoex", "pilotfairchan", "pilotfairexpl", "pilotfairintern")) #define order from unfairest to fairest

pilotfair_data$approach <- factor(pilotfair_data$approach, labels = c("Gut feeling", "Chance", "Criteria", "Voluntary"))

#Barchart.
p <- pilotfair_data %>%
   ggplot(aes(x = fairness, fill = approach, binwidth = 2))+ 
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   labs(x = "Fairness") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 225), expand = c(0, 0), breaks = seq(0, 225, by = 25)) +
   scale_x_continuous(name = 'Evaluation of procedural justice',
                      limits = c(0.5, 6.5),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all fair", "2", "3", "4", "5", "6\nTotally fair")) +
   scale_fill_manual(values=f_colors_sz) +
   guides(fill = guide_legend(nrow=2,byrow=TRUE, title = "Approach")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/pilotfair_approaches.png", p, width = 140, height = 90, unit = "mm")

#Boxplot.
p <- pilotfair_data %>%
   ggplot(aes(x = approach, y = fairness)) +
   geom_boxplot(fatten = 2) +    
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of distributive justice:\nindividual',
                      breaks = c(1, 2, 3, 4, 5, 6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Approach') +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/pilotfair_approaches_box.png", p, width = 140, height = 90, unit = "mm")

#' Stacked barchart showing the fractions of respondents who exhibited the predicted ranking (vs. indifference and opposite ranking) between approaches of procedural justice
fractions <- fair_data_quant %>%
   select(id, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern)

fractions <- fractions %>%
   mutate(a_NoexChan = ifelse(pilotfairnoex < pilotfairchan, 3, 0))%>%
   mutate(a_NoexChan = ifelse(pilotfairnoex == pilotfairchan, 2, a_NoexChan)) %>%
   mutate(a_NoexChan = ifelse(pilotfairnoex > pilotfairchan, 1, a_NoexChan)) %>%
   mutate(b_ChanExpl = ifelse(pilotfairchan < pilotfairexpl, 3, 0))%>%
   mutate(b_ChanExpl = ifelse(pilotfairchan == pilotfairexpl, 2, b_ChanExpl)) %>%
   mutate(b_ChanExpl = ifelse(pilotfairchan > pilotfairexpl, 1, b_ChanExpl)) %>%
   mutate(c_ExplIntern = ifelse(pilotfairexpl < pilotfairintern, 3, 0))%>%
   mutate(c_ExplIntern = ifelse(pilotfairexpl == pilotfairintern, 2, c_ExplIntern)) %>%
   mutate(c_ExplIntern = ifelse(pilotfairexpl > pilotfairintern, 1, c_ExplIntern))

fractions <- fractions %>%
   select(id, a_NoexChan, b_ChanExpl, c_ExplIntern) %>%
   gather(approach, comparison, a_NoexChan:c_ExplIntern)  

fractions <- fractions %>%
   group_by(approach) %>%
   count(comparison) %>%
   mutate(percent = prop.table(n)*100)

fractions$comparison <- factor(fractions$comparison, labels = c(">", "=", "<"))
fractions

p <- fractions %>%
   ggplot(aes(y = percent, x = approach, fill = comparison)) + 
   geom_bar(stat="identity", color = "#A9A9A9", width = 0.6)+
   scale_y_continuous(name = "Percent", limits=c(0, 102), expand = c(0, 0), breaks = seq(0, 100, by = 20)) +
   scale_x_discrete(name = NULL,
                      labels = c("Gut feeling\nvs.\nChance", "Chance\nvs.\nCriteria", "Criteria\nvs.\nVoluntary")) +
   guides(fill = guide_legend(title = NULL)) +
   scale_fill_manual(values=f_colors_sz) +
   f_layout_demo() 
p   
ggsave("output/graphs_for_paper/bar_pilot_fractions.png", p, width = 100, height = 70, unit = "mm")



### 3.4. Test phase ----
testfair_data <- fair_data_quant %>%
   select(id, testfairEq, testfairEt) %>%
   gather(approach, fairness, testfairEq:testfairEt)

testfair_data$approach <- factor(testfair_data$approach, labels = c("Equality", "Equity"))

#Barchart.
p <- testfair_data %>%
   ggplot(aes(x = fairness, fill = approach, binwidth = 2))+ 
   geom_bar(position = position_dodge(), size = 0.5, color = 'black') +
   labs(x = "Fairness") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 225), expand = c(0, 0), breaks = seq(0, 225, by = 25)) +
   scale_x_continuous(name = 'Evaluation of distributive justice:\ncollective',
                      limits = c(0.5, 6.5),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all fair", "2", "3", "4", "5", "6\nTotally fair")) +
   scale_fill_manual(values=f_colors_sz) +
   guides(fill = guide_legend(nrow=2,byrow=TRUE, title = "Approach")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/testfair_approaches.png", p, width = 100, height = 90, unit = "mm")

#Boxplot.
p <- testfair_data %>%
   ggplot(aes(x = approach, y = fairness)) +
   geom_boxplot(fatten = 2) +
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of distributive justice:\ncollective',
                      breaks = c(1, 2, 3, 4, 5, 6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Approach') +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/testfair_approaches_box.png", p, width = 120, height = 90, unit = "mm")


#### 5. Allocation key ----

#' Distribution of chosen allocation keys
p <- fair_data_quant %>%
   ggplot(aes(x = testalloc))+ 
   single_col_bar +
   labs(x = "Allocation chosen as the fairest") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 125), expand = c(0, 0), breaks = seq(0, 225, by = 25)) +
   scale_x_continuous(limits = c(0.5,22), breaks = c(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21),
                      labels = c("\n1\nW: 100%, A: 0%", 
                                 "2", 
                                 "3",
                                 "4", 
                                 "5",
                                 "6",
                                 "7", 
                                 "8", 
                                 "9", 
                                 "10",
                                 "\n11\n W: 50%, A: 50%", 
                                 "12",
                                 "13", 
                                 "14", 
                                 "15", 
                                 "16", 
                                 "17", 
                                 "18", 
                                 "19", 
                                 "20",
                                 "\n21\nW: 0%, A: 100%")) +
   geom_density(aes(y=..count..), colour="#9712FA", adjust=4) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/allocation_keys.png", p, width = 160, height = 90, unit = "mm")



#### 6. Correlation: outcome - process ----
p <- fair_data_quant %>%
   ggplot(aes(x=gradfairEt, y=pilotfairchan)) + 
   geom_point() +
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   geom_smooth(method = lm, color = "black") +
   scale_y_continuous(name = "Evaluation of Chance\n(procedural)", 
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Evaluation of Equity\n(distributive; individual)",
                      limits=c(0.5, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all fair","2","3","4","5","6\nTotally fair")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/corr_equity-chance.png", p, width = 130, height = 90, unit = "mm")


p <- ggplot(fair_data_quant, aes(x=gradfairEt, y=pilotfairexpl)) + 
   geom_point() +
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   geom_smooth(method = lm, color = "black") +
   scale_y_continuous(name = "Evaluation of Criteria\n(procedural)", 
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
scale_x_continuous(name = "Evaluation of Equity\n(distributive; individual)",
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all fair","2","3","4","5","6\nTotally fair")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/corr_equity-criteria.png", p, width = 130, height = 90, unit = "mm")


p <- ggplot(fair_data_quant, aes(x=gradfairNe, y=pilotfairnoex)) + 
   geom_point() +
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   geom_smooth(method = lm, color = "black") +
   scale_y_continuous(name = "Evaluation of Gut feeling\n(procedural)", 
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Evaluation of Need\n(distributive; individual)",
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all fair","2","3","4","5","6\nTotally fair")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/corr_need-gutfeeling.png", p, width = 130, height = 90, unit = "mm")

p <- ggplot(fair_data_quant, aes(x=gradfairNe, y=pilotfairexpl)) + 
   geom_point() +
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   geom_smooth(method = lm, color = "black") +
   scale_y_continuous(name = "Evaluation of Criteria\n(procedural)", 
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Evaluation of Need\n(distributive; individual)",
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all fair","2","3","4","5","6\nTotally fair")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/corr_need-criteria.png", p, width = 130, height = 90, unit = "mm")


#### 7. Boxplots Eq-Et individual vs. collective ----
#' Boxplots for Equality and Equity at the individual and the collective level.
H4.1_long <- f13_buildEEDataFrame1(fair_data_quant)
H4.1_long <- H4.1_long %>%
   mutate(new_group = ifelse(Question == "Equality" & Vignette == "grad", "Eq.ind", "placeholder")) %>%
   mutate(new_group = ifelse(Question == "Equality" & Vignette == "test", "Eq.coll", new_group)) %>%
   mutate(new_group = ifelse(Question == "Equity" & Vignette == "grad", "Et.ind", new_group)) %>%
   mutate(new_group = ifelse(Question == "Equity" & Vignette == "test", "Et.coll", new_group)) 
   
#Boxplot.
p <- H4.1_long %>%
   ggplot(aes(x = new_group, y = Score)) +
   geom_boxplot(fatten = 2) + 
   geom_jitter(width = 0.3, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of distributive justice',
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6), 
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Distributive Justice', 
                    labels = c("Equality \n individual", "Equality \n collective", "Equity \n individual", "Equity \n collective")) +
   f_layout_demo() +
   theme(strip.background = element_blank(),
         strip.text.x = element_blank())
p
ggsave("output/graphs_for_paper/box_ind_coll.png", p, width = 120, height = 90, unit = "mm")


#' Boxplot for the difference between Equality and Equity at the individual and the collective level.
H4.1_long_diff <- f14_buildEEDataFrame2(fair_data_quant)

#Boxplot.
p <- H4.1_long_diff %>%
   ggplot(aes(x = Vignette, y = Diff)) +
   geom_boxplot(fatten = 2) + 
   geom_jitter(width = 0.3, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Difference between Equality and Equity',
                      limits=c(-6, 6), expand = c(0, 0),
                      breaks = c(-5,-4,-3,-2,-1,0,1,2,3,4,5)) +
   scale_x_discrete(name = 'Distributive Justice\n(Whole sample, N = 472)', 
                    labels = c("Individual level", "Collective level")) +
   f_layout_demo() +
   theme(strip.background = element_blank(),
      strip.text.x = element_blank())
p
ggsave("output/graphs_for_paper/Eq-Et_ind_coll.png", p, width = 80, height = 90, unit = "mm")

#' only including quizright = 2.
H4.1_long_diff_q2 <- fair_data_quant %>%
   filter(quizright == 2)

H4.1_long_diff_q2 <- f14_buildEEDataFrame2(H4.1_long_diff_q2)

p <- H4.1_long_diff %>%
   ggplot(aes(x = Vignette, y = Diff)) +
   geom_boxplot(fatten = 2) + 
   geom_jitter(width = 0.3, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Difference between Equality and Equity',
                      limits=c(-6, 6), expand = c(0, 0),
                      breaks = c(-5,-4,-3,-2,-1,0,1,2,3,4,5)) +
   scale_x_discrete(name = 'Distributive Justice\n(Subsample, N = 284)', 
                    labels = c("Individual level", "Collective level")) +
   f_layout_demo() +
   theme(strip.background = element_blank(),
         strip.text.x = element_blank())
p
ggsave("output/graphs_for_paper/Eq-Et_ind_coll_q2.png", p, width = 80, height = 90, unit = "mm")


#' Boxplots for Equality at the individual and the collective level depending on previous knowledge about wastewater treatment.
Eq_knowledge <- fair_data_quant %>%
   select(id, gradfairEq, testfairEq, knowledge1) %>%
   gather(approach, fairness, gradfairEq:testfairEq)

Eq_knowledge <- Eq_knowledge %>%
   mutate(new_group = ifelse(approach == "gradfairEq" & knowledge1 == 1, "Ind.yes", "placeholder")) %>%
   mutate(new_group = ifelse(approach == "gradfairEq" & knowledge1 == 0, "Ind.no", new_group)) %>%
   mutate(new_group = ifelse(approach == "testfairEq" & knowledge1 == 1, "Coll.yes", new_group)) %>%
   mutate(new_group = ifelse(approach == "testfairEq" & knowledge1 == 0, "Coll.no", new_group)) 

#Boxplot.
p <- Eq_knowledge %>%
   ggplot(aes(x = new_group, y = fairness)) +
   geom_boxplot(fatten = 2) + 
   geom_jitter(width = 0.3, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of Equality',
                      limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6), 
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Distributive Justice', 
                    labels = c("individual \n prev.KNWL", "individual \n no prev.KNWL", "collective \n prev.KNWL", "collective \n no prev.KNWL")) +
   f_layout_demo() +
   theme(strip.background = element_blank(),
         strip.text.x = element_blank())
p
ggsave("output/graphs_for_paper/box_Eq_knowledge.png", p, width = 140, height = 90, unit = "mm")


#### 8. Grahps for demographics as predictor for gradfair Eq, Et & Ne ----
gradfair_RQ1.4_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, gradfairEq, gradfairEt, gradfairNe) %>%
   gather(approach, fairness, gradfairEq:gradfairNe)

gradfair_RQ1.4_data$approach <- factor(gradfair_RQ1.4_data$approach, labels = c("Equality", "Equity", "Need")) #Just for design reasons, so the charts are labeled nicely.

#' Gender.
p <- gradfair_RQ1.4_data %>%
   ggplot(aes(x = sex, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) +    
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Gender") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/grad_gender.png", p, width = 160, height = 90, unit = "mm")


#' Age.
p <- gradfair_RQ1.4_data %>%
   ggplot(aes(x = age, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Age") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/grad_age.png", p, width = 160, height = 90, unit = "mm")


#' Size of place of residence
p <- gradfair_RQ1.4_data %>%
   ggplot(aes(x = city, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(labs(x = "Size of place of residence"), 
                    labels = c("Less than\n2.000","Up to\n5.000","Up to\n20.000","Up to\n50.000","Up to\n100.000","100.000\nor more", "I don't\nknow")) +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/grad_city.png", p, width = 180, height = 90, unit = "mm")


#' Education.
gradfair_RQ1.4_data$education <- factor(gradfair_RQ1.4_data$education, labels = c("SecS","BVoc","HigS","HVoc","UniD"))

p <- gradfair_RQ1.4_data %>%
   ggplot(aes(x = education, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Highest education") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/grad_education.png", p, width = 160, height = 90, unit = "mm")


#' Politic (left, center, right)
p <- gradfair_RQ1.4_data %>%
   ggplot(aes(x = politic_lcr, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Political orientation") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/grad_politic_lcr.png", p, width = 160, height = 90, unit = "mm")


#' Finance
p <- gradfair_RQ1.4_data %>%
   ggplot(aes(x=finance, y=fairness, fill = approach, color = approach, shape = approach)) + 
   geom_smooth(aes(group = approach), method = lm, size = 0.3, color = 'black') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Financial worries", limits=c(0,7), expand = c(0, 0),
                      breaks = c(0,1,2,3,4,5,6),
                      labels = c("0\nI don't have any\nfinancial worries","1","2","3","4","5", "6\nVery big\nfinancial worries")) +
   scale_fill_manual(values = c("#FFDE21", "#FF656C", "#9712FA"), name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/grad_finance_cor.png", p, width = 160, height = 90, unit = "mm")


#' Reward
p <- gradfair_RQ1.4_data %>%
   ggplot(aes(x=reward, y=fairness, fill = approach, color = approach, shape = approach)) + 
   geom_smooth(aes(group = approach), method = lm, size = 0.3, color = 'black') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Importance of reward", limits=c(1,7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all important","2","3","4","5","6\nTotally important")) +
   scale_fill_manual(values = c("#FFDE21", "#FF656C", "#9712FA"), name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/grad_reward_cor.png", p, width = 160, height = 90, unit = "mm")


#' knowledge
gradfair_RQ1.4_data$knowledge1 <- factor(gradfair_RQ1.4_data$knowledge1, labels = c("No previous knowledge", "Previous knowledge")) #Just for design reasons, so the charts are labeled nicely.

p <- gradfair_RQ1.4_data %>%
   ggplot(aes(x = knowledge1, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Previous knowledge of wastewater treatment") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(values = c("#FFAE51", "#FF656C", "#9712FA"), name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/grad_engagement.png", p, width = 160, height = 90, unit = "mm")


#### 9. Grahps for demographics as predictor for testfair Eq & Et----
testfair_RQ3.1_data <- fair_data_quant %>%
   select(id, quizright, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, testfairEq, testfairEt) %>%
   gather(approach, fairness, testfairEq:testfairEt)

testfair_RQ3.1_data$approach <- factor(testfair_RQ3.1_data$approach, labels = c("Equality", "Equity")) #Just for design reasons, so the charts are labeled nicely.

#' Size of place of residence
p <- testfair_RQ3.1_data %>%
   ggplot(aes(x = city, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of distributive justice:\ncollective", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(labs(x = "Size of place of residence"), 
                    labels = c("Less than\n2.000","Up to\n5.000","Up to\n20.000","Up to\n50.000","Up to\n100.000","100.000\nor more", "I don't\nknow")) +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/test_city.png", p, width = 180, height = 90, unit = "mm")

#' Reward
p <- testfair_RQ3.1_data %>%
   ggplot(aes(x=reward, y=fairness, fill = approach, color = approach, shape = approach)) + 
   geom_smooth(aes(group = approach), method = lm, size = 0.3, color = 'black') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Importance of reward", limits=c(1,7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all important","2","3","4","5","6\nTotally important")) +
   scale_fill_manual(values = c("#FFDE21", "#FF656C", "#9712FA"), name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/test_reward_cor.png", p, width = 160, height = 90, unit = "mm")

#' only including quizright = 2.
testfair_RQ3.1_data_q2 <- testfair_RQ3.1_data %>%
   filter(quizright == 2)

p <- testfair_RQ3.1_data_q2 %>%
   ggplot(aes(x=reward, y=fairness, fill = approach, color = approach, shape = approach)) + 
   geom_smooth(aes(group = approach), method = lm, size = 0.3, color = 'black') +
   scale_y_continuous(name = "Evaluation of distributive justice:\nindividual", limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Importance of reward", limits=c(1,7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all important","2","3","4","5","6\nTotally important")) +
   scale_fill_manual(values = c("#FFDE21", "#FF656C", "#9712FA"), name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/test_reward_cor_q2.png", p, width = 160, height = 90, unit = "mm")



#### 10. Grahps for demographics as predictor for pilotfair ----
pilotfair_RQ2.1_data <- fair_data_quant %>%
   select(id, sex, age, education, city, reward, religion, engagement, finance, politic_lcr, knowledge1, knowledge_points, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern) %>%
   gather(approach, fairness, pilotfairnoex:pilotfairintern)

pilotfair_RQ2.1_data$approach <- factor(pilotfair_RQ2.1_data$approach,
                                  levels = unique(pilotfair_RQ2.1_data$approach),
                                  labels = c("pilotfairnoex", "pilotfairchan", "pilotfairexpl", "pilotfairintern")) #define order from unfairest to fairest

pilotfair_RQ2.1_data$approach <- factor(pilotfair_RQ2.1_data$approach, labels = c("Gut feeling", "Chance", "Criteria", "Voluntary")) #Just for design reasons, so the charts are labeled nicely.


#' Gender.
p <- pilotfair_RQ2.1_data %>%
   ggplot(aes(x = sex, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of procedural justice", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Gender") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(values = c("#FFAE51", "#FF656C", "#9712FA", "#000000"), name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/pilot_gender.png", p, width = 160, height = 90, unit = "mm")

#' Age.
p <- pilotfair_RQ2.1_data %>%
   ggplot(aes(x = age, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of procedural justice", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Age") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/pilot_age.png", p, width = 160, height = 90, unit = "mm")

#' Education.
pilotfair_RQ2.1_data$education <- factor(pilotfair_RQ2.1_data$education, labels = c("SecS","BVoc","HigS","HVoc","UniD"))

p <- pilotfair_RQ2.1_data %>%
   ggplot(aes(x = education, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of procedural justice", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Highest education") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(values = c("#FFAE51", "#FF656C", "#9712FA", "#000000"), name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/pilot_education.png", p, width = 160, height = 90, unit = "mm")

#Barchart for the means of Gut feeling and Chance, depending on education.
noex_chan_bar <- fair_data_quant %>%
   select(id, education, pilotfairnoex, pilotfairchan) %>%
   gather(approach, fairness, pilotfairnoex:pilotfairchan)

noex_chan_bar_mean <- noex_chan_bar %>%
   group_by(education) %>%
   summarise(Noex_Mean = mean(fairness[approach == "pilotfairnoex"]),
             Chan_Mean = mean(fairness[approach == "pilotfairchan"]))

noex_chan_bar_mean <- noex_chan_bar_mean %>%
   select(education, Noex_Mean, Chan_Mean) %>%
   gather(approach, Mean, Noex_Mean:Chan_Mean)

noex_chan_bar_mean$approach <- factor(noex_chan_bar_mean$approach,
                                 levels = unique(noex_chan_bar_mean$approach),
                                 labels = c("Noex_Mean", "Chan_Mean")) #define order from unfairest to fairest

noex_chan_bar_mean$approach <- factor(noex_chan_bar_mean$approach, labels = c("Gut feeling", "Chance"))

p <- noex_chan_bar_mean %>%
   ggplot(aes(x = approach, y = Mean, fill = education, binwidth = 2))+ 
   geom_bar(stat = "identity", position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   labs(x = "Approach") +
   scale_y_continuous(name = 'Average evaluation of procedural justice',
                      limits = c(0, 4),
                      breaks = c(0.5,1,1.5,2,2.5,3,3.5,4), expand = c(0, 0)) +
   scale_fill_manual(values=f_colors_sz) +
   guides(fill = guide_legend(nrow=5, title = "Education")) +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/bar_noex_chan_mean.png", p, width = 150, height = 90, unit = "mm")

#' Religiousness
p <- pilotfair_RQ2.1_data %>%
   ggplot(aes(x=religion, y=fairness, fill = approach, color = approach, shape = approach)) + 
   geom_smooth(aes(group = approach), method = lm, size = 0.3, color = 'black') +
   scale_y_continuous(name = "Evaluation of procedural justice", limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Religiousness", limits=c(0,6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("1\nNot at all religious","2","3","4","5","6\nTotally religious")) +
   scale_fill_manual(values = c("#FFAE51", "#FF656C", "#9712FA", "#000000"), name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/pilot_religion.png", p, width = 160, height = 90, unit = "mm")


#' knowledge
pilotfair_RQ2.1_data$knowledge1 <- factor(pilotfair_RQ2.1_data$knowledge1, labels = c("No previous knowledge", "Previous knowledge")) #Just for design reasons, so the charts are labeled nicely.

p <- pilotfair_RQ2.1_data %>%
   ggplot(aes(x = knowledge1, y = fairness, fill = approach, color = approach)) +
   geom_boxplot(position = position_dodge(1), size = 0.3, color = 'black', fatten = 2) + 
   geom_jitter(aes(group = approach), position = position_jitterdodge(1, jitter.width = 0.5, jitter.height = 0.5), size = 0.5, color = '#898989') +
   scale_y_continuous(name = "Evaluation of procedural justice", limits=c(0, 7), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = "Previous knowledge of wastewater treatment") +
   scale_fill_manual(values = f_colors_sz, name = "Approach") +
   scale_color_manual(values = c("#FFAE51", "#FF656C", "#9712FA", "#000000"), name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/pilot_engagement.png", p, width = 160, height = 90, unit = "mm")

#' points in knowledge quiz.
p <- pilotfair_RQ2.1_data %>%
   ggplot(aes(x=knowledge_points, y=fairness, fill = approach, color = approach, shape = approach)) + 
   geom_smooth(aes(group = approach), method = lm, size = 0.3, color = 'black') +
   scale_y_continuous(name = "Evaluation of procedural justice", limits=c(0, 6.5), expand = c(0, 0),
                      breaks = c(1,2,3,4,5,6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_continuous(name = "Number of points in\nwastewater knowledge quiz ", limits=c(0,8), expand = c(0, 0),
                      breaks = c(0,1,2,3,4,5,6,7,8),
                      labels = c("0","1","2","3","4","5","6","7","8")) +
   scale_fill_manual(values = c("#FFAE51", "#FF656C", "#9712FA", "#000000"), name = "Approach") +
   scale_color_manual(name = "Approach") +
   f_layout_demo()
p
ggsave("output/graphs_for_paper/pilot_knowledgepoints_cor.png", p, width = 160, height = 90, unit = "mm")


