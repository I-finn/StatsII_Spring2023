#' *****************************************************************
#' > Project:     Fairness - Main Sample \
#' > File:        5_compare_quizright0-2.R \
#' > Created:     06.08.19 \
#' > Authors:     Sara Zürcher, sara.zuercher@eawag.ch \
#' > Description: Compare groups of participants with no, one or two
#' >                 correctly answered quiz questions
#' > Last change: 06.08.19 by Sara \



#### 1. Set Up ----

### 1.1. Update dates ----

#' Update the dates (yymmdd) in this file (5_compare_quizright0-2.R).

### 1.2. Import data ----

#' Run the script "datacleaning" to get the datafile needed for the following analyses.
source("scripts/1.1_fairness_cleaning.R")

### 1.3. Functions ----
f_colors_sz <- c('#FFFFC4','#FFDE21','#FFAE52','#FF656C','#FF2DA5','#9712FA','#000000')

f_quizright21 <- function (data, var_nm, sht_nm) {
   d <- data 
   
   d <- split(d, d$quizright)
   
   M1 <- mean(unlist(d[["1"]][["fairness"]]))
   SD1 <- sd(unlist(d[["1"]][["fairness"]]))
   N1 <- length(d[["1"]][["fairness"]])
   M2 <- mean(unlist(d[["2"]][["fairness"]]))
   SD2 <- sd(unlist(d[["2"]][["fairness"]]))
   N2 <- length(d[["2"]][["fairness"]])
   
   #' Wilcoxon. Test people with one correct quiz question against people with two correct quiz questions.
   wilcox <- wilcox.test(d$"1"$fairness, d$"2"$fairness)
   wilcox_p <- wilcox[["p.value"]]
   wilcox_W <- wilcox[["statistic"]][["W"]]
   
   M_SD <- do.call(rbind, Map(data.frame, 
                              M1 = M1, SD1 = SD1,N1 = N1, M2 = M2, SD2 = SD2, N2 = N2, wilcox_W = wilcox_W, wilcox_p = wilcox_p))
   
   write.xlsx(M_SD, file = "output/compare_quizright0-2/190806_compare_quizright0-2.xlsx", 
              sheetName = sht_nm, col.names = TRUE, row.names = TRUE, append = TRUE)
}

f_quizright20 <- function (data, var_nm, sht_nm) {
   d <- data 
   
   d <- split(d, d$quizright)
   
   M1 <- mean(unlist(d[["0"]][["fairness"]]))
   SD1 <- sd(unlist(d[["0"]][["fairness"]]))
   N1 <- length(d[["0"]][["fairness"]])
   M2 <- mean(unlist(d[["2"]][["fairness"]]))
   SD2 <- sd(unlist(d[["2"]][["fairness"]]))
   N2 <- length(d[["2"]][["fairness"]])
   
   #' Wilcoxon. Test people with no correct quiz question against people with two correct quiz questions.
   wilcox <- wilcox.test(d$"0"$fairness, d$"2"$fairness)
   wilcox_p <- wilcox[["p.value"]]
   wilcox_W <- wilcox[["statistic"]][["W"]]
   
   M_SD <- do.call(rbind, Map(data.frame, 
                              M1 = M1, SD1 = SD1,N1 = N1, M2 = M2, SD2 = SD2, N2 = N2, wilcox_W = wilcox_W, wilcox_p = wilcox_p))
   
   write.xlsx(M_SD, file = "output/compare_quizright0-2/190806_compare_quizright0-2.xlsx", 
              sheetName = sht_nm, col.names = TRUE, row.names = TRUE, append = TRUE)
}

f_layout_demo <- function() {
   theme_bw() +
      theme(axis.line = element_line(colour = "black"),
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            panel.border = element_blank(),
            panel.background = element_blank(),
            axis.text.x = element_text(size = 11, colour = "black"),
            axis.title.x = element_text(size = 13, colour = "black"),
            axis.title.y = element_text(size = 13, colour = "black"),
            axis.text.y = element_text(size = 11, colour = "black"),
            plot.title = element_text(size = 17, colour = "black"),
            legend.title = element_text(size = 13, colour = "black"),
            legend.text = element_text(size = 11, colour = "black"),
            legend.key.size = unit(0.75, 'lines'), 
            legend.position = "bottom",
            strip.text.x = element_text(size=17),
            strip.background = element_blank()) 
}

f10_rmANOVA <- function (dataset) {
   m2 <- ezANOVA(data = dataset, dv= .(fairness), wid = .(id), within = .(approach), detailed = TRUE)
   m2
}
#Repeated measures ANOVA.

f12_barcharts_vign <- function (data, titletext) {
   data %>%
      ggplot(aes(x = fairness))+ 
      facet_wrap(~ approach, scales='free_x', nrow = 1) + 
      geom_bar() +
      labs(x = "Fairness of the approach", y = "Count", title = titletext) 
}
#Creates barcharts of the different approaches per vignette.

f13_del_incons_cases_q2 <- function() {
   testfair_data_wide_no_incons_q2 <- fair_data_quant_q2 %>%
      filter(testfairEq != 6 | testfairEt != 6) %>%
      filter(testfairEq == 6 & testalloc == 11 | testfairEq != 6) %>%
      filter(testfairEt == 6 & testalloc == 1 | testfairEt != 6)
}
#Deletes inconsistent cases from the dataset. 597 and 1023 are filtered in both Eq and testalloc inconsistent as well as in Et and testalloc inconsistent. Therefore instead of 47 cases (33 from Et and 14 from Eq), only 45 are deleted

#Function for a posthoc pairwise.t.test, but it also prints t-values and dfs.
f21_pairwise.t.test.with.t.and.df <- function (x, g, p.adjust.method = p.adjust.methods, pool.sd = !paired, 
                                               paired = FALSE, alternative = c("two.sided", "less", "greater"), 
                                               ...) 
{
   if (paired & pool.sd) 
      stop("pooling of SD is incompatible with paired tests")
   DNAME <- paste(deparse(substitute(x)), "and", deparse(substitute(g)))
   g <- factor(g)
   p.adjust.method <- match.arg(p.adjust.method)
   alternative <- match.arg(alternative)
   if (pool.sd) {
      METHOD <- "t tests with pooled SD"
      xbar <- tapply(x, g, mean, na.rm = TRUE)
      s <- tapply(x, g, sd, na.rm = TRUE)
      n <- tapply(!is.na(x), g, sum)
      degf <- n - 1
      total.degf <- sum(degf)
      pooled.sd <- sqrt(sum(s^2 * degf)/total.degf)
      compare.levels <- function(i, j) {
         dif <- xbar[i] - xbar[j]
         se.dif <- pooled.sd * sqrt(1/n[i] + 1/n[j])
         t.val <- dif/se.dif
         if (alternative == "two.sided") 
            2 * pt(-abs(t.val), total.degf)
         else pt(t.val, total.degf, lower.tail = (alternative == 
                                                     "less"))
      }
      compare.levels.t <- function(i, j) {
         dif <- xbar[i] - xbar[j]
         se.dif <- pooled.sd * sqrt(1/n[i] + 1/n[j])
         t.val = dif/se.dif 
         t.val
      }       
   }
   else {
      METHOD <- if (paired) 
         "paired t tests"
      else "t tests with non-pooled SD"
      compare.levels <- function(i, j) {
         xi <- x[as.integer(g) == i]
         xj <- x[as.integer(g) == j]
         t.test(xi, xj, paired = paired, alternative = alternative, 
                ...)$p.value
      }
      compare.levels.t <- function(i, j) {
         xi <- x[as.integer(g) == i]
         xj <- x[as.integer(g) == j]
         t.test(xi, xj, paired = paired, alternative = alternative, 
                ...)$statistic
      }
      compare.levels.df <- function(i, j) {
         xi <- x[as.integer(g) == i]
         xj <- x[as.integer(g) == j]
         t.test(xi, xj, paired = paired, alternative = alternative, 
                ...)$parameter
      }
   }
   PVAL <- pairwise.table(compare.levels, levels(g), p.adjust.method)
   TVAL <- pairwise.table.t(compare.levels.t, levels(g), p.adjust.method)
   if (pool.sd) 
      DF <- total.degf
   else
      DF <- pairwise.table.t(compare.levels.df, levels(g), p.adjust.method)           
   ans <- list(method = METHOD, data.name = DNAME, p.value = PVAL, 
               p.adjust.method = p.adjust.method, t.value = TVAL, dfs = DF)
   class(ans) <- "pairwise.htest"
   ans
}
pairwise.table.t <- function (compare.levels.t, level.names, p.adjust.method) 
{
   ix <- setNames(seq_along(level.names), level.names)
   pp <- outer(ix[-1L], ix[-length(ix)], function(ivec, jvec) sapply(seq_along(ivec), 
                                                                     function(k) {
                                                                        i <- ivec[k]
                                                                        j <- jvec[k]
                                                                        if (i > j)
                                                                           compare.levels.t(i, j)               
                                                                        else NA
                                                                     }))
   pp[lower.tri(pp, TRUE)] <- pp[lower.tri(pp, TRUE)]
   pp
}

#Calculates the effectsize. Author: Andy Field
f23_rFromWilcox <- function(wilcoxModel, N) {
   z <- stats::qnorm(wilcoxModel$p.value / 2)
   r <- z / sqrt(N)
   cat(wilcoxModel$data.name, "Effect Size, r = ", r)
}

min.mean.sd.max <- function(x) {
   r <- c(min(x), mean(x) - sd(x), mean(x), mean(x) + sd(x), max(x))
   names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
   r
}


### 1.4. Libraries ----
library("RColorBrewer")
library("broom")
library("Hmisc")
library("ez")
library("nlme")



#### 2. Compare groups in answers to vignettes and concerning characteristics ----

### 2.1. Compare groups concerning current situation ----
quizright_cursit1 <- fair_data_quant %>%
   select(quizright, cursit1)

quizright_cursit1$cursit1 <- factor(quizright_cursit1$cursit1, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_cursit1 %>%
   ggplot(aes(x = quizright, group = cursit1, fill = cursit1), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Current situation")) +
   f_layout_demo() 
p
ggsave("bar_quizright_cursit1.png", p, width = 120, height = 80, unit = "mm")


## 2.1.1. quizright1 vs. quizright2 ----
quizright21_cursit1 <- fair_data_quant %>%
   select(quizright, cursit1) %>%
   filter(quizright != 0) %>%
   rename(fairness = cursit1)

f_quizright21(quizright21_cursit1, sht_nm = "cursit21")


## 2.1.2. quizright0 vs. quizright2 ----
quizright20_cursit1 <- fair_data_quant %>%
   select(quizright, cursit1) %>%
   filter(quizright != 1) %>%
   rename(fairness = cursit1)

f_quizright20(quizright20_cursit1, sht_nm = "cursit20")


### 2.2. Compare groups concerning gradfair ----
quizright_gradfair <- fair_data_quant %>%
   select(quizright, gradfairEq, gradfairEt, gradfairNe) %>%
   select(-gradfairEt, - gradfairNe)

quizright_gradfair$gradfairEq <- factor(quizright_gradfair$gradfairEq, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_gradfair %>%
   ggplot(aes(x = quizright, group = gradfairEq, fill = gradfairEq), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Equality")) +
   f_layout_demo() 
p
ggsave("bar_quizright_gradfairEq.png", p, width = 120, height = 80, unit = "mm")


quizright_gradfair <- fair_data_quant %>%
   select(quizright, gradfairEq, gradfairEt, gradfairNe) %>%
   select(-gradfairEq, - gradfairNe)

quizright_gradfair$gradfairEt <- factor(quizright_gradfair$gradfairEt, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_gradfair %>%
   ggplot(aes(x = quizright, group = gradfairEt, fill = gradfairEt), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Equity")) +
   f_layout_demo() 
p
ggsave("bar_quizright_gradfairEt.png", p, width = 120, height = 80, unit = "mm")

quizright_gradfair <- fair_data_quant %>%
   select(quizright, gradfairEq, gradfairEt, gradfairNe) %>%
   select(-gradfairEq, - gradfairEt)

quizright_gradfair$gradfairNe <- factor(quizright_gradfair$gradfairNe, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_gradfair %>%
   ggplot(aes(x = quizright, group = gradfairNe, fill = gradfairNe), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Need")) +
   f_layout_demo() 
p
ggsave("bar_quizright_gradfairNe.png", p, width = 120, height = 80, unit = "mm")


## 2.2.1. Equality: quizright1 vs. quizright2 ----
quizright21_gradfairEq <- fair_data_quant %>%
   select(quizright, gradfairEq) %>%
   filter(quizright != 0) %>%
   rename(fairness = gradfairEq)

f_quizright21(quizright21_gradfairEq, sht_nm = "gradfairEq21")


## 2.2.2. Equality: quizright0 vs. quizright2 ----
quizright20_gradfairEq <- fair_data_quant %>%
   select(quizright, gradfairEq) %>%
   filter(quizright != 1) %>%
   rename(fairness = gradfairEq)

f_quizright20(quizright20_gradfairEq, sht_nm = "gradfairEq20")


## 2.2.3. Equity: quizright1 vs. quizright2 ----
quizright21_gradfairEt <- fair_data_quant %>%
   select(quizright, gradfairEt) %>%
   filter(quizright != 0) %>%
   rename(fairness = gradfairEt)

f_quizright21(quizright21_gradfairEt, sht_nm = "gradfairEt21")


## 2.2.4. Equity: quizright0 vs. quizright2 ----
quizright20_gradfairEt <- fair_data_quant %>%
   select(quizright, gradfairEt) %>%
   filter(quizright != 1) %>%
   rename(fairness = gradfairEt)

f_quizright20(quizright20_gradfairEt, sht_nm = "gradfairEt20")

## 2.2.5. Need: quizright1 vs. quizright2 ----
quizright21_gradfairNe <- fair_data_quant %>%
   select(quizright, gradfairNe) %>%
   filter(quizright != 0) %>%
   rename(fairness = gradfairNe)

f_quizright21(quizright21_gradfairNe, sht_nm = "gradfairNe21")


## 2.2.6. Need: quizright0 vs. quizright2 ----
quizright20_gradfairNe <- fair_data_quant %>%
   select(quizright, gradfairNe) %>%
   filter(quizright != 1) %>%
   rename(fairness = gradfairNe)

f_quizright20(quizright20_gradfairNe, sht_nm = "gradfairNe20")


### 2.3. Compare groups concerning testfair ----
quizright_testfair <- fair_data_quant %>%
   select(quizright, testfairEq, testfairEt) %>%
   select(-testfairEt)

quizright_testfair$testfairEq <- factor(quizright_testfair$testfairEq, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_testfair %>%
   ggplot(aes(x = quizright, group = testfairEq, fill = testfairEq), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Equality")) +
   f_layout_demo() 
p
ggsave("bar_quizright_testfairEq.png", p, width = 120, height = 80, unit = "mm")


quizright_testfair <- fair_data_quant %>%
   select(quizright, testfairEq, testfairEt) %>%
   select(-testfairEq)

quizright_testfair$testfairEt <- factor(quizright_testfair$testfairEt, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_testfair %>%
   ggplot(aes(x = quizright, group = testfairEt, fill = testfairEt), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Equity")) +
   f_layout_demo() 
p
ggsave("bar_quizright_testfairEt.png", p, width = 120, height = 80, unit = "mm")

## 2.3.1. Equality: quizright1 vs. quizright2 ----
quizright21_testfairEq <- fair_data_quant %>%
   select(quizright, testfairEq) %>%
   filter(quizright != 0) %>%
   rename(fairness = testfairEq)

f_quizright21(quizright21_testfairEq, sht_nm = "testfairEq21")


## 2.3.2. Equality: quizright0 vs. quizright2 ----
quizright20_testfairEq <- fair_data_quant %>%
   select(quizright, testfairEq) %>%
   filter(quizright != 1) %>%
   rename(fairness = testfairEq)

f_quizright20(quizright20_testfairEq, sht_nm = "testfairEq20")

## 2.3.3. Equity: quizright1 vs. quizright2 ----
quizright21_testfairEt <- fair_data_quant %>%
   select(quizright, testfairEt) %>%
   filter(quizright != 0) %>%
   rename(fairness = testfairEt)

f_quizright21(quizright21_testfairEt, sht_nm = "testfairEt21")


## 2.3.4. Equity: quizright0 vs. quizright2 ----
quizright20_testfairEt <- fair_data_quant %>%
   select(quizright, testfairEt) %>%
   filter(quizright != 1) %>%
   rename(fairness = testfairEt)

f_quizright20(quizright20_testfairEt, sht_nm = "testfairEt20")



### 2.4. Compare groups concerning pilotfair ----
quizright_pilotfair <- fair_data_quant %>%
   select(quizright, pilotfairchan, pilotfairnoex, pilotfairexpl, pilotfairintern) %>%
   select(-pilotfairnoex, -pilotfairexpl, -pilotfairintern)

quizright_pilotfair$pilotfairchan <- factor(quizright_pilotfair$pilotfairchan, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_pilotfair %>%
   ggplot(aes(x = quizright, group = pilotfairchan, fill = pilotfairchan), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Chance")) +
   f_layout_demo() 
p
ggsave("bar_quizright_pilotfairChan.png", p, width = 120, height = 80, unit = "mm")


quizright_pilotfair <- fair_data_quant %>%
   select(quizright, pilotfairchan, pilotfairnoex, pilotfairexpl, pilotfairintern) %>%
   select(-pilotfairchan, -pilotfairexpl, -pilotfairintern)

quizright_pilotfair$pilotfairnoex <- factor(quizright_pilotfair$pilotfairnoex, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_pilotfair %>%
   ggplot(aes(x = quizright, group = pilotfairnoex, fill = pilotfairnoex), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Gut feeling")) +
   f_layout_demo() 
p
ggsave("bar_quizright_pilotfairNoex.png", p, width = 120, height = 80, unit = "mm")


quizright_pilotfair <- fair_data_quant %>%
   select(quizright, pilotfairchan, pilotfairnoex, pilotfairexpl, pilotfairintern) %>%
   select(-pilotfairchan, -pilotfairnoex, -pilotfairintern)

quizright_pilotfair$pilotfairexpl <- factor(quizright_pilotfair$pilotfairexpl, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_pilotfair %>%
   ggplot(aes(x = quizright, group = pilotfairexpl, fill = pilotfairexpl), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Criteria")) +
   f_layout_demo() 
p
ggsave("bar_quizright_pilotfairExpl.png", p, width = 120, height = 80, unit = "mm")


quizright_pilotfair <- fair_data_quant %>%
   select(quizright, pilotfairchan, pilotfairnoex, pilotfairexpl, pilotfairintern) %>%
   select(-pilotfairchan, -pilotfairnoex, -pilotfairexpl)

quizright_pilotfair$pilotfairintern <- factor(quizright_pilotfair$pilotfairintern, labels = c("Not at all fair", "Not fair", "Rather not fair", "Rather fair", "Fair", "Very fair"))

p <- quizright_pilotfair %>%
   ggplot(aes(x = quizright, group = pilotfairintern, fill = pilotfairintern), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 140), breaks = seq(0,140, by = 20)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Voluntary")) +
   f_layout_demo() 
p
ggsave("bar_quizright_pilotfairIntern.png", p, width = 120, height = 80, unit = "mm")


## 2.4.1. Gut feeling: quizright1 vs. quizright2 ----
quizright21_pilotfairnoex <- fair_data_quant %>%
   select(quizright, pilotfairnoex) %>%
   filter(quizright != 0) %>%
   rename(fairness = pilotfairnoex)

f_quizright21(quizright21_pilotfairnoex, sht_nm = "pilotfairnoex21")


## 2.4.2. Gut feeling: quizright0 vs. quizright2 ----
quizright20_pilotfairnoex <- fair_data_quant %>%
   select(quizright, pilotfairnoex) %>%
   filter(quizright != 1) %>%
   rename(fairness = pilotfairnoex)

f_quizright20(quizright20_pilotfairnoex, sht_nm = "pilotfairnoex20")


## 2.4.3. Chance: quizright1 vs. quizright2 ----
quizright21_pilotfairchan <- fair_data_quant %>%
   select(quizright, pilotfairchan) %>%
   filter(quizright != 0) %>%
   rename(fairness = pilotfairchan)

f_quizright21(quizright21_pilotfairchan, sht_nm = "pilotfairchan21")


## 2.4.4. Chance: quizright0 vs. quizright2 ----
quizright20_pilotfairchan <- fair_data_quant %>%
   select(quizright, pilotfairchan) %>%
   filter(quizright != 1) %>%
   rename(fairness = pilotfairchan)

f_quizright20(quizright20_pilotfairchan, sht_nm = "pilotfairchan20")


## 2.4.5. Criteria: quizright1 vs. quizright2 ----
quizright21_pilotfairexpl <- fair_data_quant %>%
   select(quizright, pilotfairexpl) %>%
   filter(quizright != 0) %>%
   rename(fairness = pilotfairexpl)

f_quizright21(quizright21_pilotfairexpl, sht_nm = "pilotfairexpl21")

## 2.4.6. Criteria: quizright0 vs. quizright2 ----
quizright20_pilotfairexpl <- fair_data_quant %>%
   select(quizright, pilotfairexpl) %>%
   filter(quizright != 1) %>%
   rename(fairness = pilotfairexpl)

f_quizright20(quizright20_pilotfairexpl, sht_nm = "pilotfairexpl20")

## 2.4.7. Voluntary: quizright1 vs. quizright2 ----
quizright21_pilotfairintern <- fair_data_quant %>%
   select(quizright, pilotfairintern) %>%
   filter(quizright != 0) %>%
   rename(fairness = pilotfairintern)

f_quizright21(quizright21_pilotfairintern, sht_nm = "pilotfairintern21")

## 2.4.8. Voluntary: quizright0 vs. quizright2 ----
quizright20_pilotfairintern <- fair_data_quant %>%
   select(quizright, pilotfairintern) %>%
   filter(quizright != 1) %>%
   rename(fairness = pilotfairintern)

f_quizright20(quizright20_pilotfairintern, sht_nm = "pilotfairintern20")


### 2.5. Compare groups concerning characteristics (graphs) ----

## 2.5.1. Gender ----
quizright_sex <- fair_data_quant %>%
   select(quizright, sex)

p <- quizright_sex %>%
   ggplot(aes(x = quizright, group = sex, fill = sex), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   guides(fill = guide_legend(nrow=1,byrow=TRUE, title = "Gender")) +
   f_layout_demo() 
p
ggsave("bar_quizright_sex.png", p, width = 120, height = 80, unit = "mm")

## 2.5.2. Age ----
quizright_age <- fair_data_quant %>%
   select(quizright, age)

p <- quizright_age %>%
   ggplot(aes(x = quizright, group = age, fill = age), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   guides(fill = guide_legend(nrow=2,byrow=TRUE, title = "Age")) +
   f_layout_demo() 
p
ggsave("bar_quizright_age.png", p, width = 120, height = 80, unit = "mm")


## 2.5.3. City ----
quizright_city <- fair_data_quant %>%
   select(quizright, city)

p <- na.omit(quizright_city) %>%
   ggplot(aes(x = quizright, group = city, fill = city), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   f_layout_demo() +
   guides(fill=guide_legend(nrow=4,byrow=TRUE, title = "Size of Place\nof residence"))
p
ggsave("bar_quizright_city.png", p, width = 120, height = 80, unit = "mm")

## 2.5.4. Education ----
quizright_education <- fair_data_quant %>%
   select(quizright, education)

p <- quizright_education %>%
   ggplot(aes(x = quizright, group = education, fill = education), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   f_layout_demo() +
   guides(fill=guide_legend(nrow=5,byrow=TRUE, title = "Highest education"))
p
ggsave("bar_quizright_education.png", p, width = 120, height = 100, unit = "mm")


## 2.5.5. WW experience ----
quizright_knowledge1 <- fair_data_quant %>%
   select(quizright, knowledge1)

quizright_knowledge1$knowledge1 <- factor(quizright_knowledge1$knowledge1, labels = c("No", "Yes"))

p <- quizright_knowledge1 %>%
   ggplot(aes(x = quizright, group = knowledge1, fill = knowledge1), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   guides(fill = guide_legend(title = "Previous engagement\nwith wastewater")) +
   f_layout_demo() 
p
ggsave("bar_quizright_knowledge1.png", p, width = 120, height = 80, unit = "mm")
   
   
## 2.5.6. Duration of WW experience ----
quizright_knowledge1howlong <- na.omit(fair_data_quant) %>%
   select(quizright, knowledge1howlong)

quizright_knowledge1howlong$knowledge1howlong <- factor(quizright_knowledge1howlong$knowledge1howlong, labels = c("Less than 1", "1-5", "6-10", "More than 10"))

p <- quizright_knowledge1howlong %>%
   ggplot(aes(x = quizright, group = knowledge1howlong, fill = knowledge1howlong), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   guides(fill = guide_legend(nrow=4,byrow=TRUE, title = "Duration of\nprevious engagement\nwith wastewater\n(in years)")) +
   f_layout_demo() 
p
ggsave("bar_quizright_knowledge1howlong.png", p, width = 120, height = 80, unit = "mm")


## 2.5.7. Reward ----
quizright_reward <- fair_data_quant %>%
   select(quizright, reward)

quizright_reward$reward <- factor(quizright_reward$reward, labels = c("Not at all important", "Not important", "Rather not important", "Rather important", "Important", "Very important"))

p <- quizright_reward %>%
   ggplot(aes(x = quizright, group = reward, fill = reward), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5) +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=2,byrow=TRUE, title = "Importance\nof reward")) +
   f_layout_demo() 
p
ggsave("bar_quizright_reward.png", p, width = 120, height = 80, unit = "mm")


## 2.5.8. Religion ----
quizright_religion <- fair_data_quant %>%
   select(quizright, religion)

quizright_religion$religion <- factor(quizright_religion$religion, labels = c("Not at all religious", "Not religious", "Rather not religious", "Rather religious", "Religious", "Very religious"))

p <- quizright_religion %>%
   ggplot(aes(x = quizright, group = religion, fill = religion), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Religioiusness")) +
   f_layout_demo() 
p
ggsave("bar_quizright_religion.png", p, width = 120, height = 80, unit = "mm")


## 2.5.8. Engagement ----
quizright_engagement <- fair_data_quant %>%
   select(quizright, engagement)

quizright_engagement$engagement <- factor(quizright_engagement$engagement, labels = c("Not at all committed", "Not committed", "Rather not committed", "Rather committed", "Committed", "Very committed"))

p <- quizright_engagement %>%
   ggplot(aes(x = quizright, group = engagement, fill = engagement), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Social\ncommitment")) +
   f_layout_demo() 
p
ggsave("bar_quizright_engagement.png", p, width = 120, height = 80, unit = "mm")


## 2.5.8. Finance ----
quizright_finance <- fair_data_quant %>%
   select(quizright, finance)

quizright_finance$finance <- factor(quizright_finance$finance, labels = c("None", "Not at all big", "Not big", "Rather not big", "Rather big", "Big", "Very big"))

p <- quizright_finance %>%
   ggplot(aes(x = quizright, group = finance, fill = finance), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=4,byrow=TRUE, title = "Financial worries")) +
   f_layout_demo() 
p
ggsave("bar_quizright_finance.png", p, width = 120, height = 80, unit = "mm")


## 2.5.8. politic_lcr ----
quizright_politic_lcr <- fair_data_quant %>%
   select(quizright, politic_lcr)

p <- quizright_politic_lcr %>%
   ggplot(aes(x = quizright, group = politic_lcr, fill = politic_lcr), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = f_colors_sz) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Social commitment")) +
   f_layout_demo() 
p
ggsave("bar_quizright_politic_lcr.png", p, width = 120, height = 80, unit = "mm")


## 2.5.8. knowledge_points ----
quizright_knowledge_points <- fair_data_quant %>%
   select(quizright, knowledge_points)
quizright_knowledge_points$knowledge_points <- factor(quizright_knowledge_points$knowledge_points, labels = c("0", "1", "2", "3", "4", "5", "6", "7", "8"))

p <- quizright_knowledge_points %>%
   ggplot(aes(x = quizright, group = knowledge_points, fill = knowledge_points), binwidth = 2) +
   geom_bar(position = position_dodge(), size = 0.5, color = '#A9A9A9') +
   scale_fill_manual(values = c("#FFFFFF", f_colors_sz, "#686868")) +
   labs(x = "No. of correct answers to the quiz") +
   scale_y_continuous(name = "Number of respondents", limits=c(0, 300), breaks = seq(0,300, by = 50)) +
   scale_x_continuous(limits = c(-0.5,2.5),
                      breaks = c(0,1,2)) +
   guides(fill = guide_legend(nrow=3,byrow=TRUE, title = "Social commitment")) +
   f_layout_demo() 
p
ggsave("bar_quizright_knowledge_points.png", p, width = 120, height = 80, unit = "mm")



### 2.6. Correlate quizright with interviewtime ----
quizright_interviewtime <- fair_data_quant %>%
   select(id, quizright, interviewtime)

#' Plot Equality vs Chance
quizright_interviewtime %>%
   ggplot(mapping = aes(x = quizright, y = interviewtime)) + 
   geom_jitter( width = 0.3) +
   geom_smooth(method = lm) +
   scale_y_continuous(name = "Duration") +
   scale_x_continuous(name = "Number of correct answers", limits=c(-0.5, 2.5), expand = c(0, 0),
                      breaks = c(0,1,2))
   
rcorr(as.matrix(quizright_interviewtime), type = "pearson") 



#### 3. Analysis of hypotheses with group "quizright = 2" ----
#' Create dataset with only quizright = 2.
fair_data_quant_q2 <- fair_data_quant %>%
   filter(quizright ==2)

##Dataset in long format with all gradfair variables.
gradfair_data_q2 <- fair_data_quant_q2 %>%
   select(id, gradfairEq, gradfairEt, gradfairNe) %>%
   gather(approach, fairness, gradfairEq:gradfairNe)

#' Dataset in long format with all testfair variables.
testfair_data_q2 <- fair_data_quant_q2 %>%
   select(id, testfairEq, testfairEt) %>%
   gather(approach, fairness, testfairEq:testfairEt)

#' Dataset in long format with all pilotfair variables.
pilotfair_data_q2 <- fair_data_quant_q2 %>%
   select(id, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern) %>%
   gather(approach, fairness, pilotfairnoex:pilotfairintern)

pilotfair_data_q2$approach <- factor(pilotfair_data_q2$approach,
                                  levels = unique(pilotfair_data_q2$approach),
                                  labels = c("pilotfairnoex", "pilotfairchan", "pilotfairexpl", "pilotfairintern")) #define order from unfairest to fairest


### 3.1. Testing H1.1, H1.2 and RQ1.3 ----
#' Barcharts.
gradfair_data_q2$approach <- factor(gradfair_data_q2$approach, labels = c("Equality", "Equity", "Need")) #Just for design reasons, so the charts are labeled nicely.
f12_barcharts_vign(gradfair_data_q2, titletext = "Fairness of the different approaches in the vignette: Gradual implementation of package plants.")
gradfair_data_q2$approach <- factor(gradfair_data_q2$approach, labels = c("gradfairEq", "gradfairEt", "gradfairNe")) #Change the names of the items back.

#' Boxplots.
gradfair_data_q2 %>%
   ggplot(aes(x = approach, y = fairness)) +
   stat_summary(fun.data = min.mean.sd.max, geom = "boxplot") + 
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of distributive justice:\nindividual',
                      breaks = c(1, 2, 3, 4, 5, 6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Approach') +
   f_layout_demo()

#' Test the differences between the approaches.
f10_rmANOVA(gradfair_data_q2)
#' Mauchly's test for sphericity is p < .05. Therefore we report the Greenhouse-Geisser estimate. The three approaches Eq, Et and Ne do differ significantly.  

#' Posthoc-test
gradfair_tt <-f21_pairwise.t.test.with.t.and.df(gradfair_data_q2$fairness, gradfair_data_q2$approach, paired = TRUE, p.adjust.method = "bonferroni")
gradfair_tt$t.value
gradfair_tt$p.value
gradfair_tt$dfs
by(gradfair_data_q2$fairness,list(gradfair_data_q2$approach),mean)
#' Et is significantly fairer than Eq. Ne is significantly fairer than Eq. Ne is significantly fairer than Et.  
#' Effect sizes: sqrt(t^2/(t^2+df))
sqrt(gradfair_tt$t.value^2/(gradfair_tt$t.value^2+gradfair_tt$dfs))


### 3.2. Testing H2.1 ----
#' Barchart.
testfair_data_q2$approach <- factor(testfair_data_q2$approach, labels = c("Equality", "Equity")) #Just for design reasons, so the charts are labeled nicely.
f12_barcharts_vign(testfair_data_q2, titletext = "Fairness of the different approaches in the vignette: Test phase with package plants.")
testfair_data_q2$approach <- factor(testfair_data_q2$approach, labels = c("testfairEq", "testfairEt"))#Change the names of the items back.

#Boxplot with M, SD, Min, Max.
testfair_data_q2 %>%
   ggplot(aes(x = approach, y = fairness)) +
   stat_summary(fun.data = min.mean.sd.max, geom = "boxplot") + 
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of distributive justice:\ncollective',
                      breaks = c(1, 2, 3, 4, 5, 6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Approach') +
   f_layout_demo()

#' Test the difference between the two approaches.
testfair_wt <- wilcox.test(fair_data_quant_q2$testfairEq, fair_data_quant_q2$testfairEt, paired = TRUE, alternative = "less", conf.int = TRUE)
testfair_wt
by(testfair_data_q2$fairness,list(testfair_data_q2$approach),mean)
#' Equity is fairer than Equality (p = .007).  
f23_rFromWilcox(testfair_wt, 472)


### 3.3. Testing H2.2 and RQ2.3----
#' Test consistency of answers. participants who chose 100% : 0% as totally fair, should also allocate 100% to Weihermatten.
#' Spearman correlation between testalloc and testfairEt is significant.
fair_data_quant_q2 %>%
   filter(testfairEq == 6) %>%
   count(testalloc)

fair_data_quant_q2 %>%
   filter(testfairEt == 6) %>%
   count(testalloc)

#' What do we do with participants, who answered inconsistently? 
#' Ignore all inconsistent cases for this analysis: ignored if...  
#' ...Eq and Et were both rated as totally fair.   
#' ...rating of Eq/Et is inconsistent with testalloc:
testfair_data_wide_no_incons_q2 <- f13_del_incons_cases_q2()

#' H2.2: The share allocated to Weihermatten is more than 50% (= 11).
#' 1 means 100% for Weihermatten and 0% for Angarten. Therefore our hypothesis means: testalloc < 11.  
median(testfair_data_wide_no_incons_q2$testalloc)
mean(testfair_data_wide_no_incons_q2$testalloc)
sd(testfair_data_wide_no_incons_q2$testalloc)

alloc_wt <- wilcox.test(testfair_data_wide_no_incons_q2$testalloc, mu = 11, alternative = "less", conf.int = TRUE)
alloc_wt
#' Calculate the effectsize (Reference: Andy Field (2012)):
f23_rFromWilcox(alloc_wt, 427)


#' *RQ2.3: Which allocation key is most often chosen as totally fair?*
testfair_data_wide_no_incons_q2 %>%
   count(testalloc) %>%
   mutate(percent = prop.table(n)*100)


### 3.3. Testing H3.1 - H3.4 ----
#' Barcharts.
pilotfair_data_q2$approach <- factor(pilotfair_data_q2$approach, labels = c("Gut feeling", "Chance", "Criteria", "Voluntary")) #Just for design reasons, so the charts are labeled nicely.
f12_barcharts_vign(pilotfair_data_q2, titletext = "Fairness of the different approaches in the vignette: Pilot project with package plants.")
pilotfair_data_q2$approach <- factor(pilotfair_data_q2$approach, labels = c("pilotfairnoex", "pilotfairchan", "pilotfairexpl", "pilotfairintern")) #Change the names of the items back.

#' Boxplots.
pilotfair_data_q2 %>%
   ggplot(aes(x = approach, y = fairness)) +
   stat_summary(fun.data = min.mean.sd.max, geom = "boxplot") + 
   geom_jitter(width = 0.2, height = 0.3, color = "#9712FA", size = 0.8) +
   scale_y_continuous(name = 'Evaluation of distributive justice:\nindividual',
                      breaks = c(1, 2, 3, 4, 5, 6),
                      labels = c("Not at all fair - 1", "Not fair - 2", "Rather not fair - 3", "Rather fair - 4", "Fair - 5", "Totally fair - 6")) +
   scale_x_discrete(name = 'Approach') +
   f_layout_demo()

f10_rmANOVA(pilotfair_data_q2)
#' Mauchly's test for sphericity is significant. Therefore we report the Greenhouse-Geisser estimate. The four approaches gut feeling, chance, criteria and voluntary do differ significantly.

# Create wide format data
pilotfair_data_wide_q2 <- fair_data_quant_q2 %>%
   select(id, pilotfairnoex, pilotfairchan, pilotfairexpl, pilotfairintern)
pilotfair_data_wide_q2 <- pilotfair_data_wide_q2 %>%
   mutate(diffnoexchan = pilotfairnoex - pilotfairchan)%>%
   mutate(diffnoexexpl = pilotfairnoex - pilotfairexpl)%>%
   mutate(diffnoexintern = pilotfairnoex - pilotfairintern) %>%
   mutate(diffchanexpl = pilotfairchan - pilotfairexpl) %>%
   mutate(diffchanintern = pilotfairchan - pilotfairintern) %>%
   mutate(diffexplintern = pilotfairexpl - pilotfairintern)

by(pilotfair_data_q2$fairness,list(pilotfair_data_q2$approach),mean)

#' Posthoc test: Wilcoxon signed-rank test for all comparisons.
#' NoexChan.
noexchan_wt <- wilcox.test(pilotfair_data_wide_q2$pilotfairnoex, pilotfair_data_wide_q2$pilotfairchan, paired = TRUE, alternative = "less", conf.int = TRUE)
noexchan_wt$statistic
noexchan_wt$p.value
noexchan_r <- f23_rFromWilcox(noexchan_wt, 284)

#' NoexExpl.
noexexpl_wt <- wilcox.test(pilotfair_data_wide_q2$pilotfairnoex, pilotfair_data_wide_q2$pilotfairexpl, paired = TRUE, alternative = "less", conf.int = TRUE)
noexexpl_wt$statistic
noexexpl_wt$p.value
f23_rFromWilcox(noexexpl_wt, 284)

#' NoexIntern.
noexintern_wt <- wilcox.test(pilotfair_data_wide_q2$pilotfairnoex, pilotfair_data_wide_q2$pilotfairintern, paired = TRUE, alternative = "less", conf.int = TRUE)
noexintern_wt$statistic
noexintern_wt$p.value
f23_rFromWilcox(noexintern_wt, 284)

#' ChanExpl.
chanexpl_wt <- wilcox.test(pilotfair_data_wide_q2$pilotfairchan, pilotfair_data_wide_q2$pilotfairexpl, paired = TRUE, alternative = "less", conf.int = TRUE)
chanexpl_wt$statistic
chanexpl_wt$p.value
f23_rFromWilcox(chanexpl_wt, 284)

#' ChanIntern.
chanintern_wt <- wilcox.test(pilotfair_data_wide_q2$pilotfairchan, pilotfair_data_wide_q2$pilotfairintern, paired = TRUE, alternative = "less", conf.int = TRUE)
chanintern_wt$statistic
chanintern_wt$p.value
f23_rFromWilcox(chanintern_wt, 284)

#' ExplIntern.
explintern_wt <- wilcox.test(pilotfair_data_wide_q2$pilotfairexpl, pilotfair_data_wide_q2$pilotfairintern, paired = TRUE, alternative = "less", conf.int = TRUE)
explintern_wt$statistic
explintern_wt$p.value
f23_rFromWilcox(explintern_wt, 284)

#' Bonferroni adjustment.
pilot_wt <- c(noexchan_wt$p.value, noexexpl_wt$p.value, noexintern_wt$p.value, chanexpl_wt$p.value, chanintern_wt$p.value, explintern_wt$p.value)
p.adjust(pilot_wt, method = "bonferroni", n = 6)




