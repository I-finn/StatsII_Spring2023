HOW TO USE THE SCRIPTS
----------------------
There are three main parts of the analysis: Cleaning, testing assumptions and the actual analysis. Each of these parts consists oft two scripts,
the main script (x.1) and a script containing the functions used in that script (xxx_func). There is a code in the main script, that automatically 
calls the functions at the beginning. Also, in the assumptions and the analysis scripts, the cleaning script is sourced by code at the beginning of
the script. This way, the data always gets "cleaned" before you start analysing the data.
There are two additional parts: graphs for papers and the comparison of the respondents, who answered both quiz questions correctly and the ones
who only answered one or non of them correctly.


FILES
-------

DATE ADDED      NAME OF FILE/FOLDER                             SHORT DESCRIPTION OF CONTENTS
============    ============================================    =================================================================================
20201124	1.1_fairness_cleaning				With this script, the data is brought to a presentable format (deleting unused
								variables, changing variable names, etc). Open answers are categorized where
								possible. Variable levels are defined. Value labels are added. incomplete cases 
								are excluded, etc. 

20201124	1.2_fairness_cleaning_func			These are the functions, that are used in the script 1.1.

20190903	2.1_fairness_assumptions			With this script, the data gets checked for outliers. Assumptions for tests, that
								are done in 3.1 are checked and it is decided which exact test is possible for the 
								data.

20190903	2.2_fairness_assumptions_func			These are the functions, that are used in the script 2.1.

20201124	3.1_fairness_analysis				With this script, the hypotheses are tested. Also descriptives are calculated. 

20201124	3.2_fairness_analysis_func			These are the functions, that are used in the script 3.1.

20201124	4_graphs_for_paper				This script computes all the graphs for the paper. 

20190806	5_compare_quizright0-2				In this script groups are built according to the number of correctly answered quiz 
								questions. Then the answers of the groups are compared. Also the hypotheses testing 
								was done with only the group of respondents who had answered both quiz questions 
								correctly. 