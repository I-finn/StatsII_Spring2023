# Pat Leslie, 22 June 2021

rm(list=ls())
library(tidyverse);library(readr);library(summarytools); library(table1)

masterData <- read_csv("analysis_data.csv")


## creating a summarised descriptive dataset

descriptiveData<-masterData[masterData$unan==0,]
descriptiveData$Female<-0
descriptiveData$Female[descriptiveData$gender=='Female']<-1
descriptiveData$LowerCourtLiberal<-0
descriptiveData$LowerCourtLiberal[descriptiveData$lcDispositionDirection=='liberal']<-1
descriptiveData$AppointedBYALP<-0
descriptiveData$AppointedBYALP[descriptiveData$appPMParty=='ALP']<-1

## general summary statistics table

descriptiveData<-descriptiveData%>%dplyr::select(direction, AppointedBYALP   , scIdeolScore  ,Female   ,
                                                 Experience, lcDissent, LowerCourtLiberal, numberJustices, 
                                                 totalTimeArgumentDays )
view(descr(descriptiveData, stats = c("mean", "sd", 'min', 'max'), transpose = TRUE, headings = T))



#Desciptive tabulations for the following tables: 

#TABLE 1: Ideology scores for Australian High Court Justices, Ranked from Most to Least Liberal
#TABLE 2: Proportion of Liberal Votes by Justice in All Non-Unanimous Decisions, Ordered Most Liberal to Least Liberal
#TABLE 3: Liberal Ideology Scores and Voting Patterns by Justice in Non-Unanimous Cases

CorTab<-masterData%>%
  group_by(justiceName)%>%
  summarise(
    
    justiceNum = justice[1],
    Party = appPMParty[1],
    Ideology = scIdeolScore[1],
    LiberalVotesAll = mean(direction,na.rm=T),
    casesAll= sum(!is.na(direction)), 
    LiberalVotesContested = mean(direction[unan==0], na.rm=T), 
    casesContested = sum(!is.na(direction) &unan==0),
    LiberalVotesContestedWithAppeal =  mean(direction[unan==0&!is.na(lcDissent)
                                                      &!is.na(totalTimeArgumentDays)&
                                                        !is.na(direction)]),
    casesContestedWithAppeal= sum(unan==0&!is.na(lcDissent)
                                  &!is.na(totalTimeArgumentDays)&
                                    !is.na(direction))
  )

View(CorTab)



inits<- bind_cols(initials=judge_data$justiceInitials[1:21], 
                  justiceName=judge_data$justiceName[1:21])

# 
# #bivariate tests of association for TABLE 3
# 
# # calculations for association between party of appointment and voting
# prop.test(table(masterData$appPMParty, masterData$direction))
# prop.test(table(masterData$appPMParty[masterData$unan==0], masterData$direction[masterData$unan==0]))
# prop.test(table(masterData$appPMParty[masterData$unan==0&
#                                         !is.na(masterData$lcDissent)],
#                 masterData$direction[masterData$unan==0&
#                                        !is.na(masterData$lcDissent)]))
# 
# # calculations for ideology correlation
# library(wCorr)
# AllCov<-weightedCorr(CorTab$Ideology, CorTab$LiberalVotesAll, weights = CorTab$casesAll, method = 'pearson')
# ContestedCov<-weightedCorr(CorTab$Ideology, CorTab$LiberalVotesContested, weights = CorTab$casesContested, method = 'pearson')
# ContestedWithAppealCov<-weightedCorr(CorTab$Ideology, CorTab$LiberalVotesContestedWithAppeal, weights = CorTab$casesContestedWithAppeal, method = 'pearson')
# 
# 



#TABLE 3: Liberal Voting by Policy Issue (i.e. area of law), in Non-Unanimous Cases

VotingByAreaAndJustice<-masterData%>%
  group_by(justiceName)%>%
  summarise(
    Ideology = scIdeolScore[1],
    Economic = mean(direction[Area=="Economic Relations"&unan==0], na.rm=T),
    Criminal = mean(direction[Area=="Criminal Law and Procedure"&unan==0], na.rm=T),
    Public = mean(direction[Area=="Public and Constitutional Law"&unan==0], na.rm=T),
    Common = mean(direction[Area=="Common Law"&unan==0], na.rm=T),
    CivilRights = mean(direction[Area=="Civil Rights and Vulnerable Persons"&unan==0], na.rm=T),
    Procedure = mean(direction[Area=="Procedure and Ethics"&unan==0], na.rm=T),
    nTotal = length(direction[unan==0]),
    nEcon = length(direction[Area=="Economic Relations"&unan==0]),
    nCrim = length(direction[Area=="Criminal Law and Procedure"&unan==0]),
    nPub = length(direction[Area=="Public and Constitutional Law"&unan==0]),
    nComm = length(direction[Area=="Common Law"&unan==0]),
    nCiv = length(direction[Area=="Civil Rights and Vulnerable Persons"&unan==0]),
    nProc = length(direction[Area=="Procedure and Ethics"&unan==0])
  )

View(VotingByAreaAndJustice)

# figure: scatter plot with regression coefficient


CorTab<- CorTab%>% left_join(inits)


scatter <-ggplot(CorTab, aes(Ideology, LiberalVotesContested))+ 
  geom_point()+
  scale_y_continuous(limits = c(0,1))+geom_smooth(method = 'lm', se=F, col='Black')+
  scale_x_continuous(limits = c(0,1))+
  geom_text_repel(aes(Ideology, LiberalVotesContested, label=CorTab$initials, 
                      col=CorTab$Party),nudge_x=0.01, show.legend = F)+
  theme_classic()+xlab("Liberal ideology")+ylab('proportion(Liberal votes)')+
  scale_color_manual(values=c('Black', 'grey'))

scatter



ggsave(scatter,filename = 'Outputs/scatter_figure_BW.png' ,height = 5, width = 7, device='png', dpi=600)


